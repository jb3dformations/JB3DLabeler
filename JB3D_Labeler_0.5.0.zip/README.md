# JB3D Labeler 0.5.0

## Nouveautés 0.5

### Gestionnaire d’étiquettes

Le panneau `N > JB3D` contient maintenant une liste persistante de toutes les étiquettes de la scène.

Chaque ligne permet directement de :

- renommer l’étiquette ;
- l’afficher ou la masquer dans la vue et au rendu ;
- verrouiller ou déverrouiller sa surface ;
- verrouiller ou déverrouiller son ancre ;
- choisir son mode de fusion couleur.

Le clic sur une ligne active l’étiquette et sélectionne automatiquement son ancre. Si cette ancre est verrouillée, le contrôleur est sélectionné à sa place.

### Ordre de superposition

Les boutons fléchés placés à droite de la liste changent l’ordre des couches :

```text
Haut de la liste = étiquette au-dessus
Bas de la liste  = étiquette en dessous
```

Pour les étiquettes attachées au même produit, le plugin calcule automatiquement un très léger décalage supplémentaire afin de rendre l’ordre déterministe et d’éviter le conflit de profondeur. La valeur de décalage physique demandée par chaque étiquette est conservée.

### Modes de fusion

Le mode par défaut est **Mélange (`Mix`)**, qui conserve l’apparence normale de l’image.

Modes proposés :

- Mélange ;
- Addition ;
- Soustraction ;
- Multiplication ;
- Écran ;
- Division ;
- Différence ;
- Assombrir ;
- Éclaircir ;
- Superposition ;
- Densité couleur − ;
- Densité couleur + ;
- Teinte ;
- Saturation ;
- Valeur ;
- Couleur ;
- Lumière tamisée ;
- Lumière linéaire.

Le choix pilote le nœud **Mix Color** du matériau de l’étiquette. L’alpha de l’image continue à découper proprement la surface et le dos reste blanc.

### Protection contre les manipulations accidentelles

À la création et lors de la migration d’une ancienne étiquette :

- la surface générée est verrouillée à la sélection par défaut ;
- elle reste modifiable depuis le gestionnaire ;
- l’ancre reste visible, sélectionnable et manipulable ;
- l’ancre peut être verrouillée individuellement depuis sa ligne ;
- le contrôleur reste disponible pour le placement, la rotation et la taille.

Le verrouillage repose sur la restriction de sélection de l’objet. Il protège donc aussi bien la vue 3D que l’Outliner.

### Interface épurée

L’interface est maintenant organisée en trois zones :

1. **Étiquettes** : gestion globale et superposition ;
2. **Nouvelle étiquette** : image, dimensions et création ;
3. **Étiquette active** : réglages utiles, outils et maintenance repliable.

Les paramètres techniques de dépliage, de surface et de matériau restent accessibles dans les sections avancées sans encombrer le workflow principal.

## Fonctionnalités conservées

- détection automatique des dimensions de l’image en pixels ;
- conservation du rapport largeur/hauteur ;
- dimensions physiques exactes ;
- UV métriques ;
- copie du modificateur Surface de subdivision avant le Shrinkwrap ;
- parentage complet au produit ;
- matériau organisé avec un groupe de coordonnées partagé ;
- face imprimée et dos collé blanc ;
- analyse de déformation ;
- contrôle du dépassement de la zone sélectionnée.

## Installation

1. Désactiver l’ancienne version de JB3D Labeler.
2. Ouvrir `Edit > Preferences > Add-ons` ou `Extensions`.
3. Choisir **Install from Disk**.
4. Installer `JB3D_Labeler_0.5.0.zip`.
5. Activer l’extension.
6. Ouvrir `N > JB3D` dans la vue 3D.

## Migration des étiquettes 0.1 à 0.4

Les anciennes étiquettes sont détectées et ajoutées automatiquement à la liste.

Pour réparer une étiquette ancienne ou incomplète :

1. la sélectionner dans la liste ;
2. ouvrir **Maintenance** ;
3. utiliser **Vérifier les liens et le parentage** ;
4. cliquer sur **Mettre à jour l’étiquette** si son matériau doit être reconstruit.

Les anciennes surfaces deviennent protégées par défaut et leurs ancres restent déverrouillées.

## Workflow

1. Sélectionner le produit et passer en mode Édition.
2. Sélectionner une zone continue légèrement plus grande que l’étiquette.
3. Définir en dernier la face centrale et, éventuellement, une arête horizontale.
4. Choisir l’image et saisir une dimension physique.
5. Créer l’étiquette.
6. Utiliser l’ancre ou le contrôleur selon le réglage souhaité.
7. Gérer visibilité, verrouillage, fusion et superposition depuis la liste.

## Compatibilité visée

Blender 4.3 et versions 5.x.
