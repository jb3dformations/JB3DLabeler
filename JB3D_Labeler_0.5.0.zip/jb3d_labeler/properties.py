from __future__ import annotations

import os

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup


UNWRAP_ITEMS = (
    ('AUTO', "Automatique", "Projection plane si possible, Follow Active Quads sur une grille de quads, sinon dépliage angulaire"),
    ('PLANAR', "Planaire métrique", "Projection métrique sur le plan moyen de la sélection"),
    ('QUAD', "Follow Active Quads", "Dépliage basé sur la face active et les longueurs de la grille de quads"),
    ('ANGLE_BASED', "Angle Based", "Dépliage adapté aux surfaces organiques ou courbes"),
    ('CONFORMAL', "Conformal", "Dépliage conformal"),
)

ORIENTATION_ITEMS = (
    ('AUTO', "Automatique", "Utilise l'arête active si elle existe, sinon l'axe Z de l'objet"),
    ('ACTIVE_EDGE', "Arête active horizontale", "Aligne l'arête active sur l'horizontale de l'étiquette"),
    ('OBJECT_Z', "Axe Z de l'objet", "Conserve la verticale de l'objet comme verticale de l'étiquette"),
    ('VIEW', "Vue actuelle", "Utilise l'horizontale de la vue 3D comme horizontale"),
)

ROLE_ITEMS = (
    ('NONE', "Aucun", "Objet étranger au rig"),
    ('LABEL', "Étiquette", "Surface de l'étiquette"),
    ('CONTROLLER', "Contrôleur", "Contrôleur de position et de taille"),
    ('ANCHOR', "Ancrage", "Repère tangent à la surface"),
)

SIZE_AXIS_ITEMS = (
    ('WIDTH', "Largeur", "La largeur est la dimension de référence"),
    ('HEIGHT', "Hauteur", "La hauteur est la dimension de référence"),
)

# Identifiers match ShaderNodeMix.blend_type.
BLEND_MODE_ITEMS = (
    ('MIX', "Mélange", "Mélange normal, sans effet particulier"),
    ('ADD', "Addition", "Additionne les couleurs"),
    ('SUBTRACT', "Soustraction", "Soustrait les couleurs"),
    ('MULTIPLY', "Multiplication", "Multiplie les couleurs"),
    ('SCREEN', "Écran", "Éclaircit selon le mode Écran"),
    ('DIVIDE', "Division", "Divise les couleurs"),
    ('DIFFERENCE', "Différence", "Affiche la différence entre les couleurs"),
    ('DARKEN', "Assombrir", "Conserve les composantes les plus sombres"),
    ('LIGHTEN', "Éclaircir", "Conserve les composantes les plus claires"),
    ('OVERLAY', "Superposition", "Combine multiplication et écran"),
    ('DODGE', "Densité couleur −", "Éclaircit par densité couleur"),
    ('BURN', "Densité couleur +", "Assombrit par densité couleur"),
    ('HUE', "Teinte", "Applique la teinte de l'image"),
    ('SATURATION', "Saturation", "Applique la saturation de l'image"),
    ('VALUE', "Valeur", "Applique la valeur de l'image"),
    ('COLOR', "Couleur", "Applique teinte et saturation"),
    ('SOFT_LIGHT', "Lumière tamisée", "Applique une lumière tamisée"),
    ('LINEAR_LIGHT', "Lumière linéaire", "Applique une lumière linéaire"),
)


def _image_ratio(data) -> float | None:
    width = int(getattr(data, "image_pixel_width", 0))
    height = int(getattr(data, "image_pixel_height", 0))
    if width <= 0 or height <= 0:
        image = getattr(data, "image", None)
        if image is not None and len(image.size) >= 2:
            width = int(image.size[0])
            height = int(image.size[1])
    if width <= 0 or height <= 0:
        return None
    return width / height


def _sync_ratio(data, reference_axis: str | None = None) -> None:
    if getattr(data, "ratio_update_lock", False) or not getattr(data, "preserve_ratio", True):
        return
    ratio = _image_ratio(data)
    if ratio is None or ratio <= 1e-12:
        return

    axis = reference_axis or getattr(data, "last_edited_dimension", 'WIDTH')
    data.ratio_update_lock = True
    try:
        if axis == 'HEIGHT':
            data.width = max(float(data.height) * ratio, 1e-6)
        else:
            data.height = max(float(data.width) / ratio, 1e-6)
    finally:
        data.ratio_update_lock = False


def _update_width(data, context) -> None:
    if getattr(data, "ratio_update_lock", False):
        return
    data.last_edited_dimension = 'WIDTH'
    _sync_ratio(data, 'WIDTH')


def _update_height(data, context) -> None:
    if getattr(data, "ratio_update_lock", False):
        return
    data.last_edited_dimension = 'HEIGHT'
    _sync_ratio(data, 'HEIGHT')


def _update_preserve_ratio(data, context) -> None:
    if data.preserve_ratio:
        _sync_ratio(data, data.last_edited_dimension)


def _update_image_path(data, context) -> None:
    if getattr(data, "ratio_update_lock", False):
        return

    path = bpy.path.abspath(getattr(data, "image_path", ""))
    if not path or not os.path.isfile(path):
        return

    try:
        image = bpy.data.images.load(path, check_existing=True)
    except Exception:
        return

    data.image = image
    data.image_pixel_width = int(image.size[0]) if len(image.size) >= 1 else 0
    data.image_pixel_height = int(image.size[1]) if len(image.size) >= 2 else 0
    _sync_ratio(data, data.last_edited_dimension)


def _label_owner(data) -> bpy.types.Object | None:
    owner = getattr(data, "id_data", None)
    if isinstance(owner, bpy.types.Object):
        if getattr(data, "role", 'NONE') == 'LABEL':
            return owner
        linked = getattr(data, "owner_label", None)
        if isinstance(linked, bpy.types.Object):
            return linked
    return None


def _update_visibility(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    hidden = not bool(data.visible)
    try:
        label.hide_viewport = hidden
        label.hide_render = hidden
    except (AttributeError, RuntimeError):
        pass


def _select_safe_rig_part(context, data, excluded) -> None:
    if context is None:
        return
    try:
        from .utils import select_only
        for candidate in (getattr(data, "anchor_object", None), getattr(data, "controller_object", None)):
            if candidate is None or candidate == excluded or candidate.hide_select:
                continue
            select_only(context, candidate)
            return
    except Exception:
        pass


def _update_label_lock(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    try:
        was_active = context is not None and context.view_layer.objects.active == label
        label.hide_select = bool(data.label_locked)
        if data.label_locked:
            label.select_set(False)
            if was_active:
                _select_safe_rig_part(context, data, label)
    except (AttributeError, RuntimeError):
        pass


def _update_anchor_lock(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    anchor = getattr(data, "anchor_object", None)
    if anchor is None:
        return
    try:
        was_active = context is not None and context.view_layer.objects.active == anchor
        anchor.hide_select = bool(data.anchor_locked)
        if data.anchor_locked:
            anchor.select_set(False)
            if was_active:
                _select_safe_rig_part(context, data, anchor)
    except (AttributeError, RuntimeError):
        pass


def _update_blend_mode(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    try:
        from . import materials
        applied = materials.set_label_blend_mode(label, data.blend_mode)
        if not applied and data.controller_object is not None and data.image is not None:
            materials.update_label_material(
                label,
                data.controller_object,
                data.image,
                data.roughness,
                data.metallic,
                data.blend_mode,
            )
    except Exception:
        # A severely damaged material can still be rebuilt with “Mettre à jour”.
        pass


def _update_active_label_index(scene, context) -> None:
    if context is None or context.scene != scene:
        return
    try:
        from . import registry
        if registry.index_selection_suspended():
            return
        from .utils import resolve_rig_from_object, select_only
        label = registry.active_label(scene)
        rig = resolve_rig_from_object(label)
        if rig is None:
            return
        target = rig.anchor if rig.anchor is not None and not label.jb3d_labeler.anchor_locked else rig.controller
        if target is not None:
            select_only(context, target)
    except Exception:
        pass


class JB3DLabelerDefaults(PropertyGroup):
    image: PointerProperty(type=bpy.types.Image, options={'HIDDEN'})

    image_path: StringProperty(
        name="Image",
        description="Image de l'étiquette (PNG, JPG, TIFF...)",
        subtype='FILE_PATH',
        update=_update_image_path,
    )

    image_pixel_width: IntProperty(default=0, min=0, options={'HIDDEN'})
    image_pixel_height: IntProperty(default=0, min=0, options={'HIDDEN'})
    ratio_update_lock: BoolProperty(default=False, options={'HIDDEN'})
    last_edited_dimension: EnumProperty(items=SIZE_AXIS_ITEMS, default='WIDTH', options={'HIDDEN'})

    width: FloatProperty(
        name="Largeur",
        description="Largeur physique de l'étiquette",
        default=0.085,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_width,
    )

    height: FloatProperty(
        name="Hauteur",
        description="Hauteur physique de l'étiquette",
        default=0.120,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_height,
    )

    preserve_ratio: BoolProperty(
        name="Conserver le ratio",
        description="Lie automatiquement la largeur et la hauteur selon les pixels de l'image",
        default=True,
        update=_update_preserve_ratio,
    )

    surface_offset: FloatProperty(
        name="Décalage surface",
        description="Distance entre le produit et l'étiquette",
        default=0.0002,
        min=0.0,
        soft_max=0.01,
        subtype='DISTANCE',
        unit='LENGTH',
    )

    follow_surface: BoolProperty(
        name="Suivre la surface",
        description="Conserve un Shrinkwrap non destructif vers l'objet source",
        default=True,
    )

    unwrap_method: EnumProperty(
        name="Dépliage",
        description="Méthode utilisée pour créer les UV métriques",
        items=UNWRAP_ITEMS,
        default='AUTO',
    )

    orientation_mode: EnumProperty(
        name="Orientation",
        description="Référence utilisée pour orienter l'étiquette",
        items=ORIENTATION_ITEMS,
        default='AUTO',
    )

    roughness: FloatProperty(name="Rugosité", default=0.42, min=0.0, max=1.0, subtype='FACTOR')
    metallic: FloatProperty(name="Métallique", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    pack_image: BoolProperty(
        name="Embarquer l'image",
        description="Pack l'image dans le fichier .blend",
        default=False,
    )

    show_create_advanced: BoolProperty(name="Options avancées", default=False)
    show_active_advanced: BoolProperty(name="Réglages avancés", default=False)
    show_maintenance: BoolProperty(name="Maintenance", default=False)


class JB3DLabelObjectData(PropertyGroup):
    role: EnumProperty(items=ROLE_ITEMS, default='NONE', options={'HIDDEN'})
    rig_uuid: StringProperty(name="Rig UUID", options={'HIDDEN'})
    data_version: IntProperty(default=5, options={'HIDDEN'})

    owner_label: PointerProperty(type=bpy.types.Object)
    source_object: PointerProperty(type=bpy.types.Object)
    controller_object: PointerProperty(type=bpy.types.Object)
    anchor_object: PointerProperty(type=bpy.types.Object)
    image: PointerProperty(type=bpy.types.Image)

    image_path: StringProperty(
        name="Image",
        description="Fichier image utilisé par cette étiquette",
        subtype='FILE_PATH',
        update=_update_image_path,
    )

    image_pixel_width: IntProperty(default=0, min=0, options={'HIDDEN'})
    image_pixel_height: IntProperty(default=0, min=0, options={'HIDDEN'})
    ratio_update_lock: BoolProperty(default=False, options={'HIDDEN'})
    last_edited_dimension: EnumProperty(items=SIZE_AXIS_ITEMS, default='WIDTH', options={'HIDDEN'})

    width: FloatProperty(
        name="Largeur",
        default=0.085,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_width,
    )

    height: FloatProperty(
        name="Hauteur",
        default=0.120,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_height,
    )

    preserve_ratio: BoolProperty(name="Conserver le ratio", default=True, update=_update_preserve_ratio)

    surface_offset: FloatProperty(
        name="Décalage surface",
        default=0.0002,
        min=0.0,
        soft_max=0.01,
        subtype='DISTANCE',
        unit='LENGTH',
    )

    follow_surface: BoolProperty(name="Suivre la surface", default=True)
    unwrap_method: EnumProperty(name="Dépliage", items=UNWRAP_ITEMS, default='AUTO')
    orientation_mode: EnumProperty(name="Orientation", items=ORIENTATION_ITEMS, default='AUTO')
    applied_unwrap_method: StringProperty(default="", options={'HIDDEN'})
    applied_orientation_mode: StringProperty(default="", options={'HIDDEN'})

    roughness: FloatProperty(name="Rugosité", default=0.42, min=0.0, max=1.0, subtype='FACTOR')
    metallic: FloatProperty(name="Métallique", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    pack_image: BoolProperty(name="Embarquer l'image", default=False)

    visible: BoolProperty(
        name="Visible",
        description="Afficher l'étiquette dans la vue et au rendu",
        default=True,
        update=_update_visibility,
    )
    label_locked: BoolProperty(
        name="Verrouiller la surface",
        description="Empêcher la sélection directe de la surface de l'étiquette dans la vue et l'Outliner",
        default=True,
        update=_update_label_lock,
    )
    anchor_locked: BoolProperty(
        name="Verrouiller l'ancre",
        description="Empêcher la sélection et la manipulation de l'ancre",
        default=False,
        update=_update_anchor_lock,
    )
    blend_mode: EnumProperty(
        name="Fusion",
        description="Mode de fusion de l'image dans le matériau de l'étiquette",
        items=BLEND_MODE_ITEMS,
        default='MIX',
        update=_update_blend_mode,
    )
    stack_order: IntProperty(default=0, options={'HIDDEN'})
    stack_bias: FloatProperty(default=0.0, options={'HIDDEN'})

    active_face_index: IntProperty(default=-1, options={'HIDDEN'})
    active_edge_v0: IntProperty(default=-1, options={'HIDDEN'})
    active_edge_v1: IntProperty(default=-1, options={'HIDDEN'})

    distortion_rms: FloatProperty(default=0.0, options={'HIDDEN'})
    distortion_u: FloatProperty(default=0.0, options={'HIDDEN'})
    distortion_v: FloatProperty(default=0.0, options={'HIDDEN'})
    available_width: FloatProperty(default=0.0, options={'HIDDEN'})
    available_height: FloatProperty(default=0.0, options={'HIDDEN'})
    last_unwrap_used: StringProperty(default="", options={'HIDDEN'})


class JB3DLabelListItem(PropertyGroup):
    label: PointerProperty(type=bpy.types.Object)


_CLASSES = (
    JB3DLabelerDefaults,
    JB3DLabelObjectData,
    JB3DLabelListItem,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.jb3d_labeler = PointerProperty(type=JB3DLabelerDefaults)
    bpy.types.Scene.jb3d_label_items = CollectionProperty(type=JB3DLabelListItem)
    bpy.types.Scene.jb3d_label_index = IntProperty(name="Étiquette active", default=0, min=0, update=_update_active_label_index)


def unregister():
    for name in ("jb3d_label_index", "jb3d_label_items", "jb3d_labeler"):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
