from __future__ import annotations

from collections import defaultdict
import bpy
from bpy.app.handlers import persistent

from .utils import (
    ROLE_KEY,
    ROLE_LABEL,
    configure_surface_follow,
    ensure_rig_parenting,
    migrate_legacy_label,
    resolve_rig_from_object,
    select_only,
    update_anchor_frame,
)


# Tiny physical separation used to make the list order deterministic when
# several transparent label surfaces overlap on the same product.
STACK_SPACING = 0.00002  # 0.02 mm in Blender metres.
_SYNC_GUARD = False
_INDEX_SELECTION_SUSPENDED = False


def is_label_object(obj: bpy.types.Object | None) -> bool:
    if obj is None or not hasattr(obj, "jb3d_labeler"):
        return False
    data = obj.jb3d_labeler
    return data.role == ROLE_LABEL or obj.get(ROLE_KEY) == ROLE_LABEL


def labels_in_scene(scene: bpy.types.Scene) -> list[bpy.types.Object]:
    labels = []
    for obj in scene.objects:
        if not is_label_object(obj):
            continue
        migrate_legacy_label(obj)
        if obj.jb3d_labeler.role == ROLE_LABEL:
            labels.append(obj)
    return labels


def _apply_saved_states(label: bpy.types.Object) -> None:
    data = label.jb3d_labeler
    try:
        label.hide_viewport = not data.visible
        label.hide_render = not data.visible
        label.hide_select = data.label_locked
    except (AttributeError, RuntimeError):
        pass

    anchor = data.anchor_object
    if anchor is not None:
        try:
            anchor.hide_select = data.anchor_locked
        except (AttributeError, RuntimeError):
            pass


def sync_scene_label_list(scene: bpy.types.Scene) -> None:
    """Keep the persistent UI list aligned with label objects in the scene.

    Existing collection order is preserved. Missing legacy labels are appended,
    while dead pointers and duplicates are removed.
    """
    global _SYNC_GUARD
    if _SYNC_GUARD or scene is None or not hasattr(scene, "jb3d_label_items"):
        return

    _SYNC_GUARD = True
    try:
        valid_labels = labels_in_scene(scene)
        valid_by_pointer = {label.as_pointer(): label for label in valid_labels}
        seen_pointers = set()

        for index in reversed(range(len(scene.jb3d_label_items))):
            label = scene.jb3d_label_items[index].label
            pointer = label.as_pointer() if label is not None else 0
            if pointer not in valid_by_pointer or pointer in seen_pointers:
                scene.jb3d_label_items.remove(index)
            else:
                seen_pointers.add(pointer)

        missing = [label for label in valid_labels if label.as_pointer() not in seen_pointers]
        missing.sort(key=lambda obj: (obj.jb3d_labeler.stack_order, obj.name.casefold()))
        for label in missing:
            item = scene.jb3d_label_items.add()
            item.label = label

        for index, item in enumerate(scene.jb3d_label_items):
            label = item.label
            if label is None:
                continue
            label.jb3d_labeler.stack_order = index
            _apply_saved_states(label)

        if len(scene.jb3d_label_items) == 0:
            if scene.jb3d_label_index != 0:
                scene.jb3d_label_index = 0
        else:
            clamped_index = min(scene.jb3d_label_index, len(scene.jb3d_label_items) - 1)
            if scene.jb3d_label_index != clamped_index:
                scene.jb3d_label_index = clamped_index
    finally:
        _SYNC_GUARD = False
_INDEX_SELECTION_SUSPENDED = False


def active_label(scene: bpy.types.Scene) -> bpy.types.Object | None:
    sync_scene_label_list(scene)
    if not scene.jb3d_label_items:
        return None
    index = max(0, min(scene.jb3d_label_index, len(scene.jb3d_label_items) - 1))
    return scene.jb3d_label_items[index].label


def active_rig(context: bpy.types.Context):
    rig = resolve_rig_from_object(context.active_object)
    if rig is not None:
        return rig
    label = active_label(context.scene)
    return resolve_rig_from_object(label)


def index_selection_suspended() -> bool:
    return _INDEX_SELECTION_SUSPENDED


def set_active_label(
    scene: bpy.types.Scene,
    label: bpy.types.Object | None,
    *,
    select_object: bool = True,
) -> None:
    global _INDEX_SELECTION_SUSPENDED
    sync_scene_label_list(scene)
    if label is None:
        return
    for index, item in enumerate(scene.jb3d_label_items):
        if item.label == label:
            if select_object:
                scene.jb3d_label_index = index
            else:
                _INDEX_SELECTION_SUSPENDED = True
                try:
                    scene.jb3d_label_index = index
                finally:
                    _INDEX_SELECTION_SUSPENDED = False
            return


def register_label(scene: bpy.types.Scene, label: bpy.types.Object, *, at_top: bool = True) -> None:
    sync_scene_label_list(scene)
    current_index = next(
        (index for index, item in enumerate(scene.jb3d_label_items) if item.label == label),
        None,
    )
    if current_index is None:
        item = scene.jb3d_label_items.add()
        item.label = label
        current_index = len(scene.jb3d_label_items) - 1
    if at_top and current_index > 0:
        scene.jb3d_label_items.move(current_index, 0)
        current_index = 0
    scene.jb3d_label_index = current_index
    for index, item in enumerate(scene.jb3d_label_items):
        if item.label is not None:
            item.label.jb3d_labeler.stack_order = index


def unregister_label(scene: bpy.types.Scene, label: bpy.types.Object | None) -> None:
    if label is None or not hasattr(scene, "jb3d_label_items"):
        return
    for index in reversed(range(len(scene.jb3d_label_items))):
        if scene.jb3d_label_items[index].label == label:
            scene.jb3d_label_items.remove(index)
    if scene.jb3d_label_items:
        scene.jb3d_label_index = min(scene.jb3d_label_index, len(scene.jb3d_label_items) - 1)
    else:
        scene.jb3d_label_index = 0


def label_from_uuid(scene: bpy.types.Scene, rig_uuid: str) -> bpy.types.Object | None:
    sync_scene_label_list(scene)
    for item in scene.jb3d_label_items:
        label = item.label
        if label is not None and label.jb3d_labeler.rig_uuid == rig_uuid:
            return label
    return None


def effective_surface_offset(label_or_data) -> float:
    data = label_or_data.jb3d_labeler if isinstance(label_or_data, bpy.types.Object) else label_or_data
    return max(float(data.surface_offset) + float(data.stack_bias), 0.0)


def _ordered_groups(scene: bpy.types.Scene) -> dict[int, list[bpy.types.Object]]:
    groups: dict[int, list[bpy.types.Object]] = defaultdict(list)
    for item in scene.jb3d_label_items:
        label = item.label
        if label is None:
            continue
        source = label.jb3d_labeler.source_object
        key = source.as_pointer() if source is not None else 0
        groups[key].append(label)
    return groups


def apply_stack_order(context: bpy.types.Context, scene: bpy.types.Scene | None = None) -> None:
    """Apply top-to-bottom list order as a tiny surface offset hierarchy."""
    scene = scene or context.scene
    sync_scene_label_list(scene)

    original_active = context.view_layer.objects.active
    groups = _ordered_groups(scene)

    for global_index, item in enumerate(scene.jb3d_label_items):
        if item.label is not None:
            item.label.jb3d_labeler.stack_order = global_index

    for labels in groups.values():
        # Resolve offsets from bottom to top. This preserves each requested base
        # offset while guaranteeing that the first list item remains above all
        # lower layers, even when their base offsets differ.
        next_minimum = 0.0
        for label in reversed(labels):
            data = label.jb3d_labeler
            base_offset = max(float(data.surface_offset), 0.0)
            resolved_offset = max(base_offset, next_minimum)
            data.stack_bias = max(resolved_offset - base_offset, 0.0)
            next_minimum = resolved_offset + STACK_SPACING

        for label in labels:
            data = label.jb3d_labeler
            rig = resolve_rig_from_object(label)
            if rig is None:
                continue
            ensure_rig_parenting(rig)
            frame_offset = configure_surface_follow(
                context,
                rig.label,
                rig.source,
                data.follow_surface,
                effective_surface_offset(data),
            )
            update_anchor_frame(rig, frame_offset)

    if original_active is not None and original_active.name in bpy.data.objects:
        try:
            select_only(context, original_active)
        except Exception:
            pass


def move_active_item(context: bpy.types.Context, direction: str) -> bool:
    scene = context.scene
    sync_scene_label_list(scene)
    count = len(scene.jb3d_label_items)
    if count < 2:
        return False
    index = max(0, min(scene.jb3d_label_index, count - 1))
    target = index - 1 if direction == 'UP' else index + 1
    if target < 0 or target >= count:
        return False
    scene.jb3d_label_items.move(index, target)
    scene.jb3d_label_index = target
    apply_stack_order(context, scene)
    return True


@persistent
def _load_post(_dummy) -> None:
    for scene in bpy.data.scenes:
        sync_scene_label_list(scene)


def register():
    if _load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_load_post)
    for scene in bpy.data.scenes:
        sync_scene_label_list(scene)


def unregister():
    if _load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post)
