bl_info = {
    "name": "JB3D Labeler",
    "author": "Josselin Boullery / OpenAI",
    "version": (1, 0, 0),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar > JB3D",
    "description": "Create and manage physically sized labels from selected mesh faces",
    "category": "Object",
}

from . import operators, properties, registry, ui


def register():
    properties.register()
    registry.register()
    operators.register()
    ui.register()


def unregister():
    ui.unregister()
    operators.unregister()
    registry.unregister()
    properties.unregister()
