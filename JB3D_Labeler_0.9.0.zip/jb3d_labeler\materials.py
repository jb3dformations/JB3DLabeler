from __future__ import annotations

import bpy

from .utils import UV_NAME, add_transform_driver


NODE_PREFIX = "JB3D_LABEL_"
COORD_GROUP_NAME = "JB3D Label Coordinates v1"
COORD_GROUP_SCHEMA = 2
COORD_NODE_NAME = f"{NODE_PREFIX}COORDINATES"


def _new_math(nodes, operation: str, name: str, x: float, y: float):
    node = nodes.new("ShaderNodeMath")
    node.name = name
    node.label = name.replace(NODE_PREFIX, "")
    node.operation = operation
    node.location = (x, y)
    return node


def _new_interface_socket(
    node_tree: bpy.types.NodeTree,
    name: str,
    in_out: str,
    socket_type: str,
    default_value=None,
):
    """Create a node-group socket with Blender 4.x/5.x and a legacy fallback."""
    if hasattr(node_tree, "interface"):
        socket = node_tree.interface.new_socket(
            name=name,
            in_out=in_out,
            socket_type=socket_type,
        )
    else:  # pragma: no cover - compatibility fallback for older Blender files.
        collection = node_tree.inputs if in_out == 'INPUT' else node_tree.outputs
        socket = collection.new(socket_type, name)

    if default_value is not None and hasattr(socket, "default_value"):
        try:
            socket.default_value = default_value
        except (TypeError, ValueError):
            pass
    return socket


def _coordinate_group_is_valid(group: bpy.types.NodeTree | None) -> bool:
    if group is None or group.bl_idname != 'ShaderNodeTree':
        return False
    if int(group.get("jb3d_schema", 0)) != COORD_GROUP_SCHEMA:
        return False
    return (
        group.nodes.get("JB3D_COORD_INPUT") is not None
        and group.nodes.get("JB3D_COORD_OUTPUT") is not None
    )


def ensure_coordinate_group() -> bpy.types.NodeTree:
    """Return the shared coordinate-transform group used by all label materials."""
    group = bpy.data.node_groups.get(COORD_GROUP_NAME)
    if _coordinate_group_is_valid(group):
        return group

    # Do not destructively edit an unknown user node group with the same name.
    group_name = COORD_GROUP_NAME
    if group is not None:
        if group.users == 0:
            bpy.data.node_groups.remove(group)
        else:
            group_name = f"{COORD_GROUP_NAME} - Managed v{COORD_GROUP_SCHEMA}"
            managed = bpy.data.node_groups.get(group_name)
            if _coordinate_group_is_valid(managed):
                return managed

    group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group["jb3d_schema"] = COORD_GROUP_SCHEMA
    group.use_fake_user = True
    try:
        group.description = (
            "Transforms metric JB3D label UVs with the label controller: "
            "translation, rotation, physical width and physical height."
        )
    except Exception:
        pass

    _new_interface_socket(group, "Metric UV", 'INPUT', 'NodeSocketVector', (0.0, 0.0, 0.0))
    _new_interface_socket(group, "Center U", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Center V", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Rotation", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Width", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Image Coordinates", 'OUTPUT', 'NodeSocketVector')

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.name = "JB3D_COORD_INPUT"
    group_input.label = "Label Controls"
    group_input.location = (-1000, 20)

    group_output = nodes.new("NodeGroupOutput")
    group_output.name = "JB3D_COORD_OUTPUT"
    group_output.label = "0–1 Coordinates"
    group_output.location = (720, 80)

    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.name = "JB3D_COORD_SEPARATE"
    separate.label = "Separate UV"
    separate.location = (-780, 180)

    subtract_u = _new_math(nodes, 'SUBTRACT', "JB3D_COORD_SUB_U", -560, 260)
    subtract_v = _new_math(nodes, 'SUBTRACT', "JB3D_COORD_SUB_V", -560, 80)

    cosine = _new_math(nodes, 'COSINE', "JB3D_COORD_COS", -560, -160)
    sine = _new_math(nodes, 'SINE', "JB3D_COORD_SIN", -560, -300)

    dx_cos = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DX_COS", -330, 330)
    dy_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DY_SIN", -330, 210)
    rotated_x = _new_math(nodes, 'ADD', "JB3D_COORD_ROT_X", -100, 280)

    dx_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DX_SIN", -330, 50)
    dy_cos = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DY_COS", -330, -80)
    negative_dx_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_NEG_DX_SIN", -100, 40)
    negative_dx_sin.inputs[1].default_value = -1.0
    rotated_y = _new_math(nodes, 'ADD', "JB3D_COORD_ROT_Y", 110, -20)

    divide_u = _new_math(nodes, 'DIVIDE', "JB3D_COORD_DIV_U", 120, 280)
    divide_v = _new_math(nodes, 'DIVIDE', "JB3D_COORD_DIV_V", 330, -20)

    add_half_u = _new_math(nodes, 'ADD', "JB3D_COORD_ADD_HALF_U", 340, 280)
    add_half_u.inputs[1].default_value = 0.5
    add_half_v = _new_math(nodes, 'ADD', "JB3D_COORD_ADD_HALF_V", 540, -20)
    add_half_v.inputs[1].default_value = 0.5

    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.name = "JB3D_COORD_COMBINE"
    combine.label = "Image Coordinates"
    combine.location = (540, 170)
    combine.inputs["Z"].default_value = 0.0

    links.new(group_input.outputs["Metric UV"], separate.inputs["Vector"])
    links.new(separate.outputs["X"], subtract_u.inputs[0])
    links.new(group_input.outputs["Center U"], subtract_u.inputs[1])
    links.new(separate.outputs["Y"], subtract_v.inputs[0])
    links.new(group_input.outputs["Center V"], subtract_v.inputs[1])

    links.new(group_input.outputs["Rotation"], cosine.inputs[0])
    links.new(group_input.outputs["Rotation"], sine.inputs[0])

    links.new(subtract_u.outputs[0], dx_cos.inputs[0])
    links.new(cosine.outputs[0], dx_cos.inputs[1])
    links.new(subtract_v.outputs[0], dy_sin.inputs[0])
    links.new(sine.outputs[0], dy_sin.inputs[1])
    links.new(dx_cos.outputs[0], rotated_x.inputs[0])
    links.new(dy_sin.outputs[0], rotated_x.inputs[1])

    links.new(subtract_u.outputs[0], dx_sin.inputs[0])
    links.new(sine.outputs[0], dx_sin.inputs[1])
    links.new(subtract_v.outputs[0], dy_cos.inputs[0])
    links.new(cosine.outputs[0], dy_cos.inputs[1])
    links.new(dx_sin.outputs[0], negative_dx_sin.inputs[0])
    links.new(negative_dx_sin.outputs[0], rotated_y.inputs[0])
    links.new(dy_cos.outputs[0], rotated_y.inputs[1])

    links.new(rotated_x.outputs[0], divide_u.inputs[0])
    links.new(group_input.outputs["Width"], divide_u.inputs[1])
    links.new(rotated_y.outputs[0], divide_v.inputs[0])
    links.new(group_input.outputs["Height"], divide_v.inputs[1])

    links.new(divide_u.outputs[0], add_half_u.inputs[0])
    links.new(divide_v.outputs[0], add_half_v.inputs[0])
    links.new(add_half_u.outputs[0], combine.inputs["X"])
    links.new(add_half_v.outputs[0], combine.inputs["Y"])
    links.new(combine.outputs["Vector"], group_output.inputs["Image Coordinates"])

    return group


def _configure_coordinate_drivers(
    coordinate_node: bpy.types.ShaderNodeGroup,
    controller: bpy.types.Object,
) -> None:
    add_transform_driver(coordinate_node.inputs["Center U"], controller, 'LOC_X')
    add_transform_driver(coordinate_node.inputs["Center V"], controller, 'LOC_Y')
    add_transform_driver(coordinate_node.inputs["Rotation"], controller, 'ROT_Z')
    add_transform_driver(
        coordinate_node.inputs["Width"],
        controller,
        'SCALE_X',
        "abs(v) * 2.0 + 1e-8",
    )
    add_transform_driver(
        coordinate_node.inputs["Height"],
        controller,
        'SCALE_Y',
        "abs(v) * 2.0 + 1e-8",
    )


COLOR_MIX_NODE_NAME = f"{NODE_PREFIX}COLOR_MIX"


def _available_socket(sockets, name: str, socket_type: str):
    candidates = [
        socket for socket in sockets
        if socket.name == name and getattr(socket, "type", "") == socket_type
    ]
    for socket in candidates:
        if not getattr(socket, "is_unavailable", False):
            return socket
    return candidates[-1] if candidates else None


def _mix_color_sockets(node):
    factor = _available_socket(node.inputs, "Factor", 'VALUE')
    color_a = _available_socket(node.inputs, "A", 'RGBA')
    color_b = _available_socket(node.inputs, "B", 'RGBA')
    result = _available_socket(node.outputs, "Result", 'RGBA')

    # Stable fallbacks used by ShaderNodeMix in Blender 4.x/5.x.
    factor = factor or (node.inputs[0] if len(node.inputs) > 0 else None)
    color_a = color_a or (node.inputs[6] if len(node.inputs) > 6 else None)
    color_b = color_b or (node.inputs[7] if len(node.inputs) > 7 else None)
    result = result or (node.outputs[2] if len(node.outputs) > 2 else node.outputs[0])
    return factor, color_a, color_b, result


def _configure_mix_color(node, blend_mode: str) -> None:
    node.data_type = 'RGBA'
    try:
        node.blend_type = blend_mode
    except (TypeError, ValueError):
        node.blend_type = 'MIX'
    if hasattr(node, "clamp_factor"):
        node.clamp_factor = True

    factor, color_a, _color_b, _result = _mix_color_sockets(node)
    if factor is not None:
        factor.default_value = 1.0
    if color_a is not None:
        # White paper/substrate is the neutral base used by artistic blend modes.
        color_a.default_value = (1.0, 1.0, 1.0, 1.0)


def create_label_material(
    label: bpy.types.Object,
    controller: bpy.types.Object,
    image: bpy.types.Image,
    roughness: float,
    metallic: float,
    blend_mode: str = 'MIX',
) -> bpy.types.Material:
    old_material = label.data.materials[0] if label.data.materials else None

    material = bpy.data.materials.new(f"{label.name}_Material")
    material.use_nodes = True
    material.use_backface_culling = False

    if hasattr(material, "surface_render_method"):
        for method in ('DITHERED', 'BLENDED'):
            try:
                material.surface_render_method = method
                break
            except Exception:
                continue
    if hasattr(material, "use_transparency_overlap"):
        try:
            material.use_transparency_overlap = False
        except Exception:
            pass

    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()

    uv_map = nodes.new("ShaderNodeUVMap")
    uv_map.name = f"{NODE_PREFIX}UV_MAP"
    uv_map.label = "Metric UV"
    uv_map.uv_map = UV_NAME
    uv_map.location = (-820, 80)

    coordinate_node = nodes.new("ShaderNodeGroup")
    coordinate_node.name = COORD_NODE_NAME
    coordinate_node.label = "Placement and Size"
    coordinate_node.node_tree = ensure_coordinate_group()
    coordinate_node.location = (-600, 80)
    coordinate_node.width = 220
    _configure_coordinate_drivers(coordinate_node, controller)

    image_node = nodes.new("ShaderNodeTexImage")
    image_node.name = f"{NODE_PREFIX}IMAGE"
    image_node.label = "LABEL IMAGE"
    image_node.location = (-320, 80)
    image_node.image = image
    image_node.extension = 'CLIP'
    image_node.interpolation = 'Linear'

    color_mix = nodes.new("ShaderNodeMix")
    color_mix.name = COLOR_MIX_NODE_NAME
    color_mix.label = "Blend Mode"
    color_mix.location = (-60, 100)
    color_mix.width = 180
    _configure_mix_color(color_mix, blend_mode)
    mix_factor, _mix_a, mix_b, mix_result = _mix_color_sockets(color_mix)

    surface_frame = nodes.new("NodeFrame")
    surface_frame.name = f"{NODE_PREFIX}SURFACE_FRAME"
    surface_frame.label = "Material: Printed Face / White Back"
    surface_frame.location = (180, -120)

    geometry_node = nodes.new("ShaderNodeNewGeometry")
    geometry_node.name = f"{NODE_PREFIX}GEOMETRY"
    geometry_node.parent = surface_frame
    geometry_node.location = (0, 260)

    front_principled = nodes.new("ShaderNodeBsdfPrincipled")
    front_principled.name = f"{NODE_PREFIX}PRINCIPLED"
    front_principled.label = "Printed Face"
    front_principled.parent = surface_frame
    front_principled.location = (0, 70)
    front_principled.inputs["Roughness"].default_value = roughness
    front_principled.inputs["Metallic"].default_value = metallic

    back_principled = nodes.new("ShaderNodeBsdfPrincipled")
    back_principled.name = f"{NODE_PREFIX}BACK_PRINCIPLED"
    back_principled.label = "White Adhesive Back"
    back_principled.parent = surface_frame
    back_principled.location = (0, -130)
    back_principled.inputs["Base Color"].default_value = (1.0, 1.0, 1.0, 1.0)
    back_principled.inputs["Roughness"].default_value = 0.5
    back_principled.inputs["Metallic"].default_value = 0.0

    side_mix = nodes.new("ShaderNodeMixShader")
    side_mix.name = f"{NODE_PREFIX}SIDE_MIX"
    side_mix.label = "Front / Back"
    side_mix.parent = surface_frame
    side_mix.location = (280, 80)

    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.name = f"{NODE_PREFIX}TRANSPARENT"
    transparent.parent = surface_frame
    transparent.location = (280, -120)

    alpha_mix = nodes.new("ShaderNodeMixShader")
    alpha_mix.name = f"{NODE_PREFIX}ALPHA_MIX"
    alpha_mix.label = "Alpha Cutout"
    alpha_mix.parent = surface_frame
    alpha_mix.location = (510, 60)

    output = nodes.new("ShaderNodeOutputMaterial")
    output.name = f"{NODE_PREFIX}OUTPUT"
    output.location = (1050, 80)

    links.new(uv_map.outputs["UV"], coordinate_node.inputs["Metric UV"])
    links.new(coordinate_node.outputs["Image Coordinates"], image_node.inputs["Vector"])
    if mix_b is not None:
        links.new(image_node.outputs["Color"], mix_b)
    if mix_result is not None:
        links.new(mix_result, front_principled.inputs["Base Color"])
    else:
        links.new(image_node.outputs["Color"], front_principled.inputs["Base Color"])

    # Backfacing = 0 on the printed face and 1 on the glued face.
    links.new(geometry_node.outputs["Backfacing"], side_mix.inputs[0])
    links.new(front_principled.outputs[0], side_mix.inputs[1])
    links.new(back_principled.outputs[0], side_mix.inputs[2])

    # The image alpha cuts both sides; the support geometry remains invisible
    # outside the physical label rectangle.
    links.new(image_node.outputs["Alpha"], alpha_mix.inputs[0])
    links.new(transparent.outputs[0], alpha_mix.inputs[1])
    links.new(side_mix.outputs[0], alpha_mix.inputs[2])
    links.new(alpha_mix.outputs[0], output.inputs["Surface"])

    label.data.materials.clear()
    label.data.materials.append(material)
    if old_material is not None and old_material != material and old_material.users == 0:
        bpy.data.materials.remove(old_material)
    return material


def set_label_blend_mode(label: bpy.types.Object, blend_mode: str) -> bool:
    material = label.data.materials[0] if label and label.type == 'MESH' and label.data.materials else None
    if material is None or not material.use_nodes:
        return False
    node = material.node_tree.nodes.get(COLOR_MIX_NODE_NAME)
    if node is None or node.bl_idname != 'ShaderNodeMix':
        return False
    _configure_mix_color(node, blend_mode)
    return True


def update_label_material(
    label: bpy.types.Object,
    controller: bpy.types.Object,
    image: bpy.types.Image,
    roughness: float,
    metallic: float,
    blend_mode: str = 'MIX',
) -> None:
    material = label.data.materials[0] if label.data.materials else None
    coordinate_node = None
    if material is not None and material.use_nodes:
        coordinate_node = material.node_tree.nodes.get(COORD_NODE_NAME)

    needs_rebuild = (
        material is None
        or not material.use_nodes
        or coordinate_node is None
        or coordinate_node.node_tree is None
        or not _coordinate_group_is_valid(coordinate_node.node_tree)
        or material.node_tree.nodes.get(f"{NODE_PREFIX}BACK_PRINCIPLED") is None
        or material.node_tree.nodes.get(f"{NODE_PREFIX}IMAGE") is None
        or material.node_tree.nodes.get(COLOR_MIX_NODE_NAME) is None
    )
    if needs_rebuild:
        create_label_material(label, controller, image, roughness, metallic, blend_mode)
        return

    material.use_backface_culling = False
    coordinate_node.node_tree = ensure_coordinate_group()
    _configure_coordinate_drivers(coordinate_node, controller)

    image_node = material.node_tree.nodes.get(f"{NODE_PREFIX}IMAGE")
    image_node.image = image

    principled = material.node_tree.nodes.get(f"{NODE_PREFIX}PRINCIPLED")
    if principled:
        if "Roughness" in principled.inputs:
            principled.inputs["Roughness"].default_value = roughness
        if "Metallic" in principled.inputs:
            principled.inputs["Metallic"].default_value = metallic

    back = material.node_tree.nodes.get(f"{NODE_PREFIX}BACK_PRINCIPLED")
    if back:
        back.inputs["Base Color"].default_value = (1.0, 1.0, 1.0, 1.0)
        back.inputs["Roughness"].default_value = 0.5
        back.inputs["Metallic"].default_value = 0.0

    set_label_blend_mode(label, blend_mode)
