from __future__ import annotations

import math
import os

import bpy
import bmesh
from bpy.props import EnumProperty
from bpy.types import Operator

from . import materials, registry
from .utils import (
    build_metric_uv,
    configure_surface_follow,
    copy_selected_faces,
    current_view_right,
    ensure_collection,
    ensure_rig_parenting,
    label_fit_report,
    load_image,
    migrate_legacy_label,
    reference_from_label,
    remove_object_and_data,
    resolve_rig_from_object,
    select_only,
    selected_face_island_count,
    store_uv_analysis,
    unique_label_name,
    create_controller_rig,
)


def _resolved_image(path: str, existing: bpy.types.Image | None, pack: bool) -> bpy.types.Image:
    if path:
        absolute = bpy.path.abspath(path)
        if os.path.isfile(absolute):
            return load_image(path, pack)
        if existing is None:
            raise FileNotFoundError("Image file not found.")
    if existing is None:
        raise FileNotFoundError("No image is associated with this label.")
    if pack and not existing.packed_file:
        existing.pack()
    return existing


def _apply_ratio(
    width: float,
    height: float,
    preserve_ratio: bool,
    image: bpy.types.Image,
    reference_axis: str = 'WIDTH',
) -> tuple[float, float]:
    if preserve_ratio and image.size[0] > 0 and image.size[1] > 0:
        ratio = image.size[0] / image.size[1]
        if reference_axis == 'HEIGHT':
            width = height * ratio
        else:
            height = width / ratio
    return max(width, 1e-6), max(height, 1e-6)


class JB3D_LABELER_OT_create_from_selection(Operator):
    bl_idname = "jb3d_labeler.create_from_selection"
    bl_label = "Create Label from Selection"
    bl_description = "Duplicate the selected faces and create metric UVs, a material and a controller"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        source = context.active_object
        settings = context.scene.jb3d_labeler

        try:
            image = load_image(settings.image_path, settings.pack_image)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(source.data)
        selected_faces = [face for face in bm.faces if face.select]
        if not selected_faces:
            self.report({'ERROR'}, "Select at least one face in Edit Mode.")
            return {'CANCELLED'}
        if selected_face_island_count(bm) != 1:
            self.report({'ERROR'}, "The selection must form one connected region.")
            return {'CANCELLED'}

        width, height = _apply_ratio(
            settings.width,
            settings.height,
            settings.preserve_ratio,
            image,
            settings.last_edited_dimension,
        )
        settings.ratio_update_lock = True
        try:
            settings.image = image
            settings.image_pixel_width = int(image.size[0])
            settings.image_pixel_height = int(image.size[1])
            settings.width = width
            settings.height = height
        finally:
            settings.ratio_update_lock = False

        collection = ensure_collection(context)
        label_name = unique_label_name()
        label = None
        anchor = None
        controller = None

        try:
            label, reference = copy_selected_faces(
                source,
                collection,
                label_name,
                current_view_right(context),
            )
            bpy.ops.object.mode_set(mode='OBJECT')

            used_method = build_metric_uv(
                context,
                label,
                settings.unwrap_method,
                settings.orientation_mode,
                reference,
            )

            frame_offset = configure_surface_follow(
                context,
                label,
                source,
                settings.follow_surface,
                settings.surface_offset,
            )

            anchor, controller = create_controller_rig(
                collection=collection,
                label=label,
                source=source,
                image=image,
                image_path=image.filepath or settings.image_path,
                width=width,
                height=height,
                preserve_ratio=settings.preserve_ratio,
                surface_offset=settings.surface_offset,
                follow_surface=settings.follow_surface,
                unwrap_method=settings.unwrap_method,
                orientation_mode=settings.orientation_mode,
                roughness=settings.roughness,
                metallic=settings.metallic,
                pack_image=settings.pack_image,
                reference=reference,
                frame_offset=frame_offset,
            )
            label.jb3d_labeler.last_unwrap_used = used_method

            materials.create_label_material(
                label,
                controller,
                image,
                settings.roughness,
                settings.metallic,
                'MIX',
            )

            analysis = store_uv_analysis(label)
            label.show_in_front = False
            label.display_type = 'TEXTURED'
            registry.register_label(context.scene, label, at_top=True)
            registry.apply_stack_order(context, context.scene)

            select_only(context, controller)
            rig = resolve_rig_from_object(controller)
            fit = label_fit_report(rig)
            fit_text = "valid size" if fit.fits else "exceeds the selected area"
            self.report(
                {'INFO'},
                f"Label created ({used_method}) — distortion {analysis.rms:.1f}%, {fit_text}.",
            )
            return {'FINISHED'}

        except Exception as exc:
            for obj in (controller, anchor, label):
                remove_object_and_data(obj)
            if source and source.name in bpy.data.objects:
                select_only(context, source)
            self.report({'ERROR'}, f"Cannot create label: {exc}")
            return {'CANCELLED'}


class JB3D_LABELER_OT_update_active(Operator):
    bl_idname = "jb3d_labeler.update_active"
    bl_label = "Update Label"
    bl_description = "Update the image, dimensions, material, modifiers and unwrap when needed"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None

    def execute(self, context):
        original_active = context.active_object
        rig = registry.active_rig(context)
        if rig is None or rig.controller is None:
            self.report({'ERROR'}, "Incomplete label rig.")
            return {'CANCELLED'}

        ensure_rig_parenting(rig)
        data = rig.label.jb3d_labeler
        try:
            image = _resolved_image(data.image_path, data.image, data.pack_image)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        width, height = _apply_ratio(
            data.width,
            data.height,
            data.preserve_ratio,
            image,
            data.last_edited_dimension,
        )
        data.ratio_update_lock = True
        try:
            data.width = width
            data.height = height
            data.image = image
            data.image_pixel_width = int(image.size[0])
            data.image_pixel_height = int(image.size[1])
            if image.filepath:
                data.image_path = image.filepath
        finally:
            data.ratio_update_lock = False

        rig.controller.scale.x = width * 0.5
        rig.controller.scale.y = height * 0.5
        rig.controller["jb3d_image_name"] = image.name
        rig.label["jb3d_image_name"] = image.name
        rig.label["jb3d_original_width"] = width
        rig.label["jb3d_original_height"] = height

        materials.update_label_material(
            rig.label,
            rig.controller,
            image,
            data.roughness,
            data.metallic,
            data.blend_mode,
        )

        uv_rebuilt = False
        used_method = data.last_unwrap_used
        if (
            data.unwrap_method != data.applied_unwrap_method
            or data.orientation_mode != data.applied_orientation_mode
        ):
            reference = reference_from_label(rig.label, current_view_right(context))
            used_method = build_metric_uv(
                context,
                rig.label,
                data.unwrap_method,
                data.orientation_mode,
                reference,
            )
            data.last_unwrap_used = used_method
            data.applied_unwrap_method = data.unwrap_method
            data.applied_orientation_mode = data.orientation_mode
            uv_rebuilt = True

        store_uv_analysis(rig.label)
        registry.apply_stack_order(context, context.scene)

        if original_active and original_active.name in bpy.data.objects:
            select_only(context, original_active)
        fit = label_fit_report(rig)
        uv_text = f" — UV rebuilt with {used_method}" if uv_rebuilt else ""
        if fit.fits:
            self.report({'INFO'}, f"Label updated{uv_text} — it fits the selected area.")
        else:
            self.report({'WARNING'}, f"Label updated{uv_text}, but it exceeds the selected area.")
        return {'FINISHED'}


class JB3D_LABELER_OT_rebuild_uv(Operator):
    bl_idname = "jb3d_labeler.rebuild_uv"
    bl_label = "Rebuild UVs"
    bl_description = "Rebuild the unwrap using the stored reference face and edge"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.label.type == 'MESH'

    def execute(self, context):
        original_active = context.active_object
        rig = registry.active_rig(context)
        ensure_rig_parenting(rig)
        data = rig.label.jb3d_labeler
        reference = reference_from_label(rig.label, current_view_right(context))

        try:
            used_method = build_metric_uv(
                context,
                rig.label,
                data.unwrap_method,
                data.orientation_mode,
                reference,
            )
            data.last_unwrap_used = used_method
            data.applied_unwrap_method = data.unwrap_method
            data.applied_orientation_mode = data.orientation_mode
            if rig.controller:
                rig.controller.location.x = 0.0
                rig.controller.location.y = 0.0
                rig.controller.rotation_euler.z = 0.0
                rig.controller.scale.x = data.width * 0.5
                rig.controller.scale.y = data.height * 0.5
            analysis = store_uv_analysis(rig.label)
            registry.apply_stack_order(context, context.scene)
        except Exception as exc:
            self.report({'ERROR'}, f"Cannot rebuild UVs: {exc}")
            return {'CANCELLED'}

        if original_active and original_active.name in bpy.data.objects:
            select_only(context, original_active)
        self.report({'INFO'}, f"UVs rebuilt with {used_method} — distortion {analysis.rms:.1f}%.")
        return {'FINISHED'}


class JB3D_LABELER_OT_select_controller(Operator):
    bl_idname = "jb3d_labeler.select_controller"
    bl_label = "Select Controller"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.controller is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        select_only(context, rig.controller)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_label(Operator):
    bl_idname = "jb3d_labeler.select_label"
    bl_label = "Select Surface"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        if rig.label.jb3d_labeler.label_locked:
            self.report({'WARNING'}, "Unlock the surface in the label list first.")
            return {'CANCELLED'}
        select_only(context, rig.label)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_anchor(Operator):
    bl_idname = "jb3d_labeler.select_anchor"
    bl_label = "Select Anchor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.anchor is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        if rig.label.jb3d_labeler.anchor_locked:
            self.report({'WARNING'}, "This anchor is locked.")
            return {'CANCELLED'}
        select_only(context, rig.anchor)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_source(Operator):
    bl_idname = "jb3d_labeler.select_source"
    bl_label = "Select Product"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.source is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        select_only(context, rig.source)
        return {'FINISHED'}


class JB3D_LABELER_OT_rotate_90(Operator):
    bl_idname = "jb3d_labeler.rotate_90"
    bl_label = "Rotate 90°"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.controller is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        rig.controller.rotation_euler.z += math.radians(90.0)
        return {'FINISHED'}


class JB3D_LABELER_OT_reset_controller(Operator):
    bl_idname = "jb3d_labeler.reset_controller"
    bl_label = "Recenter"
    bl_description = "Move the label back to the stored active face"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.controller is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        rig.controller.location.x = 0.0
        rig.controller.location.y = 0.0
        rig.controller.rotation_euler.z = 0.0
        return {'FINISHED'}


class JB3D_LABELER_OT_repair_links(Operator):
    bl_idname = "jb3d_labeler.repair_links"
    bl_label = "Repair Links"
    bl_description = "Migrate legacy rigs, restore pointers and repair product parenting"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None or context.active_object is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        obj = context.active_object
        if rig is None and obj is not None:
            if obj.get("jb3d_labeler_role") == "LABEL":
                migrate_legacy_label(obj)
            else:
                candidate = resolve_rig_from_object(obj)
                if candidate:
                    migrate_legacy_label(candidate.label)
            rig = resolve_rig_from_object(obj)
        if rig is None:
            self.report({'ERROR'}, "No JB3D Labeler rig detected on this object.")
            return {'CANCELLED'}
        ensure_rig_parenting(rig)
        registry.register_label(context.scene, rig.label, at_top=False)
        data = rig.label.jb3d_labeler
        if rig.controller and data.image:
            materials.update_label_material(
                rig.label, rig.controller, data.image, data.roughness, data.metallic, data.blend_mode
            )
        registry.apply_stack_order(context, context.scene)
        self.report({'INFO'}, "Rig links and parenting verified and migrated to the V1 format.")
        return {'FINISHED'}


class JB3D_LABELER_OT_move_layer(Operator):
    bl_idname = "jb3d_labeler.move_layer"
    bl_label = "Change Stack Order"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(
        items=(
            ('UP', "Move Up", "Place the label above"),
            ('DOWN', "Move Down", "Place the label below"),
        ),
        default='UP',
    )

    @classmethod
    def poll(cls, context):
        return len(context.scene.jb3d_label_items) > 1 and context.mode == 'OBJECT'

    def execute(self, context):
        if not registry.move_active_item(context, self.direction):
            return {'CANCELLED'}
        return {'FINISHED'}


class JB3D_LABELER_OT_refresh_list(Operator):
    bl_idname = "jb3d_labeler.refresh_list"
    bl_label = "Refresh List"
    bl_description = "Find labels in the scene and repair their order"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        registry.sync_scene_label_list(context.scene)
        registry.apply_stack_order(context, context.scene)
        self.report({'INFO'}, "Label list refreshed.")
        return {'FINISHED'}


class JB3D_LABELER_OT_delete_rig(Operator):
    bl_idname = "jb3d_labeler.delete_rig"
    bl_label = "Delete Label"
    bl_description = "Delete the active label surface, material and controllers"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        source = rig.source
        material = rig.label.data.materials[0] if rig.label.data.materials else None

        registry.unregister_label(context.scene, rig.label)
        remove_object_and_data(rig.controller)
        remove_object_and_data(rig.anchor)
        remove_object_and_data(rig.label)

        if material and material.users == 0:
            bpy.data.materials.remove(material)
        if context.scene.jb3d_label_items:
            registry.apply_stack_order(context, context.scene)
        if source and source.name in bpy.data.objects:
            select_only(context, source)
        return {'FINISHED'}


_CLASSES = (
    JB3D_LABELER_OT_create_from_selection,
    JB3D_LABELER_OT_update_active,
    JB3D_LABELER_OT_rebuild_uv,
    JB3D_LABELER_OT_select_controller,
    JB3D_LABELER_OT_select_label,
    JB3D_LABELER_OT_select_anchor,
    JB3D_LABELER_OT_select_source,
    JB3D_LABELER_OT_rotate_90,
    JB3D_LABELER_OT_reset_controller,
    JB3D_LABELER_OT_repair_links,
    JB3D_LABELER_OT_move_layer,
    JB3D_LABELER_OT_refresh_list,
    JB3D_LABELER_OT_delete_rig,
)


def _registered_class(cls):
    if getattr(cls, "is_registered", False):
        return cls
    for base in cls.__bases__:
        for candidate in base.__subclasses__():
            if candidate.__name__ == cls.__name__ and candidate.__module__ == cls.__module__:
                if getattr(candidate, "is_registered", False):
                    return candidate
    return None


def _unregister_classes() -> None:
    for cls in reversed(_CLASSES):
        registered = _registered_class(cls)
        if registered is not None:
            bpy.utils.unregister_class(registered)


def register():
    if all(_registered_class(cls) is cls for cls in _CLASSES):
        return

    _unregister_classes()
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    _unregister_classes()
