from __future__ import annotations

import bpy
from bpy.types import Panel, UIList

from . import registry
from .utils import (
    format_distance,
    label_fit_report,
    resolve_rig_from_object,
    source_subdivision_modifier,
)


def _draw_image_info(layout, data, *, compact: bool = False) -> None:
    if data.image_pixel_width <= 0 or data.image_pixel_height <= 0:
        return
    text = f"{data.image_pixel_width} × {data.image_pixel_height} px"
    if compact:
        layout.label(text=text, icon='IMAGE_DATA')
    else:
        layout.label(text=f"Detected image: {text}", icon='IMAGE_DATA')


class JB3D_LABELER_UL_labels(UIList):
    bl_idname = "JB3D_LABELER_UL_labels"

    def draw_item(
        self,
        context,
        layout,
        data,
        item,
        icon,
        active_data,
        active_propname,
        index=0,
    ):
        label = item.label
        if label is None:
            layout.label(text="Label not found", icon='ERROR')
            return

        settings = label.jb3d_labeler
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            split = row.split(factor=0.38, align=True)
            split.prop(label, "name", text="", emboss=False, icon='IMAGE_DATA', translate=False)

            controls = split.row(align=True)
            controls.prop(
                settings,
                "visible",
                text="",
                emboss=False,
                icon='HIDE_OFF' if settings.visible else 'HIDE_ON',
            )
            controls.prop(
                settings,
                "label_locked",
                text="",
                emboss=False,
                icon='RESTRICT_SELECT_ON' if settings.label_locked else 'RESTRICT_SELECT_OFF',
            )
            controls.prop(
                settings,
                "anchor_locked",
                text="",
                emboss=False,
                icon='LOCKED' if settings.anchor_locked else 'UNLOCKED',
            )
            controls.prop(settings, "blend_mode", text="")
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')


class JB3D_LABELER_PT_main(Panel):
    bl_label = "JB3D Labeler"
    bl_idname = "JB3D_LABELER_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "JB3D"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        defaults = scene.jb3d_labeler

        # ------------------------------------------------------------------
        # Label manager
        # ------------------------------------------------------------------
        manager = layout.box()
        title = manager.row(align=True)
        title.label(text=f"Labels ({len(scene.jb3d_label_items)})", icon='IMAGE_DATA')
        title.operator("jb3d_labeler.refresh_list", text="", icon='FILE_REFRESH')

        header = manager.row(align=True)
        header_split = header.split(factor=0.38, align=True)
        header_split.label(text="Name")
        header_controls = header_split.row(align=True)
        header_controls.label(text="", icon='HIDE_OFF')
        header_controls.label(text="", icon='RESTRICT_SELECT_ON')
        header_controls.label(text="", icon='EMPTY_AXIS')
        header_controls.label(text="Blend")

        list_row = manager.row()
        list_row.template_list(
            "JB3D_LABELER_UL_labels",
            "",
            scene,
            "jb3d_label_items",
            scene,
            "jb3d_label_index",
            rows=5,
        )
        buttons = list_row.column(align=True)
        op = buttons.operator("jb3d_labeler.move_layer", text="", icon='TRIA_UP')
        op.direction = 'UP'
        op = buttons.operator("jb3d_labeler.move_layer", text="", icon='TRIA_DOWN')
        op.direction = 'DOWN'
        buttons.separator()
        buttons.operator("jb3d_labeler.delete_rig", text="", icon='TRASH')

        footer = manager.row(align=True)
        footer.scale_y = 0.8
        footer.label(text="Top = Above · Surface Locked · Anchor Free", icon='TRIA_UP')

        # ------------------------------------------------------------------
        # New label
        # ------------------------------------------------------------------
        create_box = layout.box()
        create_box.label(text="New Label", icon='ADD')
        create_box.prop(defaults, "image_path", text="Image")
        _draw_image_info(create_box, defaults, compact=True)

        size_row = create_box.row(align=True)
        size_row.prop(defaults, "width")
        size_row.prop(defaults, "height")
        create_box.prop(defaults, "preserve_ratio")

        advanced_header = create_box.row(align=True)
        advanced_header.prop(
            defaults,
            "show_create_advanced",
            text="Advanced Options",
            icon='TRIA_DOWN' if defaults.show_create_advanced else 'TRIA_RIGHT',
            emboss=False,
        )
        if defaults.show_create_advanced:
            advanced = create_box.column(align=True)
            row = advanced.row(align=True)
            row.prop(defaults, "unwrap_method")
            row.prop(defaults, "orientation_mode")
            row = advanced.row(align=True)
            row.prop(defaults, "surface_offset")
            row.prop(defaults, "follow_surface")
            row = advanced.row(align=True)
            row.prop(defaults, "roughness")
            row.prop(defaults, "metallic")
            advanced.prop(defaults, "pack_image")

        create_box.operator(
            "jb3d_labeler.create_from_selection",
            text="Create from Selected Faces",
            icon='UV_FACESEL',
        )
        if context.mode != 'EDIT_MESH':
            hint = create_box.row()
            hint.scale_y = 0.8
            hint.label(text="Select the product and its faces in Edit Mode", icon='INFO')

        # ------------------------------------------------------------------
        # Active label
        # ------------------------------------------------------------------
        label = registry.active_label(scene)
        rig = resolve_rig_from_object(label)
        if rig is None:
            return

        data = rig.label.jb3d_labeler
        active_box = layout.box()
        name_row = active_box.row(align=True)
        name_row.label(text="Active Label", icon='IMAGE_DATA')
        name_row.prop(rig.label, "name", text="")

        quick = active_box.row(align=True)
        quick.operator("jb3d_labeler.select_anchor", text="Anchor", icon='EMPTY_AXIS')
        quick.operator("jb3d_labeler.select_controller", text="Controller", icon='EMPTY_AXIS')
        quick.operator("jb3d_labeler.select_source", text="Product", icon='OBJECT_DATA')

        active_box.prop(data, "image_path", text="Image")
        _draw_image_info(active_box, data, compact=True)
        row = active_box.row(align=True)
        row.prop(data, "width")
        row.prop(data, "height")
        active_box.prop(data, "preserve_ratio")

        tools = active_box.row(align=True)
        tools.operator("jb3d_labeler.rotate_90", text="Rotate 90°", icon='FILE_REFRESH')
        tools.operator("jb3d_labeler.reset_controller", text="Recenter", icon='PIVOT_CURSOR')

        active_box.operator(
            "jb3d_labeler.update_active",
            text="Update Label",
            icon='CHECKMARK',
        )

        advanced_header = active_box.row(align=True)
        advanced_header.prop(
            defaults,
            "show_active_advanced",
            text="Advanced Settings",
            icon='TRIA_DOWN' if defaults.show_active_advanced else 'TRIA_RIGHT',
            emboss=False,
        )
        if defaults.show_active_advanced:
            advanced = active_box.column(align=True)
            row = advanced.row(align=True)
            row.prop(data, "unwrap_method")
            row.prop(data, "orientation_mode")
            row = advanced.row(align=True)
            row.prop(data, "surface_offset")
            row.prop(data, "follow_surface")
            row = advanced.row(align=True)
            row.prop(data, "roughness")
            row.prop(data, "metallic")
            advanced.prop(data, "pack_image")

            source_subsurf = source_subdivision_modifier(rig.source)
            if source_subsurf is not None:
                advanced.label(
                    text=f"Synchronized Subdivision: {source_subsurf.name}",
                    icon='MOD_SUBSURF',
                )

            fit = label_fit_report(rig)
            status = advanced.box()
            if rig.controller:
                width = abs(rig.controller.scale.x) * 2.0
                height = abs(rig.controller.scale.y) * 2.0
                status.label(
                    text=(
                        f"Size: {format_distance(scene, width)} × "
                        f"{format_distance(scene, height)}"
                    )
                )
            distortion_icon = 'CHECKMARK' if data.distortion_rms < 5.0 else ('ERROR' if data.distortion_rms >= 12.0 else 'INFO')
            status.label(text=f"Distortion: {data.distortion_rms:.1f}%", icon=distortion_icon)
            if fit.fits:
                status.label(text="Label fits the support area", icon='CHECKMARK')
            else:
                status.label(
                    text=f"Overflow: {format_distance(scene, fit.overflow)}",
                    icon='ERROR',
                )

        maintenance_header = active_box.row(align=True)
        maintenance_header.prop(
            defaults,
            "show_maintenance",
            text="Maintenance",
            icon='TRIA_DOWN' if defaults.show_maintenance else 'TRIA_RIGHT',
            emboss=False,
        )
        if defaults.show_maintenance:
            maintenance = active_box.column(align=True)
            maintenance.operator("jb3d_labeler.rebuild_uv", text="Force UV Rebuild", icon='FILE_REFRESH')
            maintenance.operator("jb3d_labeler.repair_links", text="Check Links and Parenting", icon='LINKED')
            row = maintenance.row()
            row.enabled = not data.label_locked
            row.operator("jb3d_labeler.select_label", text="Select Surface", icon='MESH_GRID')
            maintenance.operator("jb3d_labeler.delete_rig", text="Delete Label", icon='TRASH')


_CLASSES = (
    JB3D_LABELER_UL_labels,
    JB3D_LABELER_PT_main,
)


def _registered_class(cls):
    if getattr(cls, "is_registered", False):
        return cls
    for base in cls.__bases__:
        for candidate in base.__subclasses__():
            if candidate.__name__ == cls.__name__ and candidate.__module__ == cls.__module__:
                if getattr(candidate, "is_registered", False):
                    return candidate
    return None


def _unregister_classes() -> None:
    for cls in reversed(_CLASSES):
        registered = _registered_class(cls)
        if registered is not None:
            bpy.utils.unregister_class(registered)


def register():
    if all(_registered_class(cls) is cls for cls in _CLASSES):
        return

    _unregister_classes()
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    _unregister_classes()
