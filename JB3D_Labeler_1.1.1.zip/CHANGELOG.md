# Changelog

## 1.1.1

- Converted the package cleanly to the Blender Extension format by removing legacy `bl_info` metadata.
- Added explicit GPL-3.0-or-later licensing information and SPDX headers.
- Prevented JB3D Labeler from deleting unrelated user node groups when an internal node-group name collides.
- Added persistent ownership markers for managed shader node groups.
- Removed a redundant module-level registry state assignment.
- Verified the code path against Blender 4.5-era APIs and lowered the minimum supported version to Blender 4.5.0 LTS; Blender 5.x remains supported.
- No changes to the saved label data schema; existing 1.0.0 and 1.1.0 labels remain compatible.

## 1.1.0

- Added a **360° Wrap** label type for bottles, cans, jars, tubes, and similar packaging.
- Added automatic detection of continuous closed quad bands.
- Added automatic back-seam placement based on the active face.
- Added optional seam placement from the active vertical edge.
- Added automatic or local-axis band detection.
- Added circumference, height, top/bottom length, and taper measurements.
- Added warnings for image-ratio mismatch and tapered surfaces.
- Added horizontal and vertical artwork offsets through the existing controller.
- Added the shared **JB3D Wrap Coordinates v1** shader node group.
- Preserved subdivision-before-shrinkwrap, white label backs, parenting, stacking, visibility, locking, and blend modes.
- Existing 1.0.0 labels are migrated as Standard labels.

## 1.0.0

- Initial public release.
