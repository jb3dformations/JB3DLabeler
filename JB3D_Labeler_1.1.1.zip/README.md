# JB3D Labeler

JB3D Labeler creates editable product labels from selected mesh faces.

## Standard Labels

Select a connected support area, choose an image and physical dimensions, then create the label. The generated surface, UVs, material, controller, parenting, subdivision and shrinkwrap remain editable.

## 360° Wrap Labels

1. Select **360° Wrap** in the creation panel.
2. In Edit Mode, select one continuous quad face band around the product.
3. Make one face active; it defines the front of the artwork.
4. For **Active Edge** seam mode, select a vertical band edge last.
5. Create the label.

The artwork is mapped exactly once from U=0 to U=1. Move the controller on local X to slide the artwork around the circumference and on local Y to move it vertically.

### Current Topology Requirements

The 360° workflow requires a clean quad band with exactly two closed boundary loops and no branches, poles, isolated faces, or extra face islands. Slightly tapered bands are supported and reported.

## Permissions

The extension requests file access only to load label images explicitly selected by the user. It does not use network access or external Python dependencies.

## Compatibility

Version 1.1.1 targets Blender 4.5.0 LTS or newer, including Blender 5.x, and keeps existing 1.0.0 and 1.1.0 labels compatible.

## License

JB3D Labeler is licensed under GPL-3.0-or-later. See `LICENSE`.
