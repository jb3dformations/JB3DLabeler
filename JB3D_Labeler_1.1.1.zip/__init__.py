# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from . import operators, properties, registry, ui


def register():
    properties.register()
    registry.register()
    operators.register()
    ui.register()


def unregister():
    ui.unregister()
    operators.unregister()
    registry.unregister()
    properties.unregister()
