# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import bpy
from mathutils import Vector

from .utils import UV_NAME, SelectionReference, ensure_uv_layer


@dataclass
class WrapMeasurements:
    circumference: float
    top_length: float
    bottom_length: float
    height: float
    taper_percentage: float
    physical_ratio: float


@dataclass
class WrapResult:
    measurements: WrapMeasurements
    seam_column: int
    active_column: int
    active_row: int
    anchor_uv: Vector
    axis_world: Vector


def _edge_key(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a < b else (b, a)


def _world_point(obj: bpy.types.Object, vertex_index: int) -> Vector:
    return obj.matrix_world @ obj.data.vertices[vertex_index].co


def _edge_length(obj: bpy.types.Object, a: int, b: int) -> float:
    return (_world_point(obj, b) - _world_point(obj, a)).length


def _polygon_edge_maps(mesh: bpy.types.Mesh):
    edge_faces: dict[tuple[int, int], list[int]] = {}
    face_edges: dict[int, list[tuple[int, int]]] = {}
    for poly in mesh.polygons:
        vertices = list(poly.vertices)
        keys = []
        for index, a in enumerate(vertices):
            b = vertices[(index + 1) % len(vertices)]
            key = _edge_key(a, b)
            keys.append(key)
            edge_faces.setdefault(key, []).append(poly.index)
        face_edges[poly.index] = keys
    return edge_faces, face_edges


def _ordered_boundary_loops(mesh: bpy.types.Mesh) -> list[list[int]]:
    edge_faces, _face_edges = _polygon_edge_maps(mesh)
    boundary = [edge for edge, faces in edge_faces.items() if len(faces) == 1]
    if not boundary:
        raise ValueError("The selection has no open top and bottom boundaries.")

    adjacency: dict[int, list[int]] = {}
    for a, b in boundary:
        adjacency.setdefault(a, []).append(b)
        adjacency.setdefault(b, []).append(a)

    if any(len(neighbours) != 2 for neighbours in adjacency.values()):
        raise ValueError("The boundary is branched. Select one clean face band.")

    loops: list[list[int]] = []
    remaining = set(boundary)
    while remaining:
        first_edge = next(iter(remaining))
        start, current = first_edge
        previous = start
        ordered = [start]
        safety = 0
        while current != start:
            safety += 1
            if safety > len(boundary) + 2:
                raise ValueError("Cannot order the boundary loops.")
            ordered.append(current)
            remaining.discard(_edge_key(previous, current))
            neighbours = adjacency[current]
            next_vertex = neighbours[0] if neighbours[0] != previous else neighbours[1]
            previous, current = current, next_vertex
        remaining.discard(_edge_key(previous, start))
        if len(ordered) < 3:
            raise ValueError("A boundary loop is too small.")
        loops.append(ordered)

    if len(loops) != 2:
        raise ValueError("Select one face band between exactly two boundary loops.")
    if len(loops[0]) != len(loops[1]):
        raise ValueError("The top and bottom loops must contain the same number of vertices.")
    return loops


def _loop_center(obj: bpy.types.Object, loop: list[int]) -> Vector:
    return sum((_world_point(obj, index) for index in loop), Vector()) / len(loop)


def _local_axis_world(obj: bpy.types.Object, axis_mode: str) -> Optional[Vector]:
    axis_map = {
        'LOCAL_X': Vector((1.0, 0.0, 0.0)),
        'LOCAL_Y': Vector((0.0, 1.0, 0.0)),
        'LOCAL_Z': Vector((0.0, 0.0, 1.0)),
    }
    local = axis_map.get(axis_mode)
    if local is None:
        return None
    result = obj.matrix_world.to_3x3() @ local
    return result.normalized() if result.length_squared > 1e-16 else None


def _choose_axis_and_boundaries(
    obj: bpy.types.Object,
    loops: list[list[int]],
    axis_mode: str,
) -> tuple[list[int], list[int], Vector]:
    center_a = _loop_center(obj, loops[0])
    center_b = _loop_center(obj, loops[1])
    between = center_b - center_a
    if between.length_squared < 1e-16:
        raise ValueError("The two boundary loops have the same center.")

    requested = _local_axis_world(obj, axis_mode)
    if requested is None:
        axis = between.normalized()
        local_axes = [
            (obj.matrix_world.to_3x3() @ Vector((1.0, 0.0, 0.0))).normalized(),
            (obj.matrix_world.to_3x3() @ Vector((0.0, 1.0, 0.0))).normalized(),
            (obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized(),
        ]
        best = max(local_axes, key=lambda item: abs(item.dot(axis)))
        if axis.dot(best) < 0.0:
            axis.negate()
    else:
        axis = requested
        if abs(axis.dot(between.normalized())) < 0.5:
            raise ValueError("The selected local axis does not match the face band direction.")

    if (center_b - center_a).dot(axis) >= 0.0:
        bottom, top = loops[0], loops[1]
    else:
        bottom, top = loops[1], loops[0]
    return bottom, top, axis


def _face_vertices(mesh: bpy.types.Mesh, face_index: int) -> list[int]:
    return list(mesh.polygons[face_index].vertices)


def _other_neighbour_in_quad(vertices: list[int], vertex: int, excluded: int) -> int:
    index = vertices.index(vertex)
    candidates = (vertices[(index - 1) % 4], vertices[(index + 1) % 4])
    for candidate in candidates:
        if candidate != excluded:
            return candidate
    raise ValueError("Invalid quad topology.")


def _propagate_rings(
    mesh: bpy.types.Mesh,
    start_ring: list[int],
    target_vertices: set[int],
) -> tuple[list[list[int]], list[list[int]]]:
    edge_faces, _face_edges = _polygon_edge_maps(mesh)
    rings = [list(start_ring)]
    face_rows: list[list[int]] = []
    consumed: set[int] = set()
    maximum_rows = len(mesh.polygons) + 1

    for _row in range(maximum_rows):
        current = rings[-1]
        mapping: dict[int, int] = {}
        row_faces: list[int] = []

        for column, a in enumerate(current):
            b = current[(column + 1) % len(current)]
            candidates = [face for face in edge_faces.get(_edge_key(a, b), []) if face not in consumed]
            if len(candidates) != 1:
                raise ValueError("The selection is not a regular continuous quad band.")
            face_index = candidates[0]
            vertices = _face_vertices(mesh, face_index)
            if len(vertices) != 4:
                raise ValueError("360° Wrap currently requires a quad face band.")

            next_a = _other_neighbour_in_quad(vertices, a, b)
            next_b = _other_neighbour_in_quad(vertices, b, a)
            if a in mapping and mapping[a] != next_a:
                raise ValueError("The quad band branches or twists.")
            if b in mapping and mapping[b] != next_b:
                raise ValueError("The quad band branches or twists.")
            mapping[a] = next_a
            mapping[b] = next_b
            row_faces.append(face_index)

        next_ring = [mapping[vertex] for vertex in current]
        if len(set(next_ring)) != len(next_ring):
            raise ValueError("The face band collapses and cannot be unwrapped reliably.")
        consumed.update(row_faces)
        face_rows.append(row_faces)
        rings.append(next_ring)

        if set(next_ring) == target_vertices:
            break
        if set(next_ring) & target_vertices:
            raise ValueError("The face band reaches the opposite boundary inconsistently.")
    else:
        raise ValueError("Cannot propagate the quad band from bottom to top.")

    if consumed != {poly.index for poly in mesh.polygons}:
        raise ValueError("The selection contains faces outside the continuous wrap band.")
    return rings, face_rows


def _polygon_normal_world(obj: bpy.types.Object, face_index: int) -> Vector:
    normal_matrix = obj.matrix_world.to_3x3().inverted_safe().transposed()
    normal = normal_matrix @ obj.data.polygons[face_index].normal
    return normal.normalized() if normal.length_squared > 1e-16 else Vector((0.0, 0.0, 1.0))


def _find_face_cell(face_rows: list[list[int]], face_index: int) -> tuple[int, int]:
    for row, faces in enumerate(face_rows):
        for column, item in enumerate(faces):
            if item == face_index:
                return row, column
    raise ValueError("The active face is not part of the wrap band.")


def _rebuild_face_rows(mesh: bpy.types.Mesh, rings: list[list[int]]) -> list[list[int]]:
    edge_faces, _face_edges = _polygon_edge_maps(mesh)
    rows: list[list[int]] = []
    for row in range(len(rings) - 1):
        current = rings[row]
        next_ring = rings[row + 1]
        next_set = set(next_ring)
        faces = []
        for column, a in enumerate(current):
            b = current[(column + 1) % len(current)]
            candidates = edge_faces.get(_edge_key(a, b), [])
            match = None
            for face_index in candidates:
                verts = set(mesh.polygons[face_index].vertices)
                if len(verts & next_set) == 2:
                    match = face_index
                    break
            if match is None:
                raise ValueError("Cannot rebuild the wrap face grid.")
            faces.append(match)
        rows.append(faces)
    return rows


def _orient_rings(
    obj: bpy.types.Object,
    rings: list[list[int]],
    face_rows: list[list[int]],
    active_face_index: int,
    axis_world: Vector,
) -> tuple[list[list[int]], list[list[int]]]:
    active_row, active_col = _find_face_cell(face_rows, active_face_index)
    ring = rings[active_row]
    tangent = _world_point(obj, ring[(active_col + 1) % len(ring)]) - _world_point(obj, ring[active_col])
    normal = _polygon_normal_world(obj, active_face_index)
    if tangent.length_squared > 1e-16 and tangent.normalized().cross(axis_world).dot(normal) < 0.0:
        rings = [list(reversed(item)) for item in rings]
        face_rows = _rebuild_face_rows(obj.data, rings)
    return rings, face_rows


def _active_edge_seam_column(
    rings: list[list[int]],
    active_edge: Optional[tuple[int, int]],
) -> int:
    if active_edge is None:
        raise ValueError("Select a vertical edge last to define the seam.")
    key = _edge_key(*active_edge)
    column_count = len(rings[0])
    for row in range(len(rings) - 1):
        for column in range(column_count):
            if _edge_key(rings[row][column], rings[row + 1][column]) == key:
                return column
    raise ValueError("The active edge must run across the face band, not around it.")


def _mark_seam(mesh: bpy.types.Mesh, rings: list[list[int]], seam_column: int) -> None:
    seam_keys = {
        _edge_key(rings[row][seam_column], rings[row + 1][seam_column])
        for row in range(len(rings) - 1)
    }
    for edge in mesh.edges:
        edge.use_seam = _edge_key(*edge.vertices) in seam_keys


def _loop_length(obj: bpy.types.Object, ring: list[int]) -> float:
    return sum(
        _edge_length(obj, vertex, ring[(index + 1) % len(ring)])
        for index, vertex in enumerate(ring)
    )


def _measure(obj: bpy.types.Object, rings: list[list[int]]) -> tuple[WrapMeasurements, list[float], list[float]]:
    column_count = len(rings[0])
    ring_lengths = [_loop_length(obj, ring) for ring in rings]

    segment_widths = []
    for column in range(column_count):
        values = [
            _edge_length(obj, ring[column], ring[(column + 1) % column_count])
            for ring in rings
        ]
        segment_widths.append(sum(values) / len(values))

    row_heights = []
    for row in range(len(rings) - 1):
        values = [
            _edge_length(obj, rings[row][column], rings[row + 1][column])
            for column in range(column_count)
        ]
        row_heights.append(sum(values) / len(values))

    column_heights = []
    for column in range(column_count):
        column_heights.append(sum(
            _edge_length(obj, rings[row][column], rings[row + 1][column])
            for row in range(len(rings) - 1)
        ))

    top_length = ring_lengths[-1]
    bottom_length = ring_lengths[0]
    circumference = sum(ring_lengths) / len(ring_lengths)
    height = sum(column_heights) / len(column_heights)
    average_end = max((top_length + bottom_length) * 0.5, 1e-12)
    taper = abs(top_length - bottom_length) / average_end * 100.0
    ratio = circumference / max(height, 1e-12)
    return (
        WrapMeasurements(circumference, top_length, bottom_length, height, taper, ratio),
        segment_widths,
        row_heights,
    )


def _cumulative_normalized(values: list[float]) -> list[float]:
    total = sum(values)
    if total <= 1e-12:
        raise ValueError("The selected face band has zero physical size.")
    result = [0.0]
    running = 0.0
    for value in values:
        running += value
        result.append(running / total)
    result[-1] = 1.0
    return result


def _assign_wrap_uv(
    obj: bpy.types.Object,
    rings: list[list[int]],
    face_rows: list[list[int]],
    seam_column: int,
    segment_widths: list[float],
    row_heights: list[float],
) -> None:
    mesh = obj.data
    uv_layer = ensure_uv_layer(mesh)
    column_count = len(rings[0])

    rotated_widths = [segment_widths[(seam_column + index) % column_count] for index in range(column_count)]
    u_values = _cumulative_normalized(rotated_widths)
    v_values = _cumulative_normalized(row_heights)

    vertex_position: dict[int, tuple[int, int]] = {}
    for row, ring in enumerate(rings):
        for column, vertex in enumerate(ring):
            vertex_position[vertex] = (row, column)

    for row, faces in enumerate(face_rows):
        for column, face_index in enumerate(faces):
            poly = mesh.polygons[face_index]
            relative = (column - seam_column) % column_count
            next_column = (column + 1) % column_count
            for loop_index in poly.loop_indices:
                vertex = mesh.loops[loop_index].vertex_index
                vertex_row, vertex_column = vertex_position[vertex]
                if vertex_column == column:
                    u = u_values[relative]
                elif vertex_column == next_column:
                    u = u_values[relative + 1]
                else:
                    raise ValueError("Unexpected quad vertex while assigning wrap UVs.")
                if vertex_row == row:
                    v = v_values[row]
                elif vertex_row == row + 1:
                    v = v_values[row + 1]
                else:
                    raise ValueError("Unexpected quad row while assigning wrap UVs.")
                uv_layer.data[loop_index].uv = (u, v)

    mesh.update()


def build_wrap_uv(
    obj: bpy.types.Object,
    reference: SelectionReference,
    seam_mode: str = 'AUTO_BACK',
    axis_mode: str = 'AUTO',
) -> WrapResult:
    """Validate and unwrap a closed quad band into one normalized 0–1 island."""
    mesh = obj.data
    if not mesh.polygons:
        raise ValueError("The selection contains no faces.")
    if any(len(poly.vertices) != 4 for poly in mesh.polygons):
        raise ValueError("360° Wrap currently requires a quad face band.")
    if reference.active_face_index < 0 or reference.active_face_index >= len(mesh.polygons):
        raise ValueError("Select an active face to define the front of the label.")

    loops = _ordered_boundary_loops(mesh)
    bottom, top, axis_world = _choose_axis_and_boundaries(obj, loops, axis_mode)
    rings, face_rows = _propagate_rings(mesh, bottom, set(top))
    rings, face_rows = _orient_rings(obj, rings, face_rows, reference.active_face_index, axis_world)
    active_row, active_column = _find_face_cell(face_rows, reference.active_face_index)

    if seam_mode == 'ACTIVE_EDGE':
        seam_column = _active_edge_seam_column(rings, reference.active_edge_vertices)
    else:
        seam_column = (active_column + (len(rings[0]) // 2) + 1) % len(rings[0])

    measurements, segment_widths, row_heights = _measure(obj, rings)
    _mark_seam(mesh, rings, seam_column)
    _assign_wrap_uv(obj, rings, face_rows, seam_column, segment_widths, row_heights)

    active_relative = (active_column - seam_column) % len(rings[0])
    rotated_widths = [segment_widths[(seam_column + index) % len(rings[0])] for index in range(len(rings[0]))]
    u_values = _cumulative_normalized(rotated_widths)
    v_values = _cumulative_normalized(row_heights)
    anchor_uv = Vector(((u_values[active_relative] + u_values[active_relative + 1]) * 0.5,
                        (v_values[active_row] + v_values[active_row + 1]) * 0.5))

    return WrapResult(
        measurements=measurements,
        seam_column=seam_column,
        active_column=active_column,
        active_row=active_row,
        anchor_uv=anchor_uv,
        axis_world=axis_world,
    )


def store_wrap_result(label: bpy.types.Object, result: WrapResult) -> None:
    data = label.jb3d_labeler
    data.wrap_circumference = result.measurements.circumference
    data.wrap_top_length = result.measurements.top_length
    data.wrap_bottom_length = result.measurements.bottom_length
    data.wrap_height = result.measurements.height
    data.taper_percentage = result.measurements.taper_percentage
    data.wrap_physical_ratio = result.measurements.physical_ratio
    data.wrap_seam_column = result.seam_column
    data.wrap_anchor_u = result.anchor_uv.x
    data.wrap_anchor_v = result.anchor_uv.y


def image_ratio_warning(data, image: bpy.types.Image) -> Optional[str]:
    if image is None or image.size[0] <= 0 or image.size[1] <= 0:
        return None
    image_ratio = image.size[0] / image.size[1]
    physical_ratio = max(float(data.wrap_physical_ratio), 1e-12)
    difference = abs(image_ratio / physical_ratio - 1.0)
    if difference > 0.02:
        return "The image ratio differs from the physical surface ratio. The artwork may be distorted."
    return None
