# JB3D Labeler

JB3D Labeler creates editable product labels from selected mesh faces.

## Standard Labels

Select a connected support area, choose an image and physical dimensions, then create the label. The generated surface, UVs, material, controller, parenting, subdivision and shrinkwrap remain editable.

## 360° Wrap Labels

1. Select **360° Wrap** in the creation panel.
2. Choose an image and enable **Preserve Image Ratio** if the artwork must not be stretched.
3. In Edit Mode, select one continuous quad face band around the product.
4. Make one face active; it defines the front of the artwork.
5. For **Active Edge** seam mode, select a vertical band edge last.
6. Create the label.

The selected face band defines the available wrap surface. The artwork itself has its own physical width and height, so it can be resized and repositioned without rebuilding the UVs.

- Move the controller on local X to slide the artwork around the circumference.
- Move it on local Y to move the artwork vertically.
- Use the **Width** and **Height** controls for precise physical sizing.
- Select the controller and use **S** for proportional viewport scaling. Axis scaling is also available; **Update Label** stores the controller scale and restores the source-image ratio when **Preserve Image Ratio** is enabled.
- **Full 360° Width** fits the artwork to one complete circumference.
- **Fit Band Height** fits the artwork to the selected band height.

When **Preserve Image Ratio** is enabled, width and height remain linked to the image proportions so the artwork is not stretched. When disabled, both dimensions can be adjusted independently, reproducing the stretched full-band behavior available in V1.1. Artwork narrower than the circumference behaves as a curved partial label with transparent space around the remaining band. Artwork width is limited to one circumference to avoid overlap at the seam.

If ratio-preserving artwork is taller than the selected face band, it is clipped vertically. The interface reports this condition so the artwork can be scaled down or the selected band can be enlarged. Tapered surfaces can still introduce physical distortion and are reported separately.

### Current Topology Requirements

The 360° workflow requires a clean quad band with exactly two closed boundary loops and no branches, poles, isolated faces, or extra face islands. Slightly tapered bands are supported and reported.

## Compatibility and Migration

Version 1.2.0 targets Blender 4.5.0 LTS or newer, including Blender 5.x. Existing Standard labels remain compatible. 360° Wrap labels created with V1.1 are migrated automatically to the V1.2 physical-size controller while preserving their previous appearance.

## Permissions

The extension requests file access only to load label images explicitly selected by the user. It does not use network access or external Python dependencies.

## License

JB3D Labeler is licensed under GPL-3.0-or-later. See `LICENSE`.
