# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import bpy
from bpy.types import Panel, UIList

from . import registry, wrap
from .utils import (
    format_distance,
    label_fit_report,
    resolve_rig_from_object,
    source_subdivision_modifier,
)


def _draw_image_info(layout, data, *, compact: bool = False) -> None:
    if data.image_pixel_width <= 0 or data.image_pixel_height <= 0:
        return
    text = f"{data.image_pixel_width} × {data.image_pixel_height} px"
    layout.label(text=text if compact else f"Detected image: {text}", icon='IMAGE_DATA')


class JB3D_LABELER_UL_labels(UIList):
    bl_idname = "JB3D_LABELER_UL_labels"

    def draw_item(
        self, context, layout, data, item, icon, active_data,
        active_propname, index=0,
    ):
        label = item.label
        if label is None:
            layout.label(text="Label not found", icon='ERROR')
            return

        settings = label.jb3d_labeler
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            split = row.split(factor=0.40, align=True)
            name_row = split.row(align=True)
            type_icon = 'MOD_UVPROJECT' if settings.label_type == 'WRAP_360' else 'IMAGE_DATA'
            name_row.prop(label, "name", text="", emboss=False, icon=type_icon, translate=False)

            controls = split.row(align=True)
            controls.prop(
                settings, "visible", text="", emboss=False,
                icon='HIDE_OFF' if settings.visible else 'HIDE_ON',
            )
            controls.prop(
                settings, "label_locked", text="", emboss=False,
                icon='RESTRICT_SELECT_ON' if settings.label_locked else 'RESTRICT_SELECT_OFF',
            )
            controls.prop(
                settings, "anchor_locked", text="", emboss=False,
                icon='LOCKED' if settings.anchor_locked else 'UNLOCKED',
            )
            controls.prop(settings, "blend_mode", text="")
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')


class JB3D_LABELER_PT_main(Panel):
    bl_label = "JB3D Labeler"
    bl_idname = "JB3D_LABELER_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "JB3D"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        defaults = scene.jb3d_labeler

        manager = layout.box()
        title = manager.row(align=True)
        title.label(text=f"Labels ({len(scene.jb3d_label_items)})", icon='IMAGE_DATA')
        title.operator("jb3d_labeler.refresh_list", text="", icon='FILE_REFRESH')

        header = manager.row(align=True)
        header_split = header.split(factor=0.40, align=True)
        header_split.label(text="Name")
        header_controls = header_split.row(align=True)
        header_controls.label(text="", icon='HIDE_OFF')
        header_controls.label(text="", icon='RESTRICT_SELECT_ON')
        header_controls.label(text="", icon='EMPTY_AXIS')
        header_controls.label(text="Blend")

        list_row = manager.row()
        list_row.template_list(
            "JB3D_LABELER_UL_labels", "", scene, "jb3d_label_items",
            scene, "jb3d_label_index", rows=5,
        )
        buttons = list_row.column(align=True)
        op = buttons.operator("jb3d_labeler.move_layer", text="", icon='TRIA_UP')
        op.direction = 'UP'
        op = buttons.operator("jb3d_labeler.move_layer", text="", icon='TRIA_DOWN')
        op.direction = 'DOWN'
        buttons.separator()
        buttons.operator("jb3d_labeler.delete_rig", text="", icon='TRASH')

        footer = manager.row(align=True)
        footer.scale_y = 0.8
        footer.label(text="Top = Above · Surface Locked · Anchor Free", icon='TRIA_UP')

        create_box = layout.box()
        create_box.label(text="New Label", icon='ADD')
        create_box.prop(defaults, "label_type", expand=True)
        create_box.prop(defaults, "image_path", text="Image")
        _draw_image_info(create_box, defaults, compact=True)

        if defaults.label_type == 'WRAP_360':
            hint = create_box.box()
            hint.label(text="Select one continuous face band around the object.", icon='INFO')
            hint.label(text="The active face defines the front of the label.")
            create_box.prop(defaults, "preserve_ratio", text="Preserve Image Ratio")
            row = create_box.row(align=True)
            row.prop(defaults, "wrap_seam_mode")
            row.prop(defaults, "wrap_axis")
        else:
            size_row = create_box.row(align=True)
            size_row.prop(defaults, "width")
            size_row.prop(defaults, "height")
            create_box.prop(defaults, "preserve_ratio")

        advanced_header = create_box.row(align=True)
        advanced_header.prop(
            defaults, "show_create_advanced", text="Advanced Options",
            icon='TRIA_DOWN' if defaults.show_create_advanced else 'TRIA_RIGHT',
            emboss=False,
        )
        if defaults.show_create_advanced:
            advanced = create_box.column(align=True)
            if defaults.label_type == 'STANDARD':
                row = advanced.row(align=True)
                row.prop(defaults, "unwrap_method")
                row.prop(defaults, "orientation_mode")
            row = advanced.row(align=True)
            row.prop(defaults, "surface_offset")
            row.prop(defaults, "follow_surface")
            row = advanced.row(align=True)
            row.prop(defaults, "roughness")
            row.prop(defaults, "metallic")
            advanced.prop(defaults, "pack_image")

        button_text = "Create 360° Wrap" if defaults.label_type == 'WRAP_360' else "Create from Selected Faces"
        create_box.operator("jb3d_labeler.create_from_selection", text=button_text, icon='UV_FACESEL')
        if context.mode != 'EDIT_MESH':
            hint = create_box.row()
            hint.scale_y = 0.8
            hint.label(text="Select the product and its faces in Edit Mode", icon='INFO')

        label = registry.active_label(scene)
        rig = resolve_rig_from_object(label)
        if rig is None:
            return

        data = rig.label.jb3d_labeler
        is_wrap = data.label_type == 'WRAP_360'
        active_box = layout.box()
        name_row = active_box.row(align=True)
        name_row.label(text="360° Wrap" if is_wrap else "Standard Label",
                       icon='MOD_UVPROJECT' if is_wrap else 'IMAGE_DATA')
        name_row.prop(rig.label, "name", text="")

        quick = active_box.row(align=True)
        quick.operator("jb3d_labeler.select_anchor", text="Anchor", icon='EMPTY_AXIS')
        quick.operator("jb3d_labeler.select_controller", text="Controller", icon='EMPTY_AXIS')
        quick.operator("jb3d_labeler.select_source", text="Product", icon='OBJECT_DATA')

        active_box.prop(data, "image_path", text="Image")
        _draw_image_info(active_box, data, compact=True)

        if is_wrap:
            placement = active_box.column(align=True)
            placement.label(text="Artwork Placement")
            if rig.controller is not None:
                row = placement.row(align=True)
                row.prop(rig.controller, "location", index=0, text="Horizontal")
                row.prop(rig.controller, "location", index=1, text="Vertical")

            placement.label(text="Artwork Size")
            size_row = placement.row(align=True)
            size_row.prop(data, "width")
            size_row.prop(data, "height")
            placement.prop(data, "preserve_ratio", text="Preserve Image Ratio")
            if data.preserve_ratio:
                tip = placement.row()
                tip.scale_y = 0.8
                tip.label(text="Viewport: use S for proportional scaling; Update Label stores controller scaling.", icon='INFO')

            fit_row = placement.row(align=True)
            op = fit_row.operator("jb3d_labeler.fit_wrap_artwork", text="Full 360° Width", icon='MOD_UVPROJECT')
            op.mode = 'FULL_WIDTH'
            op = fit_row.operator("jb3d_labeler.fit_wrap_artwork", text="Fit Band Height")
            op.mode = 'BAND_HEIGHT'

            row = placement.row(align=True)
            row.prop(data, "wrap_seam_mode")
            row.prop(data, "wrap_axis")
            active_box.operator("jb3d_labeler.reset_controller", text="Reset Artwork Position", icon='PIVOT_CURSOR')

            measurements = active_box.box()
            measurements.label(text=f"Circumference: {format_distance(scene, data.wrap_circumference)}")
            measurements.label(text=f"Height: {format_distance(scene, data.wrap_height)}")
            measurements.label(text=f"Top: {format_distance(scene, data.wrap_top_length)}")
            measurements.label(text=f"Bottom: {format_distance(scene, data.wrap_bottom_length)}")
            measurements.separator()
            actual_width = data.width
            actual_height = data.height
            controller_changed = False
            if rig.controller is not None:
                actual_width = max(abs(rig.controller.scale.x) * 2.0, 1e-8)
                actual_height = max(abs(rig.controller.scale.y) * 2.0, 1e-8)
                controller_changed = (
                    abs(actual_width - data.width) > max(data.width, 1e-8) * 1e-5
                    or abs(actual_height - data.height) > max(data.height, 1e-8) * 1e-5
                )
            measurements.label(text=f"Artwork: {format_distance(scene, actual_width)} × {format_distance(scene, actual_height)}")
            if data.wrap_circumference > 1e-8:
                coverage = min(max(actual_width / data.wrap_circumference, 0.0), 1.0) * 100.0
                measurements.label(text=f"Circumference Coverage: {coverage:.1f}%")
            if controller_changed:
                measurements.label(text="Controller scale changed — Update Label to store it.", icon='INFO')
            if data.preserve_ratio and data.image is not None and data.image.size[0] > 0 and data.image.size[1] > 0:
                source_ratio = data.image.size[0] / data.image.size[1]
                actual_ratio = actual_width / max(actual_height, 1e-8)
                if abs(actual_ratio / source_ratio - 1.0) > 0.02:
                    measurements.label(text="Current controller scale stretches the image. Update Label to restore its ratio.", icon='ERROR')
            taper_icon = 'ERROR' if data.taper_percentage > 5.0 else 'CHECKMARK'
            measurements.label(text=f"Top/Bottom Difference: {data.taper_percentage:.1f}%", icon=taper_icon)
            ratio_warning = wrap.image_ratio_warning(data, data.image)
            if ratio_warning:
                measurements.label(text=ratio_warning, icon='ERROR')
            fit_warning = wrap.artwork_fit_warning(data, rig.controller)
            if fit_warning:
                measurements.label(text=fit_warning, icon='ERROR')
        else:
            row = active_box.row(align=True)
            row.prop(data, "width")
            row.prop(data, "height")
            active_box.prop(data, "preserve_ratio")
            tools = active_box.row(align=True)
            tools.operator("jb3d_labeler.rotate_90", text="Rotate 90°", icon='FILE_REFRESH')
            tools.operator("jb3d_labeler.reset_controller", text="Recenter", icon='PIVOT_CURSOR')

        active_box.operator("jb3d_labeler.update_active", text="Update Label", icon='CHECKMARK')

        advanced_header = active_box.row(align=True)
        advanced_header.prop(
            defaults, "show_active_advanced", text="Advanced Settings",
            icon='TRIA_DOWN' if defaults.show_active_advanced else 'TRIA_RIGHT',
            emboss=False,
        )
        if defaults.show_active_advanced:
            advanced = active_box.column(align=True)
            if not is_wrap:
                row = advanced.row(align=True)
                row.prop(data, "unwrap_method")
                row.prop(data, "orientation_mode")
            row = advanced.row(align=True)
            row.prop(data, "surface_offset")
            row.prop(data, "follow_surface")
            row = advanced.row(align=True)
            row.prop(data, "roughness")
            row.prop(data, "metallic")
            advanced.prop(data, "pack_image")

            source_subsurf = source_subdivision_modifier(rig.source)
            if source_subsurf is not None:
                advanced.label(text=f"Synchronized Subdivision: {source_subsurf.name}", icon='MOD_SUBSURF')

            if not is_wrap:
                fit = label_fit_report(rig)
                status = advanced.box()
                if rig.controller:
                    width = abs(rig.controller.scale.x) * 2.0
                    height = abs(rig.controller.scale.y) * 2.0
                    status.label(text=f"Size: {format_distance(scene, width)} × {format_distance(scene, height)}")
                distortion_icon = 'CHECKMARK' if data.distortion_rms < 5.0 else ('ERROR' if data.distortion_rms >= 12.0 else 'INFO')
                status.label(text=f"Distortion: {data.distortion_rms:.1f}%", icon=distortion_icon)
                if fit.fits:
                    status.label(text="Label fits the support area", icon='CHECKMARK')
                else:
                    status.label(text=f"Overflow: {format_distance(scene, fit.overflow)}", icon='ERROR')

        maintenance_header = active_box.row(align=True)
        maintenance_header.prop(
            defaults, "show_maintenance", text="Maintenance",
            icon='TRIA_DOWN' if defaults.show_maintenance else 'TRIA_RIGHT', emboss=False,
        )
        if defaults.show_maintenance:
            maintenance = active_box.column(align=True)
            maintenance.operator("jb3d_labeler.rebuild_uv", text="Force UV Rebuild", icon='FILE_REFRESH')
            maintenance.operator("jb3d_labeler.repair_links", text="Check Links and Parenting", icon='LINKED')
            row = maintenance.row()
            row.enabled = not data.label_locked
            row.operator("jb3d_labeler.select_label", text="Select Surface", icon='MESH_GRID')
            maintenance.operator("jb3d_labeler.delete_rig", text="Delete Label", icon='TRASH')


_CLASSES = (JB3D_LABELER_UL_labels, JB3D_LABELER_PT_main)


def _registered_class(cls):
    if getattr(cls, "is_registered", False):
        return cls
    for base in cls.__bases__:
        for candidate in base.__subclasses__():
            if candidate.__name__ == cls.__name__ and candidate.__module__ == cls.__module__:
                if getattr(candidate, "is_registered", False):
                    return candidate
    return None


def _unregister_classes() -> None:
    for cls in reversed(_CLASSES):
        registered = _registered_class(cls)
        if registered is not None:
            bpy.utils.unregister_class(registered)


def register():
    if all(_registered_class(cls) is cls for cls in _CLASSES):
        return
    _unregister_classes()
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    _unregister_classes()
