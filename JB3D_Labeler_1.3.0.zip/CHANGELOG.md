# Changelog

## 1.3.0

- Added true color compositing between overlapping labels on the same product.
- Blend modes now use the visible label stack underneath instead of always using a white local base.
- Added per-label Opacity control.
- Added support for compositing Standard labels with Standard labels, 360° Wrap labels with Wrap labels, and Standard/Wrap combinations when their support faces overlap.
- Added internal source-face and source-vertex provenance attributes to newly generated label meshes.
- Added automatic provenance reconstruction for older V1.x label meshes.
- Added internal transferred coordinate and overlap-mask attributes so compositing does not modify the product mesh or its UV maps.
- Added live lower-layer sampling driven by each label controller, so position, rotation and scale changes remain interactive.
- Added compositing status information in the active-label interface.
- Added a manual Rebuild Layer Compositing maintenance action for recovery and diagnostics.
- Reordering and blend-mode changes rebuild the relevant source stack automatically; opacity and visibility are evaluated live through drivers.
- Preserved V1.2 physical sizing and aspect-ratio controls for 360° Wrap artwork.
- Minimum supported Blender version remains 4.5.0 LTS.

## 1.2.0

- Added physical Width and Height controls to 360° Wrap artwork.
- Added live wrap artwork scaling through the existing controller.
- Added horizontal and vertical repositioning combined with independent artwork sizing.
- Added Preserve Image Ratio support to 360° Wrap labels to prevent aspect-ratio stretching.
- Added Full 360° Width and Fit Band Height actions for fast wrap fitting.
- Added support for curved partial labels when artwork width is smaller than the product circumference.
- Limited wrap artwork width to one circumference to avoid overlap/discontinuities at the seam.
- Added warnings when artwork is taller than the selected wrap band and will be clipped.
- Added controller-scale detection so viewport scaling can be stored with Update Label.
- Updated the shared wrap shader coordinate system to use physical circumference, band height and artwork dimensions.
- Added automatic migration of V1.1 360° Wrap rigs to the new V1.2 controller behavior while preserving their previous appearance.
- Standard Label behavior remains compatible.

## 1.1.1

- Converted the package cleanly to the Blender Extension format by removing legacy `bl_info` metadata.
- Added explicit GPL-3.0-or-later licensing information and SPDX headers.
- Prevented JB3D Labeler from deleting unrelated user node groups when an internal node-group name collides.
- Added persistent ownership markers for managed shader node groups.
- Removed a redundant module-level registry state assignment.
- Verified the code path against Blender 4.5-era APIs and lowered the minimum supported version to Blender 4.5.0 LTS; Blender 5.x remains supported.
- No changes to the saved label data schema; existing 1.0.0 and 1.1.0 labels remain compatible.

## 1.1.0

- Added a **360° Wrap** label type for bottles, cans, jars, tubes, and similar packaging.
- Added automatic detection of continuous closed quad bands.
- Added automatic back-seam placement based on the active face.
- Added optional seam placement from the active vertical edge.
- Added automatic or local-axis band detection.
- Added circumference, height, top/bottom length, and taper measurements.
- Added warnings for image-ratio mismatch and tapered surfaces.
- Added horizontal and vertical artwork offsets through the existing controller.
- Added the shared **JB3D Wrap Coordinates v1** shader node group.
- Preserved subdivision-before-shrinkwrap, white label backs, parenting, stacking, visibility, locking, and blend modes.
- Existing 1.0.0 labels are migrated as Standard labels.

## 1.0.0

- Initial public release.
