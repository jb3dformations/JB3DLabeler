# JB3D Labeler

JB3D Labeler creates editable product labels directly from selected mesh faces while keeping the product mesh, its materials and its existing UV maps untouched.

## Standard Labels

Select a connected support area, choose an image and physical dimensions, then create the label. The generated label surface receives metric UVs plus a controller for position, rotation and physical size. Subdivision and surface following remain non-destructive and editable.

## 360° Wrap Labels

1. Select **360° Wrap** in the creation panel.
2. Choose an image and enable **Preserve Image Ratio** if the artwork must not be stretched.
3. In Edit Mode, select one continuous quad face band around the product.
4. Make one face active; it defines the front of the artwork.
5. For **Active Edge** seam mode, select a vertical band edge last.
6. Create the label.

The face band defines the available wrap surface while the artwork keeps independent physical dimensions. Move the controller on local X to slide the artwork around the circumference, move it on local Y to move it vertically, and use Width/Height or viewport scaling to resize it.

**Preserve Image Ratio** keeps the source artwork proportions. **Full 360° Width** fits the artwork to one complete circumference and **Fit Band Height** fits it to the selected band height. Artwork narrower than one circumference becomes a curved partial label with transparent space around the remaining band.

The 360° workflow requires a clean quad band with exactly two closed boundary loops and no branches, poles, isolated faces or extra face islands. Slightly tapered bands are supported and reported.

## Layer Compositing

Version 1.3 adds true color compositing between overlapping JB3D labels attached to the same product. The label list defines the layer order: the first item is the top layer.

Each label provides:

- **Blend Mode**: Mix, Multiply, Screen, Overlay, Add, Difference, Hue, Saturation, Color, Soft Light and the other Blender color blend modes exposed by JB3D Labeler.
- **Opacity**: overall layer opacity from 0 to 100%.
- Live controller transforms: moving, rotating or resizing a label automatically updates how it is sampled by labels above it.

When labels overlap, JB3D reconstructs the visible color from the bottom layer upward and uses that result as the input for the next blend operation. Standard labels and 360° Wrap labels can therefore blend with one another when their support surfaces share product faces.

The compositing system does **not** create one UV map per label on the product. Instead, JB3D stores source-topology provenance on its own generated label meshes and creates temporary internal coordinate/mask attributes only where another label overlaps. The product mesh and all user UV maps remain unchanged.

Blend compositing currently affects label color. Roughness and metallic remain properties of each physical label surface, which is appropriate for stacked sticker/packaging layers.

## Workflow

1. Select product faces in Edit Mode and create a Standard or 360° Wrap label.
2. Position and resize the label with its Controller.
3. Create additional labels on the same product.
4. Reorder them in the Labels list; **Top = Above**.
5. Choose a Blend Mode and Opacity for each layer.
6. JB3D automatically rebuilds only the internal compositing data needed for overlaps. Controller transforms remain live through drivers.
7. Use **Update Label** when changing the source image or UV-generation settings.

## Compatibility and Migration

Version 1.3.0 targets Blender 4.5.0 LTS or newer, including Blender 5.x. Existing Standard and 360° Wrap labels from V1.x are migrated in place. V1.3 can reconstruct source-face/source-vertex provenance for older generated label meshes so they can participate in layer compositing without modifying the product.

## Permissions

The extension requests file access only to load label images explicitly selected by the user. It does not use network access, subprocesses, package installation or external Python dependencies.

## License

JB3D Labeler is licensed under GPL-3.0-or-later. See `LICENSE`.
