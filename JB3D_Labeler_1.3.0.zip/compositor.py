# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

"""Layer compositing support for JB3D Labeler.

The renderer keeps every label as an independent surface/controller rig, but the
material of an upper label can sample the artwork of lower labels wherever the
support meshes refer to the same source faces. Coordinates are transferred as
internal mesh attributes on JB3D-owned label meshes; the product mesh and its UV
maps are never modified.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import bpy

from . import materials
from .utils import (
    ROLE_LABEL,
    SOURCE_FACE_ATTRIBUTE,
    SOURCE_VERTEX_ATTRIBUTE,
    UV_NAME,
    ensure_source_mapping,
)


STACK_UV_PREFIX = "JB3D_StackUV_"
STACK_MASK_PREFIX = "JB3D_StackMask_"


@dataclass(frozen=True)
class CompositeLayer:
    label: bpy.types.Object
    uv_attribute: str
    mask_attribute: str


def _safe_token(label: bpy.types.Object) -> str:
    data = label.jb3d_labeler
    token = (data.rig_uuid or label.name).replace("-", "").replace(" ", "_")
    return token[:36]


def _attribute_names(label: bpy.types.Object) -> tuple[str, str]:
    token = _safe_token(label)
    return f"{STACK_UV_PREFIX}{token}", f"{STACK_MASK_PREFIX}{token}"


def _remove_attribute(mesh: bpy.types.Mesh, name: str) -> None:
    attribute = mesh.attributes.get(name)
    if attribute is not None:
        try:
            mesh.attributes.remove(attribute)
        except (RuntimeError, TypeError):
            pass


def clear_stack_attributes(label: bpy.types.Object) -> None:
    if label is None or label.type != 'MESH':
        return
    mesh = label.data
    for attribute in list(mesh.attributes):
        if attribute.name.startswith(STACK_UV_PREFIX) or attribute.name.startswith(STACK_MASK_PREFIX):
            try:
                mesh.attributes.remove(attribute)
            except (RuntimeError, TypeError):
                pass


def _new_attribute(mesh: bpy.types.Mesh, name: str, data_type: str, domain: str):
    existing = mesh.attributes.get(name)
    if existing is not None:
        if existing.data_type == data_type and existing.domain == domain:
            return existing
        _remove_attribute(mesh, name)
    return mesh.attributes.new(name=name, type=data_type, domain=domain)


def _source_face_values(label: bpy.types.Object) -> list[int]:
    attribute = label.data.attributes.get(SOURCE_FACE_ATTRIBUTE)
    if attribute is None or attribute.domain != 'FACE' or attribute.data_type != 'INT':
        raise ValueError("Missing source-face mapping")
    return [int(item.value) for item in attribute.data]


def _source_vertex_values(label: bpy.types.Object) -> list[int]:
    attribute = label.data.attributes.get(SOURCE_VERTEX_ATTRIBUTE)
    if attribute is None or attribute.domain != 'POINT' or attribute.data_type != 'INT':
        raise ValueError("Missing source-vertex mapping")
    return [int(item.value) for item in attribute.data]


def _uv_lookup(label: bpy.types.Object) -> dict[tuple[int, int], tuple[float, float]]:
    """Return base label UV by (source face index, source vertex index)."""
    mesh = label.data
    uv_layer = mesh.uv_layers.get(UV_NAME)
    if uv_layer is None:
        raise ValueError(f"{label.name} has no {UV_NAME} UV map")

    face_ids = _source_face_values(label)
    vertex_ids = _source_vertex_values(label)
    lookup: dict[tuple[int, int], tuple[float, float]] = {}
    for polygon in mesh.polygons:
        source_face = face_ids[polygon.index]
        if source_face < 0:
            continue
        for loop_index in polygon.loop_indices:
            loop = mesh.loops[loop_index]
            source_vertex = vertex_ids[loop.vertex_index]
            if source_vertex < 0:
                continue
            uv = uv_layer.data[loop_index].uv
            lookup[(source_face, source_vertex)] = (float(uv.x), float(uv.y))
    return lookup


def _transfer_coordinates(target: bpy.types.Object, layer: bpy.types.Object) -> CompositeLayer | None:
    """Copy a lower label's base UV field onto overlapping faces of target.

    The attributes live only on the target label mesh. A mask attribute makes
    non-overlapping faces inert, which is important for periodic 360° mappings.
    """
    if target is None or layer is None or target.type != 'MESH' or layer.type != 'MESH':
        return None
    if target.jb3d_labeler.source_object != layer.jb3d_labeler.source_object:
        return None

    ensure_source_mapping(target)
    ensure_source_mapping(layer)

    lookup = _uv_lookup(layer)
    if not lookup:
        return None

    mesh = target.data
    face_ids = _source_face_values(target)
    vertex_ids = _source_vertex_values(target)
    uv_name, mask_name = _attribute_names(layer)
    uv_attribute = _new_attribute(mesh, uv_name, 'FLOAT_VECTOR', 'CORNER')
    mask_attribute = _new_attribute(mesh, mask_name, 'FLOAT', 'CORNER')

    matched_loops = 0
    for polygon in mesh.polygons:
        source_face = face_ids[polygon.index]
        for loop_index in polygon.loop_indices:
            loop = mesh.loops[loop_index]
            source_vertex = vertex_ids[loop.vertex_index]
            uv = lookup.get((source_face, source_vertex))
            if uv is None:
                uv_attribute.data[loop_index].vector = (0.0, 0.0, 0.0)
                mask_attribute.data[loop_index].value = 0.0
                continue
            uv_attribute.data[loop_index].vector = (uv[0], uv[1], 0.0)
            mask_attribute.data[loop_index].value = 1.0
            matched_loops += 1

    if matched_loops == 0:
        _remove_attribute(mesh, uv_name)
        _remove_attribute(mesh, mask_name)
        return None
    return CompositeLayer(layer, uv_name, mask_name)


def labels_for_source(
    source: bpy.types.Object | None,
    scene: bpy.types.Scene | None = None,
) -> list[bpy.types.Object]:
    """Return labels for one product in top-to-bottom stack order.

    Scene scoping prevents labels from a second scene that happens to share the
    same product datablock from leaking into the current compositing stack.
    """
    if source is None:
        return []
    labels = []
    objects = scene.objects if scene is not None else bpy.data.objects
    for obj in objects:
        if obj.type != 'MESH' or not hasattr(obj, "jb3d_labeler"):
            continue
        data = obj.jb3d_labeler
        if data.role == ROLE_LABEL and data.source_object == source:
            labels.append(obj)
    labels.sort(key=lambda item: (int(item.jb3d_labeler.stack_order), item.name.casefold()))
    return labels


def _usable_lower_labels(labels: Iterable[bpy.types.Object]) -> list[bpy.types.Object]:
    result = []
    for label in labels:
        data = label.jb3d_labeler
        # Visibility and opacity are driven live inside upper materials, so all
        # structurally valid lower layers remain in the stack.
        if data.controller_object is None or data.image is None:
            continue
        result.append(label)
    return result


def rebuild_source_stack(source: bpy.types.Object | None, scene: bpy.types.Scene | None = None) -> int:
    """Rebuild composited materials for every label attached to one product.

    Returns the number of label materials rebuilt. Failures are isolated per
    label so a damaged legacy rig cannot disable the rest of the source stack.
    """
    labels = labels_for_source(source, scene)
    if not labels:
        return 0

    rebuilt = 0
    for index, label in enumerate(labels):
        data = label.jb3d_labeler
        clear_stack_attributes(label)
        data.composite_layer_count = 0
        data.composite_status = ""

        controller = data.controller_object
        image = data.image
        if controller is None or image is None:
            data.composite_status = "Incomplete rig: compositing unavailable"
            continue

        lower_labels = _usable_lower_labels(labels[index + 1:])
        layers: list[CompositeLayer] = []
        warnings: list[str] = []
        for lower in lower_labels:
            try:
                transferred = _transfer_coordinates(label, lower)
                if transferred is not None:
                    layers.append(transferred)
            except Exception as exc:
                warnings.append(f"{lower.name}: {exc}")

        try:
            materials.create_label_material(
                label,
                controller,
                image,
                data.roughness,
                data.metallic,
                data.blend_mode,
                opacity=float(getattr(data, "opacity", 1.0)),
                underlying_layers=layers,
            )
            data.composite_layer_count = len(layers)
            if warnings:
                data.composite_status = "Partial compositing: " + "; ".join(warnings[:2])
            elif layers:
                data.composite_status = f"Compositing {len(layers)} underlying layer(s)"
            else:
                data.composite_status = "No overlapping lower label"
            rebuilt += 1
        except Exception as exc:
            data.composite_status = f"Compositing rebuild failed: {exc}"
            # Keep a functional standalone label if the stack builder itself fails.
            try:
                materials.create_label_material(
                    label,
                    controller,
                    image,
                    data.roughness,
                    data.metallic,
                    data.blend_mode,
                    opacity=float(getattr(data, "opacity", 1.0)),
                    underlying_layers=None,
                )
                rebuilt += 1
            except Exception:
                pass
    return rebuilt


def refresh_source_stack(
    label_or_source: bpy.types.Object | None,
    scene: bpy.types.Scene | None = None,
) -> int:
    if label_or_source is None:
        return 0
    label = None
    if hasattr(label_or_source, "jb3d_labeler") and label_or_source.jb3d_labeler.role == ROLE_LABEL:
        label = label_or_source
        source = label_or_source.jb3d_labeler.source_object
    else:
        source = label_or_source

    # Prefer an explicitly supplied UI scene. Otherwise fall back to one scene
    # using the edited object. This keeps callbacks deterministic in normal
    # single-scene use while remaining safe for linked multi-scene objects.
    if scene is None:
        owner = label or source
        users_scene = getattr(owner, "users_scene", ()) if owner is not None else ()
        scene = users_scene[0] if users_scene else None
    return rebuild_source_stack(source, scene)


def refresh_scene(scene: bpy.types.Scene | None) -> int:
    if scene is None:
        return 0
    sources: dict[int, bpy.types.Object] = {}
    for obj in scene.objects:
        if obj.type != 'MESH' or not hasattr(obj, "jb3d_labeler"):
            continue
        data = obj.jb3d_labeler
        if data.role != ROLE_LABEL or data.source_object is None:
            continue
        sources[data.source_object.as_pointer()] = data.source_object
    return sum(rebuild_source_stack(source, scene) for source in sources.values())
