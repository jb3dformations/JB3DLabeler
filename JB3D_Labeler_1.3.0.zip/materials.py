# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import bpy

from .utils import UV_NAME, add_transform_driver


NODE_PREFIX = "JB3D_LABEL_"
COORD_GROUP_NAME = "JB3D Label Coordinates v1"
COORD_GROUP_SCHEMA = 2
COORD_NODE_NAME = f"{NODE_PREFIX}COORDINATES"
WRAP_COORD_GROUP_NAME = "JB3D Wrap Coordinates v2"
WRAP_COORD_GROUP_SCHEMA = 2
WRAP_COORD_NODE_NAME = f"{NODE_PREFIX}WRAP_COORDINATES"
GROUP_OWNER_KEY = "jb3d_labeler_group"
GROUP_OWNER_COORDINATES = "coordinates"
GROUP_OWNER_WRAP = "wrap_coordinates"


def _new_math(nodes, operation: str, name: str, x: float, y: float):
    node = nodes.new("ShaderNodeMath")
    node.name = name
    node.label = name.replace(NODE_PREFIX, "")
    node.operation = operation
    node.location = (x, y)
    return node


def _new_interface_socket(
    node_tree: bpy.types.NodeTree,
    name: str,
    in_out: str,
    socket_type: str,
    default_value=None,
):
    """Create a node-group socket with Blender 4.x/5.x and a legacy fallback."""
    if hasattr(node_tree, "interface"):
        socket = node_tree.interface.new_socket(
            name=name,
            in_out=in_out,
            socket_type=socket_type,
        )
    else:  # pragma: no cover - compatibility fallback for older Blender files.
        collection = node_tree.inputs if in_out == 'INPUT' else node_tree.outputs
        socket = collection.new(socket_type, name)

    if default_value is not None and hasattr(socket, "default_value"):
        try:
            socket.default_value = default_value
        except (TypeError, ValueError):
            pass
    return socket


def _coordinate_group_is_valid(group: bpy.types.NodeTree | None) -> bool:
    if group is None or group.bl_idname != 'ShaderNodeTree':
        return False
    if int(group.get("jb3d_schema", 0)) != COORD_GROUP_SCHEMA:
        return False
    return (
        group.nodes.get("JB3D_COORD_INPUT") is not None
        and group.nodes.get("JB3D_COORD_OUTPUT") is not None
    )


def _managed_group(owner: str, validator) -> bpy.types.NodeTree | None:
    """Find a valid node group created and owned by JB3D Labeler."""
    for candidate in bpy.data.node_groups:
        if candidate.get(GROUP_OWNER_KEY) == owner and validator(candidate):
            return candidate
    return None


def ensure_coordinate_group() -> bpy.types.NodeTree:
    """Return the shared coordinate-transform group used by all label materials."""
    group = bpy.data.node_groups.get(COORD_GROUP_NAME)
    if _coordinate_group_is_valid(group):
        group[GROUP_OWNER_KEY] = GROUP_OWNER_COORDINATES
        return group

    # Never remove or overwrite an unknown user node group with a colliding name.
    managed = _managed_group(GROUP_OWNER_COORDINATES, _coordinate_group_is_valid)
    if managed is not None:
        return managed

    group_name = (
        COORD_GROUP_NAME
        if group is None
        else f"{COORD_GROUP_NAME} - JB3D Managed v{COORD_GROUP_SCHEMA}"
    )
    group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group["jb3d_schema"] = COORD_GROUP_SCHEMA
    group[GROUP_OWNER_KEY] = GROUP_OWNER_COORDINATES
    group.use_fake_user = True
    try:
        group.description = (
            "Transforms metric JB3D label UVs with the label controller: "
            "translation, rotation, physical width and physical height."
        )
    except Exception:
        pass

    _new_interface_socket(group, "Metric UV", 'INPUT', 'NodeSocketVector', (0.0, 0.0, 0.0))
    _new_interface_socket(group, "Center U", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Center V", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Rotation", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Width", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Image Coordinates", 'OUTPUT', 'NodeSocketVector')

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.name = "JB3D_COORD_INPUT"
    group_input.label = "Label Controls"
    group_input.location = (-1000, 20)

    group_output = nodes.new("NodeGroupOutput")
    group_output.name = "JB3D_COORD_OUTPUT"
    group_output.label = "0–1 Coordinates"
    group_output.location = (720, 80)

    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.name = "JB3D_COORD_SEPARATE"
    separate.label = "Separate UV"
    separate.location = (-780, 180)

    subtract_u = _new_math(nodes, 'SUBTRACT', "JB3D_COORD_SUB_U", -560, 260)
    subtract_v = _new_math(nodes, 'SUBTRACT', "JB3D_COORD_SUB_V", -560, 80)

    cosine = _new_math(nodes, 'COSINE', "JB3D_COORD_COS", -560, -160)
    sine = _new_math(nodes, 'SINE', "JB3D_COORD_SIN", -560, -300)

    dx_cos = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DX_COS", -330, 330)
    dy_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DY_SIN", -330, 210)
    rotated_x = _new_math(nodes, 'ADD', "JB3D_COORD_ROT_X", -100, 280)

    dx_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DX_SIN", -330, 50)
    dy_cos = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DY_COS", -330, -80)
    negative_dx_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_NEG_DX_SIN", -100, 40)
    negative_dx_sin.inputs[1].default_value = -1.0
    rotated_y = _new_math(nodes, 'ADD', "JB3D_COORD_ROT_Y", 110, -20)

    divide_u = _new_math(nodes, 'DIVIDE', "JB3D_COORD_DIV_U", 120, 280)
    divide_v = _new_math(nodes, 'DIVIDE', "JB3D_COORD_DIV_V", 330, -20)

    add_half_u = _new_math(nodes, 'ADD', "JB3D_COORD_ADD_HALF_U", 340, 280)
    add_half_u.inputs[1].default_value = 0.5
    add_half_v = _new_math(nodes, 'ADD', "JB3D_COORD_ADD_HALF_V", 540, -20)
    add_half_v.inputs[1].default_value = 0.5

    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.name = "JB3D_COORD_COMBINE"
    combine.label = "Image Coordinates"
    combine.location = (540, 170)
    combine.inputs["Z"].default_value = 0.0

    links.new(group_input.outputs["Metric UV"], separate.inputs["Vector"])
    links.new(separate.outputs["X"], subtract_u.inputs[0])
    links.new(group_input.outputs["Center U"], subtract_u.inputs[1])
    links.new(separate.outputs["Y"], subtract_v.inputs[0])
    links.new(group_input.outputs["Center V"], subtract_v.inputs[1])

    links.new(group_input.outputs["Rotation"], cosine.inputs[0])
    links.new(group_input.outputs["Rotation"], sine.inputs[0])

    links.new(subtract_u.outputs[0], dx_cos.inputs[0])
    links.new(cosine.outputs[0], dx_cos.inputs[1])
    links.new(subtract_v.outputs[0], dy_sin.inputs[0])
    links.new(sine.outputs[0], dy_sin.inputs[1])
    links.new(dx_cos.outputs[0], rotated_x.inputs[0])
    links.new(dy_sin.outputs[0], rotated_x.inputs[1])

    links.new(subtract_u.outputs[0], dx_sin.inputs[0])
    links.new(sine.outputs[0], dx_sin.inputs[1])
    links.new(subtract_v.outputs[0], dy_cos.inputs[0])
    links.new(cosine.outputs[0], dy_cos.inputs[1])
    links.new(dx_sin.outputs[0], negative_dx_sin.inputs[0])
    links.new(negative_dx_sin.outputs[0], rotated_y.inputs[0])
    links.new(dy_cos.outputs[0], rotated_y.inputs[1])

    links.new(rotated_x.outputs[0], divide_u.inputs[0])
    links.new(group_input.outputs["Width"], divide_u.inputs[1])
    links.new(rotated_y.outputs[0], divide_v.inputs[0])
    links.new(group_input.outputs["Height"], divide_v.inputs[1])

    links.new(divide_u.outputs[0], add_half_u.inputs[0])
    links.new(divide_v.outputs[0], add_half_v.inputs[0])
    links.new(add_half_u.outputs[0], combine.inputs["X"])
    links.new(add_half_v.outputs[0], combine.inputs["Y"])
    links.new(combine.outputs["Vector"], group_output.inputs["Image Coordinates"])

    return group


def _wrap_coordinate_group_is_valid(group: bpy.types.NodeTree | None) -> bool:
    if group is None or group.bl_idname != 'ShaderNodeTree':
        return False
    return (
        int(group.get("jb3d_wrap_schema", 0)) == WRAP_COORD_GROUP_SCHEMA
        and group.nodes.get("JB3D_WRAP_INPUT") is not None
        and group.nodes.get("JB3D_WRAP_OUTPUT") is not None
    )


def ensure_wrap_coordinate_group() -> bpy.types.NodeTree:
    """Create the shared physical-size coordinate group for 360° labels."""
    group = bpy.data.node_groups.get(WRAP_COORD_GROUP_NAME)
    if _wrap_coordinate_group_is_valid(group):
        group[GROUP_OWNER_KEY] = GROUP_OWNER_WRAP
        return group

    # Preserve unrelated user data if the preferred node-group name is occupied.
    managed = _managed_group(GROUP_OWNER_WRAP, _wrap_coordinate_group_is_valid)
    if managed is not None:
        return managed

    group_name = (
        WRAP_COORD_GROUP_NAME
        if group is None
        else f"{WRAP_COORD_GROUP_NAME} - JB3D Managed v{WRAP_COORD_GROUP_SCHEMA}"
    )
    group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group["jb3d_wrap_schema"] = WRAP_COORD_GROUP_SCHEMA
    group[GROUP_OWNER_KEY] = GROUP_OWNER_WRAP
    group.use_fake_user = True
    try:
        group.description = (
            "Maps normalized 360-degree wrap UVs to a movable physical artwork rectangle. "
            "Artwork width and height can be resized independently or kept at the image aspect ratio."
        )
    except Exception:
        pass

    _new_interface_socket(group, "Wrap UV", 'INPUT', 'NodeSocketVector', (0.0, 0.0, 0.0))
    _new_interface_socket(group, "Horizontal Offset", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Vertical Offset", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Surface Circumference", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Surface Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Artwork Width", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Artwork Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Image Coordinates", 'OUTPUT', 'NodeSocketVector')

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.name = "JB3D_WRAP_INPUT"
    group_input.label = "Wrap Controls"
    group_input.location = (-1180, 0)

    group_output = nodes.new("NodeGroupOutput")
    group_output.name = "JB3D_WRAP_OUTPUT"
    group_output.label = "Artwork Coordinates"
    group_output.location = (760, 60)

    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.name = "JB3D_WRAP_SEPARATE"
    separate.label = "Separate Wrap UV"
    separate.location = (-980, 120)

    # Horizontal: keep the seam periodic, center the artwork on the front,
    # convert normalized wrap distance to physical distance, then divide by
    # the requested artwork width. Width == circumference reproduces V1.1.
    subtract_u = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_SUB_U", -780, 260)
    fract_u = _new_math(nodes, 'FRACT', "JB3D_WRAP_FRACT_U", -580, 260)
    center_u = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_CENTER_U", -380, 260)
    center_u.inputs[1].default_value = 0.5
    physical_u = _new_math(nodes, 'MULTIPLY', "JB3D_WRAP_PHYSICAL_U", -180, 260)
    divide_u = _new_math(nodes, 'DIVIDE', "JB3D_WRAP_DIV_U", 20, 260)
    image_u = _new_math(nodes, 'ADD', "JB3D_WRAP_IMAGE_U", 220, 260)
    image_u.inputs[1].default_value = 0.5

    # Vertical: the normalized band is centered at 0.5. Convert it to physical
    # height around the center, apply the controller offset and artwork height.
    subtract_v_offset = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_SUB_V_OFFSET", -780, -100)
    center_v = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_CENTER_V", -580, -100)
    center_v.inputs[1].default_value = 0.5
    physical_v = _new_math(nodes, 'MULTIPLY', "JB3D_WRAP_PHYSICAL_V", -380, -100)
    divide_v = _new_math(nodes, 'DIVIDE', "JB3D_WRAP_DIV_V", -180, -100)
    image_v = _new_math(nodes, 'ADD', "JB3D_WRAP_IMAGE_V", 20, -100)
    image_v.inputs[1].default_value = 0.5

    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.name = "JB3D_WRAP_COMBINE"
    combine.label = "Image Coordinates"
    combine.location = (500, 80)
    combine.inputs["Z"].default_value = 0.0

    links.new(group_input.outputs["Wrap UV"], separate.inputs["Vector"])

    links.new(separate.outputs["X"], subtract_u.inputs[0])
    links.new(group_input.outputs["Horizontal Offset"], subtract_u.inputs[1])
    links.new(subtract_u.outputs[0], fract_u.inputs[0])
    links.new(fract_u.outputs[0], center_u.inputs[0])
    links.new(center_u.outputs[0], physical_u.inputs[0])
    links.new(group_input.outputs["Surface Circumference"], physical_u.inputs[1])
    links.new(physical_u.outputs[0], divide_u.inputs[0])
    links.new(group_input.outputs["Artwork Width"], divide_u.inputs[1])
    links.new(divide_u.outputs[0], image_u.inputs[0])

    links.new(separate.outputs["Y"], subtract_v_offset.inputs[0])
    links.new(group_input.outputs["Vertical Offset"], subtract_v_offset.inputs[1])
    links.new(subtract_v_offset.outputs[0], center_v.inputs[0])
    links.new(center_v.outputs[0], physical_v.inputs[0])
    links.new(group_input.outputs["Surface Height"], physical_v.inputs[1])
    links.new(physical_v.outputs[0], divide_v.inputs[0])
    links.new(group_input.outputs["Artwork Height"], divide_v.inputs[1])
    links.new(divide_v.outputs[0], image_v.inputs[0])

    links.new(image_u.outputs[0], combine.inputs["X"])
    links.new(image_v.outputs[0], combine.inputs["Y"])
    links.new(combine.outputs["Vector"], group_output.inputs["Image Coordinates"])
    return group


def _configure_wrap_coordinate_drivers(
    coordinate_node: bpy.types.ShaderNodeGroup,
    controller: bpy.types.Object,
    circumference: float,
    height: float,
) -> None:
    circumference = max(float(circumference), 1e-8)
    height = max(float(height), 1e-8)
    coordinate_node.inputs["Surface Circumference"].default_value = circumference
    coordinate_node.inputs["Surface Height"].default_value = height
    add_transform_driver(
        coordinate_node.inputs["Horizontal Offset"], controller, 'LOC_X',
        f"v / {circumference:.17g}",
    )
    add_transform_driver(
        coordinate_node.inputs["Vertical Offset"], controller, 'LOC_Y',
        f"v / {height:.17g}",
    )
    add_transform_driver(
        coordinate_node.inputs["Artwork Width"], controller, 'SCALE_X',
        "abs(v) * 2.0 + 1e-8",
    )
    add_transform_driver(
        coordinate_node.inputs["Artwork Height"], controller, 'SCALE_Y',
        "abs(v) * 2.0 + 1e-8",
    )


def _configure_coordinate_drivers(
    coordinate_node: bpy.types.ShaderNodeGroup,
    controller: bpy.types.Object,
) -> None:
    add_transform_driver(coordinate_node.inputs["Center U"], controller, 'LOC_X')
    add_transform_driver(coordinate_node.inputs["Center V"], controller, 'LOC_Y')
    add_transform_driver(coordinate_node.inputs["Rotation"], controller, 'ROT_Z')
    add_transform_driver(
        coordinate_node.inputs["Width"],
        controller,
        'SCALE_X',
        "abs(v) * 2.0 + 1e-8",
    )
    add_transform_driver(
        coordinate_node.inputs["Height"],
        controller,
        'SCALE_Y',
        "abs(v) * 2.0 + 1e-8",
    )


COLOR_MIX_NODE_NAME = f"{NODE_PREFIX}COLOR_MIX"
OPACITY_NODE_NAME = f"{NODE_PREFIX}OPACITY"
MATERIAL_OWNER_KEY = "jb3d_labeler_material"


def _available_socket(sockets, name: str, socket_type: str):
    candidates = [
        socket for socket in sockets
        if socket.name == name and getattr(socket, "type", "") == socket_type
    ]
    for socket in candidates:
        if not getattr(socket, "is_unavailable", False):
            return socket
    return candidates[-1] if candidates else None


def _mix_color_sockets(node):
    factor = _available_socket(node.inputs, "Factor", 'VALUE')
    color_a = _available_socket(node.inputs, "A", 'RGBA')
    color_b = _available_socket(node.inputs, "B", 'RGBA')
    result = _available_socket(node.outputs, "Result", 'RGBA')

    # Stable fallbacks used by ShaderNodeMix in Blender 4.x/5.x.
    factor = factor or (node.inputs[0] if len(node.inputs) > 0 else None)
    color_a = color_a or (node.inputs[6] if len(node.inputs) > 6 else None)
    color_b = color_b or (node.inputs[7] if len(node.inputs) > 7 else None)
    result = result or (node.outputs[2] if len(node.outputs) > 2 else node.outputs[0])
    return factor, color_a, color_b, result


def _configure_mix_color(node, blend_mode: str) -> None:
    node.data_type = 'RGBA'
    try:
        node.blend_type = blend_mode
    except (TypeError, ValueError):
        node.blend_type = 'MIX'
    if hasattr(node, "clamp_factor"):
        node.clamp_factor = True

    factor, color_a, _color_b, _result = _mix_color_sockets(node)
    if factor is not None:
        factor.default_value = 1.0
    if color_a is not None:
        color_a.default_value = (1.0, 1.0, 1.0, 1.0)


def _new_mix_node(nodes, name: str, label: str, blend_mode: str, location: tuple[float, float]):
    node = nodes.new("ShaderNodeMix")
    node.name = name
    node.label = label
    node.location = location
    node.width = 180
    _configure_mix_color(node, blend_mode)
    return node


def _attribute_vector_node(nodes, name: str, attribute_name: str, location: tuple[float, float]):
    node = nodes.new("ShaderNodeAttribute")
    node.name = name
    node.label = "Transferred Label Coordinates"
    node.location = location
    node.attribute_name = attribute_name
    if hasattr(node, "attribute_type"):
        try:
            node.attribute_type = 'GEOMETRY'
        except (TypeError, ValueError):
            pass
    return node


def _attribute_factor_node(nodes, name: str, attribute_name: str, location: tuple[float, float]):
    node = nodes.new("ShaderNodeAttribute")
    node.name = name
    node.label = "Overlap Mask"
    node.location = location
    node.attribute_name = attribute_name
    if hasattr(node, "attribute_type"):
        try:
            node.attribute_type = 'GEOMETRY'
        except (TypeError, ValueError):
            pass
    return node


def _attribute_factor_output(node):
    socket = node.outputs.get("Fac")
    if socket is None:
        socket = node.outputs.get("Factor")
    if socket is None and len(node.outputs) > 2:
        socket = node.outputs[2]
    if socket is None:
        raise RuntimeError("Attribute node has no factor output")
    return socket


def _create_coordinate_node(
    nodes,
    label: bpy.types.Object,
    controller: bpy.types.Object,
    *,
    name: str,
    location: tuple[float, float],
):
    coordinate_node = nodes.new("ShaderNodeGroup")
    is_wrap = label.jb3d_labeler.label_type == 'WRAP_360'
    if is_wrap:
        coordinate_node.name = name
        coordinate_node.label = "360° Artwork Placement & Size"
        coordinate_node.node_tree = ensure_wrap_coordinate_group()
        _configure_wrap_coordinate_drivers(
            coordinate_node,
            controller,
            label.jb3d_labeler.wrap_circumference,
            label.jb3d_labeler.wrap_height,
        )
        input_name = "Wrap UV"
    else:
        coordinate_node.name = name
        coordinate_node.label = "Placement and Size"
        coordinate_node.node_tree = ensure_coordinate_group()
        _configure_coordinate_drivers(coordinate_node, controller)
        input_name = "Metric UV"
    coordinate_node.location = location
    coordinate_node.width = 220
    return coordinate_node, input_name


def _create_image_node(nodes, name: str, image: bpy.types.Image, location: tuple[float, float]):
    image_node = nodes.new("ShaderNodeTexImage")
    image_node.name = name
    image_node.label = "LABEL IMAGE"
    image_node.location = location
    image_node.image = image
    image_node.extension = 'CLIP'
    image_node.interpolation = 'Linear'
    return image_node


def _add_property_driver(socket, owner: bpy.types.Object, data_path: str, *, expression: str = "v") -> None:
    """Drive a node scalar from a JB3D object property."""
    try:
        socket.driver_remove("default_value")
    except (TypeError, RuntimeError):
        pass
    fcurve = socket.driver_add("default_value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = expression
    variable = driver.variables.new()
    variable.name = "v"
    variable.type = 'SINGLE_PROP'
    target = variable.targets[0]
    target.id = owner
    target.data_path = data_path


def _add_layer_strength_driver(socket, label: bpy.types.Object) -> None:
    """Drive lower-layer contribution from its Opacity and Visible properties."""
    try:
        socket.driver_remove("default_value")
    except (TypeError, RuntimeError):
        pass
    fcurve = socket.driver_add("default_value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = "opacity * visible"
    opacity = driver.variables.new()
    opacity.name = "opacity"
    opacity.type = 'SINGLE_PROP'
    opacity.targets[0].id = label
    opacity.targets[0].data_path = "jb3d_labeler.opacity"
    visible = driver.variables.new()
    visible.name = "visible"
    visible.type = 'SINGLE_PROP'
    visible.targets[0].id = label
    visible.targets[0].data_path = "jb3d_labeler.visible"


def _multiply_alpha(nodes, links, a_socket, b_socket=None, b_value: float = 1.0, *, name: str, location):
    node = nodes.new("ShaderNodeMath")
    node.name = name
    node.label = "Layer Alpha"
    node.operation = 'MULTIPLY'
    node.location = location
    links.new(a_socket, node.inputs[0])
    if b_socket is not None:
        links.new(b_socket, node.inputs[1])
    else:
        node.inputs[1].default_value = max(0.0, min(float(b_value), 1.0))
    return node.outputs[0]


def _link_or_default(links, source_socket, destination_socket, default=(1.0, 1.0, 1.0, 1.0)) -> None:
    if destination_socket is None:
        return
    if source_socket is None:
        destination_socket.default_value = default
    else:
        links.new(source_socket, destination_socket)


def _configure_material_transparency(material: bpy.types.Material) -> None:
    material.use_backface_culling = False
    if hasattr(material, "surface_render_method"):
        for method in ('DITHERED', 'BLENDED'):
            try:
                material.surface_render_method = method
                break
            except Exception:
                continue
    if hasattr(material, "use_transparency_overlap"):
        try:
            material.use_transparency_overlap = False
        except Exception:
            pass


def create_label_material(
    label: bpy.types.Object,
    controller: bpy.types.Object,
    image: bpy.types.Image,
    roughness: float,
    metallic: float,
    blend_mode: str = 'MIX',
    *,
    opacity: float = 1.0,
    underlying_layers=None,
) -> bpy.types.Material:
    """Build one label material, optionally compositing labels underneath it.

    Underlying layers are sampled on the current label mesh through transferred
    corner attributes. Their own controllers remain live through drivers, so
    repositioning or resizing a label does not require a material rebuild.
    """
    old_material = label.data.materials[0] if label.data.materials else None
    reusable = (
        old_material is not None
        and old_material.users <= 1
        and (old_material.get(MATERIAL_OWNER_KEY) or old_material.name.startswith("JB3D_Label_"))
    )
    material = old_material if reusable else bpy.data.materials.new(f"{label.name}_Material")
    material[MATERIAL_OWNER_KEY] = label.jb3d_labeler.rig_uuid or label.name
    material.use_nodes = True
    _configure_material_transparency(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()

    # Current label coordinates use its native metric/wrap UV map.
    uv_map = nodes.new("ShaderNodeUVMap")
    uv_map.name = f"{NODE_PREFIX}UV_MAP"
    uv_map.label = "Metric UV"
    uv_map.uv_map = UV_NAME
    uv_map.location = (-980, 80)

    coordinate_node, coordinate_input = _create_coordinate_node(
        nodes,
        label,
        controller,
        name=WRAP_COORD_NODE_NAME if label.jb3d_labeler.label_type == 'WRAP_360' else COORD_NODE_NAME,
        location=(-760, 80),
    )
    links.new(uv_map.outputs["UV"], coordinate_node.inputs[coordinate_input])

    image_node = _create_image_node(nodes, f"{NODE_PREFIX}IMAGE", image, (-490, 80))
    links.new(coordinate_node.outputs["Image Coordinates"], image_node.inputs["Vector"])

    # Reconstruct the visible color below the current layer from bottom to top.
    accumulated_color = None
    layers = list(underlying_layers or [])
    for layer_index, layer_spec in enumerate(reversed(layers)):
        lower = layer_spec.label
        lower_data = lower.jb3d_labeler
        lower_controller = lower_data.controller_object
        lower_image = lower_data.image
        if lower_controller is None or lower_image is None:
            continue

        row_y = -420.0 - layer_index * 320.0
        prefix = f"{NODE_PREFIX}STACK_{layer_index:02d}_"
        attr = _attribute_vector_node(
            nodes, prefix + "UV", layer_spec.uv_attribute, (-1180, row_y + 80)
        )
        mask = _attribute_factor_node(
            nodes, prefix + "MASK", layer_spec.mask_attribute, (-1180, row_y - 80)
        )
        lower_coord, lower_input = _create_coordinate_node(
            nodes,
            lower,
            lower_controller,
            name=prefix + "COORD",
            location=(-930, row_y + 70),
        )
        links.new(attr.outputs["Vector"], lower_coord.inputs[lower_input])
        lower_image_node = _create_image_node(
            nodes, prefix + "IMAGE", lower_image, (-650, row_y + 70)
        )
        links.new(lower_coord.outputs["Image Coordinates"], lower_image_node.inputs["Vector"])

        artistic = _new_mix_node(
            nodes, prefix + "BLEND", f"{lower.name}: {lower_data.blend_mode}",
            lower_data.blend_mode, (-390, row_y + 100),
        )
        art_factor, art_a, art_b, art_result = _mix_color_sockets(artistic)
        if art_factor is not None:
            art_factor.default_value = 1.0
        _link_or_default(links, accumulated_color, art_a)
        if art_b is not None:
            links.new(lower_image_node.outputs["Color"], art_b)

        masked_alpha = _multiply_alpha(
            nodes, links,
            lower_image_node.outputs["Alpha"],
            _attribute_factor_output(mask),
            name=prefix + "MASK_ALPHA",
            location=(-400, row_y - 80),
        )
        effective_alpha = _multiply_alpha(
            nodes, links,
            masked_alpha,
            b_value=1.0,
            name=prefix + "LAYER_STRENGTH",
            location=(-190, row_y - 80),
        )
        strength_node = nodes.get(prefix + "LAYER_STRENGTH")
        if strength_node is not None:
            _add_layer_strength_driver(strength_node.inputs[1], lower)

        alpha_mix = _new_mix_node(
            nodes, prefix + "ALPHA_COMPOSITE", "Composite Layer", 'MIX', (40, row_y + 80)
        )
        alpha_factor, alpha_a, alpha_b, alpha_result = _mix_color_sockets(alpha_mix)
        if alpha_factor is not None:
            links.new(effective_alpha, alpha_factor)
        _link_or_default(links, accumulated_color, alpha_a)
        if alpha_b is not None and art_result is not None:
            links.new(art_result, alpha_b)
        accumulated_color = alpha_result

    # Artistic blend for the current layer. Opacity is applied later as surface
    # transparency, so the blend formula itself always uses a full-strength B.
    color_mix = _new_mix_node(
        nodes, COLOR_MIX_NODE_NAME, "Blend with Underlying Labels", blend_mode, (-170, 100)
    )
    mix_factor, mix_a, mix_b, mix_result = _mix_color_sockets(color_mix)
    if mix_factor is not None:
        mix_factor.default_value = 1.0
    _link_or_default(links, accumulated_color, mix_a)
    if mix_b is not None:
        links.new(image_node.outputs["Color"], mix_b)

    current_alpha = _multiply_alpha(
        nodes, links,
        image_node.outputs["Alpha"],
        b_value=opacity,
        name=OPACITY_NODE_NAME,
        location=(-120, -90),
    )
    opacity_node = nodes.get(OPACITY_NODE_NAME)
    if opacity_node is not None:
        _add_property_driver(opacity_node.inputs[1], label, "jb3d_labeler.opacity")

    surface_frame = nodes.new("NodeFrame")
    surface_frame.name = f"{NODE_PREFIX}SURFACE_FRAME"
    surface_frame.label = "Material: Printed Face / White Back"
    surface_frame.location = (180, -120)

    geometry_node = nodes.new("ShaderNodeNewGeometry")
    geometry_node.name = f"{NODE_PREFIX}GEOMETRY"
    geometry_node.parent = surface_frame
    geometry_node.location = (0, 260)

    front_principled = nodes.new("ShaderNodeBsdfPrincipled")
    front_principled.name = f"{NODE_PREFIX}PRINCIPLED"
    front_principled.label = "Printed Face"
    front_principled.parent = surface_frame
    front_principled.location = (0, 70)
    front_principled.inputs["Roughness"].default_value = roughness
    front_principled.inputs["Metallic"].default_value = metallic

    back_principled = nodes.new("ShaderNodeBsdfPrincipled")
    back_principled.name = f"{NODE_PREFIX}BACK_PRINCIPLED"
    back_principled.label = "White Adhesive Back"
    back_principled.parent = surface_frame
    back_principled.location = (0, -130)
    back_principled.inputs["Base Color"].default_value = (1.0, 1.0, 1.0, 1.0)
    back_principled.inputs["Roughness"].default_value = 0.5
    back_principled.inputs["Metallic"].default_value = 0.0

    side_mix = nodes.new("ShaderNodeMixShader")
    side_mix.name = f"{NODE_PREFIX}SIDE_MIX"
    side_mix.label = "Front / Back"
    side_mix.parent = surface_frame
    side_mix.location = (280, 80)

    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.name = f"{NODE_PREFIX}TRANSPARENT"
    transparent.parent = surface_frame
    transparent.location = (280, -120)

    alpha_mix = nodes.new("ShaderNodeMixShader")
    alpha_mix.name = f"{NODE_PREFIX}ALPHA_MIX"
    alpha_mix.label = "Artwork Alpha & Opacity"
    alpha_mix.parent = surface_frame
    alpha_mix.location = (510, 60)

    output = nodes.new("ShaderNodeOutputMaterial")
    output.name = f"{NODE_PREFIX}OUTPUT"
    output.location = (1050, 80)

    if mix_result is not None:
        links.new(mix_result, front_principled.inputs["Base Color"])
    else:
        links.new(image_node.outputs["Color"], front_principled.inputs["Base Color"])

    links.new(geometry_node.outputs["Backfacing"], side_mix.inputs[0])
    links.new(front_principled.outputs[0], side_mix.inputs[1])
    links.new(back_principled.outputs[0], side_mix.inputs[2])
    links.new(current_alpha, alpha_mix.inputs[0])
    links.new(transparent.outputs[0], alpha_mix.inputs[1])
    links.new(side_mix.outputs[0], alpha_mix.inputs[2])
    links.new(alpha_mix.outputs[0], output.inputs["Surface"])

    if not label.data.materials:
        label.data.materials.append(material)
    elif label.data.materials[0] != material:
        label.data.materials[0] = material

    if old_material is not None and old_material != material and old_material.users == 0:
        bpy.data.materials.remove(old_material)
    return material


def set_label_blend_mode(label: bpy.types.Object, blend_mode: str) -> bool:
    material = label.data.materials[0] if label and label.type == 'MESH' and label.data.materials else None
    if material is None or not material.use_nodes:
        return False
    node = material.node_tree.nodes.get(COLOR_MIX_NODE_NAME)
    if node is None or node.bl_idname != 'ShaderNodeMix':
        return False
    _configure_mix_color(node, blend_mode)
    return True


def update_label_material(
    label: bpy.types.Object,
    controller: bpy.types.Object,
    image: bpy.types.Image,
    roughness: float,
    metallic: float,
    blend_mode: str = 'MIX',
    opacity: float = 1.0,
) -> None:
    # V1.3 materials are cheap to rebuild and the complete rebuild guarantees the
    # node schema stays coherent after upgrades. Source-stack compositing is added
    # immediately afterwards by registry/compositor refresh calls.
    create_label_material(
        label, controller, image, roughness, metallic, blend_mode,
        opacity=opacity, underlying_layers=None,
    )

