# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import os

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup


UNWRAP_ITEMS = (
    ('AUTO', "Automatic", "Use planar projection when possible, Follow Active Quads on a quad grid, otherwise Angle Based"),
    ('PLANAR', "Metric Planar", "Metric projection onto the selection's average plane"),
    ('QUAD', "Follow Active Quads", "Unwrap from the active face using the quad grid edge lengths"),
    ('ANGLE_BASED', "Angle Based", "Unwrap organic or curved surfaces"),
    ('CONFORMAL', "Conformal", "Use conformal unwrapping"),
)

ORIENTATION_ITEMS = (
    ('AUTO', "Automatic", "Use the active edge when available, otherwise the object's Z axis"),
    ('ACTIVE_EDGE', "Active Edge Horizontal", "Align the active edge with the label's horizontal axis"),
    ('OBJECT_Z', "Object Z Axis", "Use the object's vertical axis as the label's vertical axis"),
    ('VIEW', "Current View", "Use the 3D View horizontal axis"),
)


LABEL_TYPE_ITEMS = (
    ('STANDARD', "Standard", "Create a regular label inside the selected support area"),
    ('WRAP_360', "360° Wrap", "Wrap one image exactly once around a continuous face band"),
)

WRAP_SEAM_ITEMS = (
    ('AUTO_BACK', "Automatic Back Seam", "Place the seam approximately opposite the active face"),
    ('ACTIVE_EDGE', "Active Edge", "Use the last selected vertical edge as the seam column"),
)

WRAP_AXIS_ITEMS = (
    ('AUTO', "Automatic", "Detect the band axis from its two boundary loops"),
    ('LOCAL_X', "Local X", "Use the target object's local X axis"),
    ('LOCAL_Y', "Local Y", "Use the target object's local Y axis"),
    ('LOCAL_Z', "Local Z", "Use the target object's local Z axis"),
)

ROLE_ITEMS = (
    ('NONE', "None", "Object outside the rig"),
    ('LABEL', "Label", "Label surface"),
    ('CONTROLLER', "Controller", "Position and size controller"),
    ('ANCHOR', "Anchor", "Surface tangent reference"),
)

SIZE_AXIS_ITEMS = (
    ('WIDTH', "Width", "Width is the reference dimension"),
    ('HEIGHT', "Height", "Height is the reference dimension"),
)

# Identifiers match ShaderNodeMix.blend_type.
BLEND_MODE_ITEMS = (
    ('MIX', "Mix", "Normal blend with no special effect"),
    ('ADD', "Add", "Add the colors"),
    ('SUBTRACT', "Subtract", "Subtract the colors"),
    ('MULTIPLY', "Multiply", "Multiply the colors"),
    ('SCREEN', "Screen", "Lighten using Screen mode"),
    ('DIVIDE', "Divide", "Divide the colors"),
    ('DIFFERENCE', "Difference", "Show the difference between the colors"),
    ('DARKEN', "Darken", "Keep the darkest components"),
    ('LIGHTEN', "Lighten", "Keep the lightest components"),
    ('OVERLAY', "Overlay", "Combine Multiply and Screen"),
    ('DODGE', "Color Dodge", "Lighten using Color Dodge"),
    ('BURN', "Color Burn", "Darken using Color Burn"),
    ('HUE', "Hue", "Apply the image hue"),
    ('SATURATION', "Saturation", "Apply the image saturation"),
    ('VALUE', "Value", "Apply the image value"),
    ('COLOR', "Color", "Apply the image hue and saturation"),
    ('SOFT_LIGHT', "Soft Light", "Apply Soft Light blending"),
    ('LINEAR_LIGHT', "Linear Light", "Apply Linear Light blending"),
)


def _image_ratio(data) -> float | None:
    width = int(getattr(data, "image_pixel_width", 0))
    height = int(getattr(data, "image_pixel_height", 0))
    if width <= 0 or height <= 0:
        image = getattr(data, "image", None)
        if image is not None and len(image.size) >= 2:
            width = int(image.size[0])
            height = int(image.size[1])
    if width <= 0 or height <= 0:
        return None
    return width / height


def _wrap_circumference_limit(data) -> float | None:
    if getattr(data, "label_type", 'STANDARD') != 'WRAP_360':
        return None
    circumference = float(getattr(data, "wrap_circumference", 0.0))
    return circumference if circumference > 1e-8 else None


def _clamp_wrap_width(data, ratio: float | None = None) -> None:
    """A wrap artwork cannot be physically wider than one circumference.

    Widths below the circumference are intentionally allowed: the image then acts
    as a curved partial label with transparent space around the back of the band.
    """
    limit = _wrap_circumference_limit(data)
    if limit is None or float(getattr(data, "width", 0.0)) <= limit:
        return

    data.ratio_update_lock = True
    try:
        data.width = limit
        if getattr(data, "preserve_ratio", False):
            ratio = ratio or _image_ratio(data)
            if ratio is not None and ratio > 1e-12:
                data.height = max(limit / ratio, 1e-6)
    finally:
        data.ratio_update_lock = False


def _sync_controller_size(data) -> None:
    """Push UI width/height changes to the label controller immediately."""
    label = _label_owner(data)
    if label is None or getattr(data, "role", 'NONE') != 'LABEL':
        return
    controller = getattr(data, "controller_object", None)
    if controller is None:
        return
    try:
        controller.scale.x = max(float(data.width) * 0.5, 1e-6)
        controller.scale.y = max(float(data.height) * 0.5, 1e-6)
        if getattr(data, "label_type", 'STANDARD') == 'WRAP_360':
            controller.lock_scale = (False, False, True)
            controller.lock_rotation = (True, True, True)
    except (AttributeError, RuntimeError):
        pass


def _sync_ratio(data, reference_axis: str | None = None) -> None:
    if getattr(data, "ratio_update_lock", False) or not getattr(data, "preserve_ratio", True):
        return
    ratio = _image_ratio(data)
    if ratio is None or ratio <= 1e-12:
        return

    axis = reference_axis or getattr(data, "last_edited_dimension", 'WIDTH')
    data.ratio_update_lock = True
    try:
        if axis == 'HEIGHT':
            data.width = max(float(data.height) * ratio, 1e-6)
        else:
            data.height = max(float(data.width) / ratio, 1e-6)
    finally:
        data.ratio_update_lock = False
    _clamp_wrap_width(data, ratio)


def _update_width(data, context) -> None:
    if getattr(data, "ratio_update_lock", False):
        return
    data.last_edited_dimension = 'WIDTH'
    _sync_ratio(data, 'WIDTH')
    if not getattr(data, "preserve_ratio", True):
        _clamp_wrap_width(data)
    _sync_controller_size(data)


def _update_height(data, context) -> None:
    if getattr(data, "ratio_update_lock", False):
        return
    data.last_edited_dimension = 'HEIGHT'
    _sync_ratio(data, 'HEIGHT')
    _sync_controller_size(data)


def _update_preserve_ratio(data, context) -> None:
    if data.preserve_ratio:
        _sync_ratio(data, data.last_edited_dimension)
    else:
        _clamp_wrap_width(data)
    _sync_controller_size(data)


def _update_image_path(data, context) -> None:
    if getattr(data, "ratio_update_lock", False):
        return

    path = bpy.path.abspath(getattr(data, "image_path", ""))
    if not path or not os.path.isfile(path):
        return

    try:
        image = bpy.data.images.load(path, check_existing=True)
    except Exception:
        return

    data.image = image
    data.image_pixel_width = int(image.size[0]) if len(image.size) >= 1 else 0
    data.image_pixel_height = int(image.size[1]) if len(image.size) >= 2 else 0
    _sync_ratio(data, data.last_edited_dimension)
    _sync_controller_size(data)


def _label_owner(data) -> bpy.types.Object | None:
    owner = getattr(data, "id_data", None)
    if isinstance(owner, bpy.types.Object):
        if getattr(data, "role", 'NONE') == 'LABEL':
            return owner
        linked = getattr(data, "owner_label", None)
        if isinstance(linked, bpy.types.Object):
            return linked
    return None


def _update_visibility(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    hidden = not bool(data.visible)
    try:
        label.hide_viewport = hidden
        label.hide_render = hidden
    except (AttributeError, RuntimeError):
        pass


def _select_safe_rig_part(context, data, excluded) -> None:
    if context is None:
        return
    try:
        from .utils import select_only
        for candidate in (getattr(data, "anchor_object", None), getattr(data, "controller_object", None)):
            if candidate is None or candidate == excluded or candidate.hide_select:
                continue
            select_only(context, candidate)
            return
    except Exception:
        pass


def _update_label_lock(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    try:
        was_active = context is not None and context.view_layer.objects.active == label
        label.hide_select = bool(data.label_locked)
        if data.label_locked:
            label.select_set(False)
            if was_active:
                _select_safe_rig_part(context, data, label)
    except (AttributeError, RuntimeError):
        pass


def _update_anchor_lock(data, context) -> None:
    label = _label_owner(data)
    if label is None:
        return
    anchor = getattr(data, "anchor_object", None)
    if anchor is None:
        return
    try:
        was_active = context is not None and context.view_layer.objects.active == anchor
        anchor.hide_select = bool(data.anchor_locked)
        if data.anchor_locked:
            anchor.select_set(False)
            if was_active:
                _select_safe_rig_part(context, data, anchor)
    except (AttributeError, RuntimeError):
        pass


def _refresh_compositing(data, context=None) -> None:
    label = _label_owner(data)
    if label is None:
        return
    try:
        from . import compositor
        scene = getattr(context, "scene", None) if context is not None else None
        compositor.refresh_source_stack(label, scene)
    except Exception:
        # A damaged legacy material can still be rebuilt with Update Label.
        pass


def _update_blend_mode(data, context) -> None:
    _refresh_compositing(data, context)


def _update_opacity(data, context) -> None:
    # V1.3 materials drive opacity directly from this property. No stack rebuild
    # is required while dragging the slider.
    return


def _update_active_label_index(scene, context) -> None:
    if context is None or context.scene != scene:
        return
    try:
        from . import registry
        if registry.index_selection_suspended():
            return
        from .utils import resolve_rig_from_object, select_only
        label = registry.active_label(scene)
        rig = resolve_rig_from_object(label)
        if rig is None:
            return
        target = rig.anchor if rig.anchor is not None and not label.jb3d_labeler.anchor_locked else rig.controller
        if target is not None:
            select_only(context, target)
    except Exception:
        pass


class JB3DLabelerDefaults(PropertyGroup):
    label_type: EnumProperty(name="Label Type", items=LABEL_TYPE_ITEMS, default='STANDARD')
    wrap_seam_mode: EnumProperty(name="Seam", items=WRAP_SEAM_ITEMS, default='AUTO_BACK')
    wrap_axis: EnumProperty(name="Axis", items=WRAP_AXIS_ITEMS, default='AUTO')

    image: PointerProperty(type=bpy.types.Image, options={'HIDDEN'})

    image_path: StringProperty(
        name="Image",
        description="Label image (PNG, JPG, TIFF...)",
        subtype='FILE_PATH',
        update=_update_image_path,
    )

    image_pixel_width: IntProperty(default=0, min=0, options={'HIDDEN'})
    image_pixel_height: IntProperty(default=0, min=0, options={'HIDDEN'})
    ratio_update_lock: BoolProperty(default=False, options={'HIDDEN'})
    last_edited_dimension: EnumProperty(items=SIZE_AXIS_ITEMS, default='WIDTH', options={'HIDDEN'})

    width: FloatProperty(
        name="Width",
        description="Physical label width",
        default=0.085,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_width,
    )

    height: FloatProperty(
        name="Height",
        description="Physical label height",
        default=0.120,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_height,
    )

    preserve_ratio: BoolProperty(
        name="Preserve Aspect Ratio",
        description="Automatically link width and height using the image pixel ratio",
        default=True,
        update=_update_preserve_ratio,
    )

    surface_offset: FloatProperty(
        name="Surface Offset",
        description="Distance between the product and the label",
        default=0.0002,
        min=0.0,
        soft_max=0.01,
        subtype='DISTANCE',
        unit='LENGTH',
    )

    follow_surface: BoolProperty(
        name="Follow Surface",
        description="Keep a non-destructive Shrinkwrap targeting the source object",
        default=True,
    )

    unwrap_method: EnumProperty(
        name="Unwrap",
        description="Method used to create metric UVs",
        items=UNWRAP_ITEMS,
        default='AUTO',
    )

    orientation_mode: EnumProperty(
        name="Orientation",
        description="Reference used to orient the label",
        items=ORIENTATION_ITEMS,
        default='AUTO',
    )

    roughness: FloatProperty(name="Roughness", default=0.42, min=0.0, max=1.0, subtype='FACTOR')
    metallic: FloatProperty(name="Metallic", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    pack_image: BoolProperty(
        name="Pack Image",
        description="Pack the image into the .blend file",
        default=False,
    )

    show_create_advanced: BoolProperty(name="Advanced Options", default=False)
    show_active_advanced: BoolProperty(name="Advanced Settings", default=False)
    show_maintenance: BoolProperty(name="Maintenance", default=False)


class JB3DLabelObjectData(PropertyGroup):
    label_type: EnumProperty(name="Label Type", items=LABEL_TYPE_ITEMS, default='STANDARD')
    wrap_seam_mode: EnumProperty(name="Seam", items=WRAP_SEAM_ITEMS, default='AUTO_BACK')
    wrap_axis: EnumProperty(name="Axis", items=WRAP_AXIS_ITEMS, default='AUTO')
    applied_wrap_seam_mode: StringProperty(default="", options={'HIDDEN'})
    applied_wrap_axis: StringProperty(default="", options={'HIDDEN'})

    role: EnumProperty(items=ROLE_ITEMS, default='NONE', options={'HIDDEN'})
    rig_uuid: StringProperty(name="Rig UUID", options={'HIDDEN'})
    data_version: IntProperty(default=8, options={'HIDDEN'})

    owner_label: PointerProperty(type=bpy.types.Object)
    source_object: PointerProperty(type=bpy.types.Object)
    controller_object: PointerProperty(type=bpy.types.Object)
    anchor_object: PointerProperty(type=bpy.types.Object)
    image: PointerProperty(type=bpy.types.Image)

    image_path: StringProperty(
        name="Image",
        description="Image file used by this label",
        subtype='FILE_PATH',
        update=_update_image_path,
    )

    image_pixel_width: IntProperty(default=0, min=0, options={'HIDDEN'})
    image_pixel_height: IntProperty(default=0, min=0, options={'HIDDEN'})
    ratio_update_lock: BoolProperty(default=False, options={'HIDDEN'})
    last_edited_dimension: EnumProperty(items=SIZE_AXIS_ITEMS, default='WIDTH', options={'HIDDEN'})

    width: FloatProperty(
        name="Width",
        description="Physical artwork width; for 360° Wrap it may be smaller than the circumference",
        default=0.085,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_width,
    )

    height: FloatProperty(
        name="Height",
        description="Physical artwork height along the wrap band",
        default=0.120,
        min=0.0001,
        soft_max=2.0,
        subtype='DISTANCE',
        unit='LENGTH',
        update=_update_height,
    )

    preserve_ratio: BoolProperty(
        name="Preserve Aspect Ratio",
        description="Keep the image proportions when resizing; disable to stretch width and height independently",
        default=True,
        update=_update_preserve_ratio,
    )

    surface_offset: FloatProperty(
        name="Surface Offset",
        default=0.0002,
        min=0.0,
        soft_max=0.01,
        subtype='DISTANCE',
        unit='LENGTH',
    )

    follow_surface: BoolProperty(name="Follow Surface", default=True)
    unwrap_method: EnumProperty(name="Unwrap", items=UNWRAP_ITEMS, default='AUTO')
    orientation_mode: EnumProperty(name="Orientation", items=ORIENTATION_ITEMS, default='AUTO')
    applied_unwrap_method: StringProperty(default="", options={'HIDDEN'})
    applied_orientation_mode: StringProperty(default="", options={'HIDDEN'})

    roughness: FloatProperty(name="Roughness", default=0.42, min=0.0, max=1.0, subtype='FACTOR')
    metallic: FloatProperty(name="Metallic", default=0.0, min=0.0, max=1.0, subtype='FACTOR')
    pack_image: BoolProperty(name="Pack Image", default=False)

    visible: BoolProperty(
        name="Visible",
        description="Show the label in the viewport and render",
        default=True,
        update=_update_visibility,
    )
    label_locked: BoolProperty(
        name="Lock Surface",
        description="Prevent direct label surface selection in the viewport and Outliner",
        default=True,
        update=_update_label_lock,
    )
    anchor_locked: BoolProperty(
        name="Lock Anchor",
        description="Prevent anchor selection and manipulation",
        default=False,
        update=_update_anchor_lock,
    )
    blend_mode: EnumProperty(
        name="Blend",
        description="Blend this artwork with visible labels underneath it on the same product",
        items=BLEND_MODE_ITEMS,
        default='MIX',
        update=_update_blend_mode,
    )
    opacity: FloatProperty(
        name="Opacity",
        description="Overall opacity of this label layer",
        default=1.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_update_opacity,
    )
    composite_layer_count: IntProperty(default=0, min=0, options={'HIDDEN'})
    composite_status: StringProperty(default="", options={'HIDDEN'})
    stack_order: IntProperty(default=0, options={'HIDDEN'})
    stack_bias: FloatProperty(default=0.0, options={'HIDDEN'})

    active_face_index: IntProperty(default=-1, options={'HIDDEN'})
    active_edge_v0: IntProperty(default=-1, options={'HIDDEN'})
    active_edge_v1: IntProperty(default=-1, options={'HIDDEN'})

    distortion_rms: FloatProperty(default=0.0, options={'HIDDEN'})
    distortion_u: FloatProperty(default=0.0, options={'HIDDEN'})
    distortion_v: FloatProperty(default=0.0, options={'HIDDEN'})
    available_width: FloatProperty(default=0.0, options={'HIDDEN'})
    available_height: FloatProperty(default=0.0, options={'HIDDEN'})
    last_unwrap_used: StringProperty(default="", options={'HIDDEN'})

    wrap_circumference: FloatProperty(default=0.0, min=0.0, subtype='DISTANCE', unit='LENGTH', options={'HIDDEN'})
    wrap_top_length: FloatProperty(default=0.0, min=0.0, subtype='DISTANCE', unit='LENGTH', options={'HIDDEN'})
    wrap_bottom_length: FloatProperty(default=0.0, min=0.0, subtype='DISTANCE', unit='LENGTH', options={'HIDDEN'})
    wrap_height: FloatProperty(default=0.0, min=0.0, subtype='DISTANCE', unit='LENGTH', options={'HIDDEN'})
    wrap_physical_ratio: FloatProperty(default=0.0, min=0.0, options={'HIDDEN'})
    taper_percentage: FloatProperty(default=0.0, min=0.0, options={'HIDDEN'})
    wrap_seam_column: IntProperty(default=-1, options={'HIDDEN'})
    wrap_anchor_u: FloatProperty(default=0.5, options={'HIDDEN'})
    wrap_anchor_v: FloatProperty(default=0.5, options={'HIDDEN'})


class JB3DLabelListItem(PropertyGroup):
    label: PointerProperty(type=bpy.types.Object)


_CLASSES = (
    JB3DLabelerDefaults,
    JB3DLabelObjectData,
    JB3DLabelListItem,
)


def _registered_class(cls):
    if getattr(cls, "is_registered", False):
        return cls
    for base in cls.__bases__:
        for candidate in base.__subclasses__():
            if candidate.__name__ == cls.__name__ and candidate.__module__ == cls.__module__:
                if getattr(candidate, "is_registered", False):
                    return candidate
    return None


def _registered_classes_are_current() -> bool:
    return all(_registered_class(cls) is cls for cls in _CLASSES)


def _rna_properties_are_registered() -> bool:
    return (
        hasattr(bpy.types.Object, "jb3d_labeler")
        and hasattr(bpy.types.Scene, "jb3d_labeler")
        and hasattr(bpy.types.Scene, "jb3d_label_items")
        and hasattr(bpy.types.Scene, "jb3d_label_index")
    )


def _remove_rna_properties() -> None:
    if hasattr(bpy.types.Object, "jb3d_labeler"):
        delattr(bpy.types.Object, "jb3d_labeler")
    for name in ("jb3d_label_index", "jb3d_label_items", "jb3d_labeler"):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)


def _unregister_classes() -> None:
    for cls in reversed(_CLASSES):
        registered = _registered_class(cls)
        if registered is not None:
            bpy.utils.unregister_class(registered)


def register():
    if _registered_classes_are_current() and _rna_properties_are_registered():
        return

    _remove_rna_properties()
    _unregister_classes()
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.jb3d_labeler = PointerProperty(type=JB3DLabelObjectData)
    bpy.types.Scene.jb3d_labeler = PointerProperty(type=JB3DLabelerDefaults)
    bpy.types.Scene.jb3d_label_items = CollectionProperty(type=JB3DLabelListItem)
    bpy.types.Scene.jb3d_label_index = IntProperty(name="Active Label", default=0, min=0, update=_update_active_label_index)


def unregister():
    _remove_rna_properties()
    _unregister_classes()
