# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import math
import os
import statistics
import uuid
from dataclasses import dataclass
from typing import Optional

import bpy
import bmesh
from mathutils import Matrix, Vector, geometry


ROLE_KEY = "jb3d_labeler_role"
ROLE_LABEL = "LABEL"
ROLE_CONTROLLER = "CONTROLLER"
ROLE_ANCHOR = "ANCHOR"
UV_NAME = "JB3D_Label_UV"
SOURCE_FACE_ATTRIBUTE = "JB3D_Source_Face"
SOURCE_VERTEX_ATTRIBUTE = "JB3D_Source_Vertex"
SHRINKWRAP_NAME = "JB3D Surface Follow"
SOURCE_SUBSURF_NAME = "JB3D Source Subdivision"
CURRENT_DATA_VERSION = 8


@dataclass
class LabelRig:
    label: bpy.types.Object
    controller: Optional[bpy.types.Object]
    anchor: Optional[bpy.types.Object]
    source: Optional[bpy.types.Object]


@dataclass
class SelectionReference:
    active_face_index: int = -1
    active_edge_vertices: Optional[tuple[int, int]] = None
    view_right_world: Optional[Vector] = None


@dataclass
class UVAnalysis:
    rms: float = 0.0
    u: float = 0.0
    v: float = 0.0
    width: float = 0.0
    height: float = 0.0


@dataclass
class FitReport:
    fits: bool
    overflow: float
    support_width: float
    support_height: float


def ensure_collection(context: bpy.types.Context) -> bpy.types.Collection:
    name = "JB3D_LABELS"
    collection = bpy.data.collections.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
        context.scene.collection.children.link(collection)
    return collection


def select_only(context: bpy.types.Context, obj: bpy.types.Object) -> None:
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for item in context.selected_objects:
        item.select_set(False)
    obj.hide_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


def unique_label_name() -> str:
    index = 1
    while bpy.data.objects.get(f"JB3D_Label_{index:03d}"):
        index += 1
    return f"JB3D_Label_{index:03d}"


def current_view_right(context: bpy.types.Context) -> Optional[Vector]:
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        return None
    try:
        direction = region_data.view_rotation @ Vector((1.0, 0.0, 0.0))
        return direction.normalized() if direction.length_squared > 1e-16 else None
    except Exception:
        return None


def _legacy_object(name: str) -> Optional[bpy.types.Object]:
    return bpy.data.objects.get(name) if name else None


def migrate_legacy_label(label: bpy.types.Object) -> None:
    """Upgrade a 0.1 rig in-place when it is first selected."""
    if label is None or not hasattr(label, "jb3d_labeler"):
        return

    data = label.jb3d_labeler
    previous_version = int(data.data_version)
    if data.role == ROLE_LABEL and data.data_version >= CURRENT_DATA_VERSION:
        return
    stored_width = float(getattr(data, "width", 0.0))
    stored_height = float(getattr(data, "height", 0.0))
    upgrading_v11_wrap = previous_version == 6 and getattr(data, "label_type", 'STANDARD') == 'WRAP_360'
    if label.get(ROLE_KEY) != ROLE_LABEL and data.role != ROLE_LABEL:
        return

    controller = data.controller_object or _legacy_object(label.get("jb3d_controller_name", ""))
    anchor = data.anchor_object or _legacy_object(label.get("jb3d_anchor_name", ""))
    source = data.source_object or _legacy_object(label.get("jb3d_source_name", ""))
    image = data.image or bpy.data.images.get(label.get("jb3d_image_name", ""))

    data.role = ROLE_LABEL
    data.rig_uuid = data.rig_uuid or str(uuid.uuid4())
    if previous_version < 6:
        data.label_type = 'STANDARD'
    data.data_version = CURRENT_DATA_VERSION
    data.source_object = source
    data.controller_object = controller
    data.anchor_object = anchor
    data.image = image
    if image is not None:
        data.ratio_update_lock = True
        try:
            if not data.image_path:
                data.image_path = image.filepath or image.filepath_raw
            data.image_pixel_width = int(image.size[0]) if len(image.size) >= 1 else 0
            data.image_pixel_height = int(image.size[1]) if len(image.size) >= 2 else 0
        finally:
            data.ratio_update_lock = False

    data.ratio_update_lock = True
    try:
        if upgrading_v11_wrap:
            # V1.1 stored the correct physical wrap dimensions in the label data,
            # while its controller was deliberately fixed at scale (1, 1, 1).
            # Preserve those dimensions when enabling V1.2 live artwork scaling.
            data.width = max(stored_width, float(getattr(data, "wrap_circumference", 0.0)), 1e-6)
            data.height = max(stored_height, float(getattr(data, "wrap_height", 0.0)), 1e-6)
        elif controller is not None:
            data.width = abs(controller.scale.x) * 2.0
            data.height = abs(controller.scale.y) * 2.0
        else:
            data.width = float(label.get("jb3d_original_width", data.width))
            data.height = float(label.get("jb3d_original_height", data.height))
    finally:
        data.ratio_update_lock = False

    data.distortion_rms = float(label.get("jb3d_distortion_percent", 0.0))
    if not data.applied_unwrap_method:
        data.applied_unwrap_method = data.unwrap_method
    if not data.applied_orientation_mode:
        data.applied_orientation_mode = data.orientation_mode

    if previous_version < 5:
        # Version 0.5 defaults: the generated support mesh is protected from
        # accidental Outliner/viewport selection, while the anchor remains free.
        data.visible = not bool(label.hide_viewport or label.hide_render)
        data.label_locked = True
        data.anchor_locked = False
        data.blend_mode = 'MIX'
        data.stack_bias = 0.0

    for obj, role in ((controller, ROLE_CONTROLLER), (anchor, ROLE_ANCHOR)):
        if obj is None or not hasattr(obj, "jb3d_labeler"):
            continue
        part = obj.jb3d_labeler
        part.role = role
        part.rig_uuid = data.rig_uuid
        part.data_version = CURRENT_DATA_VERSION
        part.owner_label = label
        obj[ROLE_KEY] = role
        obj["jb3d_label_name"] = label.name

    if controller is not None and data.label_type == 'WRAP_360':
        # V1.2 uses physical controller scale for wrap artwork size.
        controller.empty_display_type = 'CUBE'
        controller.empty_display_size = 1.0
        controller.scale.x = max(float(data.width) * 0.5, 1e-6)
        controller.scale.y = max(float(data.height) * 0.5, 1e-6)
        controller.scale.z = max(min(float(data.width), float(data.height)) * 0.01, 1e-6)
        controller.lock_scale = (False, False, True)
        controller.lock_rotation = (True, True, True)

    label[ROLE_KEY] = ROLE_LABEL
    if controller:
        label["jb3d_controller_name"] = controller.name
    if anchor:
        label["jb3d_anchor_name"] = anchor.name
    if source:
        label["jb3d_source_name"] = source.name

    rig = LabelRig(label=label, controller=controller, anchor=anchor, source=source)
    ensure_rig_parenting(rig)
    label.hide_select = data.label_locked
    label.hide_viewport = not data.visible
    label.hide_render = not data.visible
    if anchor is not None:
        anchor.hide_select = data.anchor_locked
    if anchor is not None:
        try:
            frame_offset = data.surface_offset if data.follow_surface else 0.0
            update_anchor_frame(rig, frame_offset)
        except Exception:
            # A damaged legacy UV map can still be repaired with the maintenance button.
            pass

    if upgrading_v11_wrap and controller is not None and image is not None:
        try:
            # Local import avoids a module-level utils/materials dependency cycle.
            from . import materials
            materials.update_label_material(
                label, controller, image, data.roughness, data.metallic, data.blend_mode,
                data.opacity,
            )
        except Exception:
            # The regular Update Label action can still rebuild a damaged material.
            pass


def resolve_rig_from_object(obj: Optional[bpy.types.Object]) -> Optional[LabelRig]:
    if obj is None or not hasattr(obj, "jb3d_labeler"):
        return None

    data = obj.jb3d_labeler
    role = data.role

    if role == 'NONE':
        legacy_role = obj.get(ROLE_KEY)
        if legacy_role == ROLE_LABEL:
            migrate_legacy_label(obj)
            role = obj.jb3d_labeler.role
        elif legacy_role in {ROLE_CONTROLLER, ROLE_ANCHOR}:
            label = _legacy_object(obj.get("jb3d_label_name", ""))
            if label:
                migrate_legacy_label(label)
                role = obj.jb3d_labeler.role

    if role == ROLE_LABEL:
        label = obj
        migrate_legacy_label(label)
    elif role in {ROLE_CONTROLLER, ROLE_ANCHOR}:
        label = data.owner_label
        if label is None:
            label = _legacy_object(obj.get("jb3d_label_name", ""))
        if label is None:
            return None
        migrate_legacy_label(label)
    else:
        return None

    label_data = label.jb3d_labeler
    return LabelRig(
        label=label,
        controller=label_data.controller_object,
        anchor=label_data.anchor_object,
        source=label_data.source_object,
    )


def load_image(path: str, pack: bool = False) -> bpy.types.Image:
    absolute = bpy.path.abspath(path)
    if not absolute or not os.path.isfile(absolute):
        raise FileNotFoundError("Image file not found.")

    image = bpy.data.images.load(absolute, check_existing=True)
    if pack and not image.packed_file:
        image.pack()
    return image


def _ensure_int_attribute(mesh: bpy.types.Mesh, name: str, domain: str):
    attribute = mesh.attributes.get(name)
    if attribute is not None and (attribute.data_type != 'INT' or attribute.domain != domain):
        mesh.attributes.remove(attribute)
        attribute = None
    if attribute is None:
        attribute = mesh.attributes.new(name=name, type='INT', domain=domain)
    return attribute


def _coord_key(vector: Vector, precision: int = 8) -> tuple[float, float, float]:
    return (round(float(vector.x), precision), round(float(vector.y), precision), round(float(vector.z), precision))


def ensure_source_mapping(label: bpy.types.Object) -> None:
    """Ensure the label mesh remembers the product face/vertex it came from.

    V1.3 stores this mapping at creation time. Older V1.x files are upgraded by
    matching the untouched base coordinates of the generated label mesh against
    the source mesh. Only JB3D-owned label meshes are modified.
    """
    if label is None or label.type != 'MESH' or not hasattr(label, 'jb3d_labeler'):
        raise ValueError('Expected a JB3D label mesh')
    source = label.jb3d_labeler.source_object
    if source is None or source.type != 'MESH':
        raise ValueError('The label has no valid source product')

    mesh = label.data
    face_attr = mesh.attributes.get(SOURCE_FACE_ATTRIBUTE)
    vert_attr = mesh.attributes.get(SOURCE_VERTEX_ATTRIBUTE)
    face_valid = (
        face_attr is not None and face_attr.data_type == 'INT' and face_attr.domain == 'FACE'
        and len(face_attr.data) == len(mesh.polygons)
        and all(0 <= int(item.value) < len(source.data.polygons) for item in face_attr.data)
    )
    vert_valid = (
        vert_attr is not None and vert_attr.data_type == 'INT' and vert_attr.domain == 'POINT'
        and len(vert_attr.data) == len(mesh.vertices)
        and all(0 <= int(item.value) < len(source.data.vertices) for item in vert_attr.data)
    )
    if face_valid and vert_valid:
        return

    source_mesh = source.data
    # Face signatures are independent of winding and survive the exact face copy
    # performed by JB3D Labeler. Rounding only guards against harmless float I/O.
    source_faces: dict[tuple, list[int]] = {}
    for polygon in source_mesh.polygons:
        signature = tuple(sorted(_coord_key(source_mesh.vertices[index].co) for index in polygon.vertices))
        source_faces.setdefault(signature, []).append(polygon.index)

    mapped_faces: list[int] = [-1] * len(mesh.polygons)
    used_source_faces: set[int] = set()
    for polygon in mesh.polygons:
        signature = tuple(sorted(_coord_key(mesh.vertices[index].co) for index in polygon.vertices))
        candidates = source_faces.get(signature, [])
        candidate = next((index for index in candidates if index not in used_source_faces), None)
        if candidate is None and candidates:
            candidate = candidates[0]
        if candidate is None:
            raise ValueError(f'Cannot map label face {polygon.index} back to the product topology')
        mapped_faces[polygon.index] = int(candidate)
        used_source_faces.add(int(candidate))

    mapped_vertices: list[int] = [-1] * len(mesh.vertices)
    # Resolve vertices inside their mapped source face first; this disambiguates
    # duplicated coordinates that can exist elsewhere on a product mesh.
    for polygon in mesh.polygons:
        source_polygon = source_mesh.polygons[mapped_faces[polygon.index]]
        by_coord: dict[tuple, list[int]] = {}
        for source_vertex in source_polygon.vertices:
            by_coord.setdefault(_coord_key(source_mesh.vertices[source_vertex].co), []).append(source_vertex)
        for label_vertex in polygon.vertices:
            key = _coord_key(mesh.vertices[label_vertex].co)
            candidates = by_coord.get(key, [])
            if not candidates:
                raise ValueError(f'Cannot map label vertex {label_vertex} back to the product topology')
            current = mapped_vertices[label_vertex]
            if current < 0:
                mapped_vertices[label_vertex] = int(candidates[0])
            elif current not in candidates:
                raise ValueError('Inconsistent product vertex mapping detected')

    face_attr = _ensure_int_attribute(mesh, SOURCE_FACE_ATTRIBUTE, 'FACE')
    vert_attr = _ensure_int_attribute(mesh, SOURCE_VERTEX_ATTRIBUTE, 'POINT')
    for index, value in enumerate(mapped_faces):
        face_attr.data[index].value = value
    for index, value in enumerate(mapped_vertices):
        vert_attr.data[index].value = value


def selected_face_island_count(bm: bmesh.types.BMesh) -> int:
    selected = {face for face in bm.faces if face.select}
    if not selected:
        return 0

    islands = 0
    remaining = set(selected)
    while remaining:
        islands += 1
        stack = [remaining.pop()]
        while stack:
            face = stack.pop()
            for edge in face.edges:
                for linked in edge.link_faces:
                    if linked in remaining:
                        remaining.remove(linked)
                        stack.append(linked)
    return islands


def copy_selected_faces(
    source: bpy.types.Object,
    collection: bpy.types.Collection,
    name: str,
    view_right_world: Optional[Vector] = None,
) -> tuple[bpy.types.Object, SelectionReference]:
    bm = bmesh.from_edit_mesh(source.data)
    bm.faces.ensure_lookup_table()
    bm.verts.ensure_lookup_table()
    bm.faces.index_update()
    bm.verts.index_update()

    selected_faces = [face for face in bm.faces if face.select]
    if not selected_faces:
        raise ValueError("No faces selected.")

    active_face = bm.faces.active if bm.faces.active in selected_faces else None
    active_face_new_index = selected_faces.index(active_face) if active_face else -1

    used_verts = []
    used_set = set()
    for face in selected_faces:
        for vert in face.verts:
            if vert not in used_set:
                used_set.add(vert)
                used_verts.append(vert)

    index_map = {vert: index for index, vert in enumerate(used_verts)}

    active_edge = None
    # bm.faces.active and the active edge are independent concepts. Search the
    # selection history backwards so a face can remain the centre reference
    # while the most recently used edge defines the horizontal direction.
    for element in reversed(list(bm.select_history)):
        if isinstance(element, bmesh.types.BMEdge) and element.select:
            active_edge = element
            break

    ordered_edge = None
    if active_edge is not None:
        if active_face is not None and active_edge in active_face.edges:
            for loop in active_face.loops:
                if loop.edge == active_edge:
                    ordered_edge = (
                        index_map.get(loop.vert, -1),
                        index_map.get(loop.link_loop_next.vert, -1),
                    )
                    break
        if ordered_edge is None and all(vert in index_map for vert in active_edge.verts):
            ordered_edge = (index_map[active_edge.verts[0]], index_map[active_edge.verts[1]])
        if ordered_edge and min(ordered_edge) < 0:
            ordered_edge = None

    vertices = [vert.co.copy() for vert in used_verts]
    faces = [[index_map[vert] for vert in face.verts] for face in selected_faces]

    mesh = bpy.data.meshes.new(f"{name}_Mesh")
    mesh.from_pydata(vertices, [], faces)
    mesh.update(calc_edges=True)

    # Persistent topology provenance used by V1.3 layer compositing. These are
    # internal attributes on the generated label mesh, never on the product.
    face_attribute = _ensure_int_attribute(mesh, SOURCE_FACE_ATTRIBUTE, 'FACE')
    vertex_attribute = _ensure_int_attribute(mesh, SOURCE_VERTEX_ATTRIBUTE, 'POINT')
    for new_index, old_face in enumerate(selected_faces):
        face_attribute.data[new_index].value = int(old_face.index)
    for old_vert, new_index in index_map.items():
        vertex_attribute.data[new_index].value = int(old_vert.index)

    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    obj.matrix_world = source.matrix_world.copy()

    for new_poly, old_face in zip(mesh.polygons, selected_faces):
        new_poly.use_smooth = old_face.smooth

    reference = SelectionReference(
        active_face_index=active_face_new_index,
        active_edge_vertices=ordered_edge,
        view_right_world=view_right_world.copy() if view_right_world else None,
    )
    return obj, reference


def average_world_normal(obj: bpy.types.Object) -> Vector:
    mesh = obj.data
    normal = Vector((0.0, 0.0, 0.0))
    normal_matrix = obj.matrix_world.to_3x3().inverted_safe().transposed()
    for poly in mesh.polygons:
        area = max(poly.area, 1e-12)
        world_normal = normal_matrix @ poly.normal
        if world_normal.length_squared > 1e-16:
            normal += world_normal.normalized() * area
    if normal.length_squared < 1e-16:
        normal = obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
    return normal.normalized()


def surface_is_nearly_planar(obj: bpy.types.Object, threshold_degrees: float = 8.0) -> bool:
    avg = average_world_normal(obj)
    normal_matrix = obj.matrix_world.to_3x3().inverted_safe().transposed()
    threshold = math.cos(math.radians(threshold_degrees))
    for poly in obj.data.polygons:
        world_normal = normal_matrix @ poly.normal
        if world_normal.length_squared < 1e-16:
            continue
        if world_normal.normalized().dot(avg) < threshold:
            return False
    return True


def all_faces_are_quads(obj: bpy.types.Object) -> bool:
    return bool(obj.data.polygons) and all(len(poly.vertices) == 4 for poly in obj.data.polygons)


def ensure_uv_layer(mesh: bpy.types.Mesh) -> bpy.types.MeshUVLoopLayer:
    layer = mesh.uv_layers.get(UV_NAME)
    if layer is None:
        layer = mesh.uv_layers.new(name=UV_NAME)
    mesh.uv_layers.active = layer
    try:
        mesh.uv_layers.active_render = layer
    except Exception:
        pass
    return layer


def _active_poly_center_world(obj: bpy.types.Object, active_face_index: int) -> Vector:
    mesh = obj.data
    if 0 <= active_face_index < len(mesh.polygons):
        poly = mesh.polygons[active_face_index]
        points = [obj.matrix_world @ mesh.vertices[index].co for index in poly.vertices]
        if points:
            return sum(points, Vector()) / len(points)
    points = [obj.matrix_world @ vert.co for vert in mesh.vertices]
    return sum(points, Vector()) / max(len(points), 1)


def _world_edge_direction(obj: bpy.types.Object, vertices: Optional[tuple[int, int]]) -> Optional[Vector]:
    if vertices is None:
        return None
    v0, v1 = vertices
    mesh = obj.data
    if min(v0, v1) < 0 or max(v0, v1) >= len(mesh.vertices):
        return None
    direction = (obj.matrix_world @ mesh.vertices[v1].co) - (obj.matrix_world @ mesh.vertices[v0].co)
    return direction.normalized() if direction.length_squared > 1e-16 else None


def _project_to_tangent(vector: Optional[Vector], normal: Vector) -> Optional[Vector]:
    if vector is None:
        return None
    projected = vector - normal * vector.dot(normal)
    return projected.normalized() if projected.length_squared > 1e-16 else None


def _metric_axes(
    obj: bpy.types.Object,
    normal: Vector,
    orientation_mode: str,
    active_edge_vertices: Optional[tuple[int, int]],
    view_right_world: Optional[Vector],
) -> tuple[Vector, Vector]:
    tangent_u = None
    if orientation_mode in {'AUTO', 'ACTIVE_EDGE'}:
        tangent_u = _project_to_tangent(_world_edge_direction(obj, active_edge_vertices), normal)
        if orientation_mode == 'ACTIVE_EDGE' and tangent_u is None:
            raise ValueError("No usable active edge. Select an edge last.")

    if tangent_u is None and orientation_mode == 'VIEW':
        tangent_u = _project_to_tangent(view_right_world, normal)

    if tangent_u is None:
        object_up = obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
        tangent_v = _project_to_tangent(object_up, normal)
        if tangent_v is None:
            helper = Vector((1.0, 0.0, 0.0))
            if abs(normal.dot(helper)) > 0.9:
                helper = Vector((0.0, 1.0, 0.0))
            tangent_v = _project_to_tangent(helper, normal)
        tangent_u = tangent_v.cross(normal).normalized()
        return tangent_u, tangent_v

    tangent_v = normal.cross(tangent_u)
    if tangent_v.length_squared < 1e-16:
        raise ValueError("Cannot build the tangent orientation.")
    tangent_v.normalize()
    return tangent_u, tangent_v


def planar_metric_uv(obj: bpy.types.Object, reference: SelectionReference, orientation_mode: str) -> None:
    mesh = obj.data
    uv_layer = ensure_uv_layer(mesh)
    normal = average_world_normal(obj)
    tangent_u, tangent_v = _metric_axes(
        obj,
        normal,
        orientation_mode,
        reference.active_edge_vertices,
        reference.view_right_world,
    )
    center = _active_poly_center_world(obj, reference.active_face_index)
    world_positions = [obj.matrix_world @ vert.co for vert in mesh.vertices]

    for poly in mesh.polygons:
        for loop_index in poly.loop_indices:
            vertex_index = mesh.loops[loop_index].vertex_index
            delta = world_positions[vertex_index] - center
            uv_layer.data[loop_index].uv = (delta.dot(tangent_u), delta.dot(tangent_v))


def _iter_polygon_uv_edges(mesh: bpy.types.Mesh):
    uv_layer = mesh.uv_layers.active
    if uv_layer is None:
        return
    for poly in mesh.polygons:
        loops = list(poly.loop_indices)
        for index, loop_a in enumerate(loops):
            loop_b = loops[(index + 1) % len(loops)]
            vert_a = mesh.loops[loop_a].vertex_index
            vert_b = mesh.loops[loop_b].vertex_index
            yield loop_a, loop_b, vert_a, vert_b


def _uniform_metric_scale(obj: bpy.types.Object) -> float:
    mesh = obj.data
    uv_layer = mesh.uv_layers.active
    if uv_layer is None:
        return 1.0

    ratios = []
    for loop_a, loop_b, vert_a, vert_b in _iter_polygon_uv_edges(mesh):
        uv_length = (uv_layer.data[loop_b].uv - uv_layer.data[loop_a].uv).length
        world_a = obj.matrix_world @ mesh.vertices[vert_a].co
        world_b = obj.matrix_world @ mesh.vertices[vert_b].co
        world_length = (world_b - world_a).length
        if uv_length > 1e-10 and world_length > 1e-10:
            ratios.append(world_length / uv_length)

    if not ratios:
        return 1.0
    scale = statistics.median(ratios)
    for item in uv_layer.data:
        item.uv *= scale
    return scale


def _rotate_uvs(mesh: bpy.types.Mesh, angle: float) -> None:
    uv_layer = mesh.uv_layers.active
    if uv_layer is None:
        return
    cos_r = math.cos(angle)
    sin_r = math.sin(angle)
    for item in uv_layer.data:
        x, y = item.uv
        item.uv = (cos_r * x - sin_r * y, sin_r * x + cos_r * y)


def _uv_direction_for_edge(obj: bpy.types.Object, vertices: tuple[int, int]) -> Optional[Vector]:
    mesh = obj.data
    uv_layer = mesh.uv_layers.active
    v0, v1 = vertices
    directions = []
    for loop_a, loop_b, vert_a, vert_b in _iter_polygon_uv_edges(mesh):
        if vert_a == v0 and vert_b == v1:
            directions.append(uv_layer.data[loop_b].uv - uv_layer.data[loop_a].uv)
        elif vert_a == v1 and vert_b == v0:
            directions.append(uv_layer.data[loop_a].uv - uv_layer.data[loop_b].uv)
    directions = [item for item in directions if item.length_squared > 1e-16]
    if not directions:
        return None
    result = sum(directions, Vector((0.0, 0.0)))
    return result.normalized() if result.length_squared > 1e-16 else directions[0].normalized()


def _uv_gradient_for_world_vector(obj: bpy.types.Object, world_vector: Vector) -> Optional[Vector]:
    mesh = obj.data
    uv_layer = mesh.uv_layers.active
    if uv_layer is None or world_vector.length_squared < 1e-16:
        return None
    target = world_vector.normalized()
    a00 = a01 = a11 = 0.0
    b0 = b1 = 0.0
    for loop_a, loop_b, vert_a, vert_b in _iter_polygon_uv_edges(mesh):
        duv = uv_layer.data[loop_b].uv - uv_layer.data[loop_a].uv
        if duv.length_squared < 1e-16:
            continue
        world_a = obj.matrix_world @ mesh.vertices[vert_a].co
        world_b = obj.matrix_world @ mesh.vertices[vert_b].co
        value = (world_b - world_a).dot(target)
        a00 += duv.x * duv.x
        a01 += duv.x * duv.y
        a11 += duv.y * duv.y
        b0 += duv.x * value
        b1 += duv.y * value
    determinant = a00 * a11 - a01 * a01
    if abs(determinant) < 1e-14:
        return None
    gradient = Vector((
        (b0 * a11 - b1 * a01) / determinant,
        (a00 * b1 - a01 * b0) / determinant,
    ))
    return gradient.normalized() if gradient.length_squared > 1e-16 else None


def orient_uvs(obj: bpy.types.Object, reference: SelectionReference, orientation_mode: str) -> None:
    direction = None
    desired_angle = 0.0

    if orientation_mode in {'AUTO', 'ACTIVE_EDGE'} and reference.active_edge_vertices:
        direction = _uv_direction_for_edge(obj, reference.active_edge_vertices)
        desired_angle = 0.0
    elif orientation_mode == 'ACTIVE_EDGE':
        raise ValueError("No usable active edge. Select an edge last.")
    elif orientation_mode == 'VIEW' and reference.view_right_world is not None:
        direction = _uv_gradient_for_world_vector(obj, reference.view_right_world)
        desired_angle = 0.0

    if direction is None:
        object_up = obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
        direction = _uv_gradient_for_world_vector(obj, object_up)
        desired_angle = math.pi * 0.5

    if direction is None:
        return
    current_angle = math.atan2(direction.y, direction.x)
    _rotate_uvs(obj.data, desired_angle - current_angle)


def center_uvs(mesh: bpy.types.Mesh, active_face_index: int = -1) -> None:
    uv_layer = mesh.uv_layers.active
    if uv_layer is None or not uv_layer.data:
        return

    if 0 <= active_face_index < len(mesh.polygons):
        poly = mesh.polygons[active_face_index]
        values = [uv_layer.data[index].uv.copy() for index in poly.loop_indices]
        center = sum(values, Vector((0.0, 0.0))) / max(len(values), 1)
    else:
        xs = [item.uv.x for item in uv_layer.data]
        ys = [item.uv.y for item in uv_layer.data]
        center = Vector(((min(xs) + max(xs)) * 0.5, (min(ys) + max(ys)) * 0.5))

    for item in uv_layer.data:
        item.uv -= center


def _seed_active_quad_uv(obj: bpy.types.Object, reference: SelectionReference) -> None:
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.verts.ensure_lookup_table()
    if not (0 <= reference.active_face_index < len(bm.faces)):
        raise ValueError("Follow Active Quads requires an active face.")

    face = bm.faces[reference.active_face_index]
    if len(face.loops) != 4:
        raise ValueError("The active face must be a quad.")

    bm.faces.active = face
    uv_layer = bm.loops.layers.uv.verify()
    loops = list(face.loops)

    start = 0
    if reference.active_edge_vertices:
        wanted = set(reference.active_edge_vertices)
        for index, loop in enumerate(loops):
            if {loop.vert.index, loop.link_loop_next.vert.index} == wanted:
                start = index
                break
    loops = loops[start:] + loops[:start]

    world = [obj.matrix_world @ loop.vert.co for loop in loops]
    width = max((world[1] - world[0]).length, 1e-8)
    side_a = (world[2] - world[1]).length
    side_b = (world[3] - world[0]).length
    height = max((side_a + side_b) * 0.5, 1e-8)

    rectangle = ((0.0, 0.0), (width, 0.0), (width, height), (0.0, height))
    for loop, uv in zip(loops, rectangle):
        loop[uv_layer].uv = uv
        loop[uv_layer].select = True
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _prepare_edit_uv(context: bpy.types.Context, obj: bpy.types.Object, active_face_index: int) -> None:
    ensure_uv_layer(obj.data)
    select_only(context, obj)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    if 0 <= active_face_index < len(bm.faces):
        bm.faces.active = bm.faces[active_face_index]
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def follow_active_quads_uv(context: bpy.types.Context, obj: bpy.types.Object, reference: SelectionReference) -> None:
    if not all_faces_are_quads(obj):
        raise ValueError("The selection must contain only quads.")
    if reference.active_face_index < 0:
        raise ValueError("Select an active face before creating the label.")

    selection_lock = obj.hide_select
    obj.hide_select = False
    try:
        _prepare_edit_uv(context, obj, reference.active_face_index)
        _seed_active_quad_uv(obj, reference)
        try:
            bpy.ops.uv.follow_active_quads(mode='LENGTH_AVERAGE')
        except Exception:
            bpy.ops.uv.follow_active_quads(mode='LENGTH')
        bpy.ops.object.mode_set(mode='OBJECT')
        _uniform_metric_scale(obj)
    finally:
        if obj.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        obj.hide_select = selection_lock


def generic_unwrap_uv(context: bpy.types.Context, obj: bpy.types.Object, reference: SelectionReference, method: str) -> None:
    selection_lock = obj.hide_select
    obj.hide_select = False
    try:
        _prepare_edit_uv(context, obj, reference.active_face_index)
        unwrap_method = 'ANGLE_BASED' if method == 'AUTO' else method
        try:
            bpy.ops.uv.unwrap(method=unwrap_method, margin=0.001)
        except Exception:
            bpy.ops.uv.smart_project(angle_limit=math.radians(66.0), island_margin=0.001)
        bpy.ops.object.mode_set(mode='OBJECT')
        _uniform_metric_scale(obj)
    finally:
        if obj.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        obj.hide_select = selection_lock


def build_metric_uv(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    method: str,
    orientation_mode: str,
    reference: SelectionReference,
) -> str:
    used_method = method

    if method == 'PLANAR' or (method == 'AUTO' and surface_is_nearly_planar(obj)):
        planar_metric_uv(obj, reference, orientation_mode)
        used_method = 'PLANAR'
    elif method == 'QUAD' or (method == 'AUTO' and all_faces_are_quads(obj) and reference.active_face_index >= 0):
        try:
            follow_active_quads_uv(context, obj, reference)
            orient_uvs(obj, reference, orientation_mode)
            center_uvs(obj.data, reference.active_face_index)
            used_method = 'QUAD'
        except Exception:
            if method == 'QUAD':
                raise
            generic_unwrap_uv(context, obj, reference, 'ANGLE_BASED')
            orient_uvs(obj, reference, orientation_mode)
            center_uvs(obj.data, reference.active_face_index)
            used_method = 'ANGLE_BASED'
    else:
        generic_unwrap_uv(context, obj, reference, method)
        orient_uvs(obj, reference, orientation_mode)
        center_uvs(obj.data, reference.active_face_index)
        used_method = method

    obj.data.update()
    return used_method


def uv_bounds(mesh: bpy.types.Mesh) -> tuple[float, float, float, float]:
    uv_layer = mesh.uv_layers.active
    if uv_layer is None or not uv_layer.data:
        return (0.0, 0.0, 0.0, 0.0)
    xs = [item.uv.x for item in uv_layer.data]
    ys = [item.uv.y for item in uv_layer.data]
    return min(xs), max(xs), min(ys), max(ys)


def analyze_uv(obj: bpy.types.Object) -> UVAnalysis:
    mesh = obj.data
    uv_layer = mesh.uv_layers.active
    if uv_layer is None:
        return UVAnalysis()

    errors = []
    errors_u = []
    errors_v = []
    for loop_a, loop_b, vert_a, vert_b in _iter_polygon_uv_edges(mesh):
        duv = uv_layer.data[loop_b].uv - uv_layer.data[loop_a].uv
        uv_length = duv.length
        world_a = obj.matrix_world @ mesh.vertices[vert_a].co
        world_b = obj.matrix_world @ mesh.vertices[vert_b].co
        world_length = (world_b - world_a).length
        if world_length <= 1e-10:
            continue
        error = abs(uv_length - world_length) / world_length
        errors.append(error)
        if abs(duv.x) >= abs(duv.y):
            errors_u.append(error)
        else:
            errors_v.append(error)

    def rms(values):
        return math.sqrt(sum(value * value for value in values) / len(values)) * 100.0 if values else 0.0

    min_u, max_u, min_v, max_v = uv_bounds(mesh)
    return UVAnalysis(
        rms=rms(errors),
        u=rms(errors_u),
        v=rms(errors_v),
        width=max_u - min_u,
        height=max_v - min_v,
    )


def store_uv_analysis(label: bpy.types.Object) -> UVAnalysis:
    analysis = analyze_uv(label)
    data = label.jb3d_labeler
    data.distortion_rms = analysis.rms
    data.distortion_u = analysis.u
    data.distortion_v = analysis.v
    data.available_width = analysis.width
    data.available_height = analysis.height
    label["jb3d_distortion_percent"] = analysis.rms
    return analysis


def _barycentric_2d(point: Vector, a: Vector, b: Vector, c: Vector) -> Optional[tuple[float, float, float]]:
    v0 = b - a
    v1 = c - a
    v2 = point - a
    denominator = v0.x * v1.y - v1.x * v0.y
    if abs(denominator) < 1e-14:
        return None
    w1 = (v2.x * v1.y - v1.x * v2.y) / denominator
    w2 = (v0.x * v2.y - v2.x * v0.y) / denominator
    return 1.0 - w1 - w2, w1, w2


def surface_frame_from_uv(obj: bpy.types.Object, offset: float = 0.0, target_uv: Vector = Vector((0.0, 0.0))) -> Matrix:
    mesh = obj.data
    uv_layer = mesh.uv_layers.active
    if uv_layer is None or not mesh.polygons:
        return obj.matrix_world.copy()

    mesh.calc_loop_triangles()
    best = None
    target3 = Vector((target_uv.x, target_uv.y, 0.0))

    for triangle in mesh.loop_triangles:
        loops = list(getattr(triangle, "loops", ()))
        if not loops:
            loops = list(getattr(triangle, "loop_indices", ()))
        if len(loops) != 3:
            continue
        uvs = [uv_layer.data[index].uv.copy() for index in loops]
        weights = _barycentric_2d(target_uv, uvs[0], uvs[1], uvs[2])
        inside = weights is not None and min(weights) >= -1e-7
        if inside:
            distance = 0.0
        else:
            a3, b3, c3 = (Vector((uv.x, uv.y, 0.0)) for uv in uvs)
            closest = geometry.closest_point_on_tri(target3, a3, b3, c3)
            weights = _barycentric_2d(Vector((closest.x, closest.y)), uvs[0], uvs[1], uvs[2])
            if weights is None:
                continue
            distance = (closest - target3).length_squared
        if best is None or distance < best[0]:
            best = (distance, loops, uvs, weights)
            if inside:
                break

    if best is None:
        return obj.matrix_world.copy()

    _, loops, uvs, weights = best
    vertices = [mesh.loops[index].vertex_index for index in loops]
    points = [obj.matrix_world @ mesh.vertices[index].co for index in vertices]
    normal_matrix = obj.matrix_world.to_3x3().inverted_safe().transposed()
    normals = [normal_matrix @ mesh.vertices[index].normal for index in vertices]

    position = sum((points[index] * weights[index] for index in range(3)), Vector())
    interpolated_normal = sum((normals[index] * weights[index] for index in range(3)), Vector())

    edge1 = points[1] - points[0]
    edge2 = points[2] - points[0]
    duv1 = uvs[1] - uvs[0]
    duv2 = uvs[2] - uvs[0]
    determinant = duv1.x * duv2.y - duv1.y * duv2.x

    if abs(determinant) > 1e-14:
        inverse = 1.0 / determinant
        raw_u = (edge1 * duv2.y - edge2 * duv1.y) * inverse
        raw_v = (edge2 * duv1.x - edge1 * duv2.x) * inverse
    else:
        raw_u = edge1
        raw_v = edge2

    normal = interpolated_normal
    if normal.length_squared < 1e-16:
        normal = raw_u.cross(raw_v)
    if normal.length_squared < 1e-16:
        normal = average_world_normal(obj)
    normal.normalize()

    average_normal = average_world_normal(obj)
    if normal.dot(average_normal) < 0.0:
        normal.negate()

    tangent_u = raw_u - normal * raw_u.dot(normal)
    if tangent_u.length_squared < 1e-16:
        tangent_u = raw_v.cross(normal)
    if tangent_u.length_squared < 1e-16:
        tangent_u = Vector((1.0, 0.0, 0.0))
    tangent_u.normalize()

    tangent_v = normal.cross(tangent_u)
    if tangent_v.length_squared < 1e-16:
        tangent_v = Vector((0.0, 1.0, 0.0))
    tangent_v.normalize()
    if raw_v.length_squared > 1e-16 and tangent_v.dot(raw_v) < 0.0:
        tangent_u.negate()
        tangent_v.negate()

    position += normal * offset
    return Matrix((
        (tangent_u.x, tangent_v.x, normal.x, position.x),
        (tangent_u.y, tangent_v.y, normal.y, position.y),
        (tangent_u.z, tangent_v.z, normal.z, position.z),
        (0.0, 0.0, 0.0, 1.0),
    ))


def add_transform_driver(socket, controller: bpy.types.Object, transform_type: str, expression: str = "v") -> None:
    try:
        socket.driver_remove("default_value")
    except Exception:
        pass
    fcurve = socket.driver_add("default_value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    variable = driver.variables.new()
    variable.name = "v"
    variable.type = 'TRANSFORMS'
    target = variable.targets[0]
    target.id = controller
    target.transform_type = transform_type
    target.transform_space = 'LOCAL_SPACE'
    driver.expression = expression


def _set_parent_keep_world(
    child: bpy.types.Object,
    parent: bpy.types.Object,
) -> None:
    """Parent an object while preserving its current world-space transform."""
    if child is None or parent is None or child == parent:
        return
    world_matrix = child.matrix_world.copy()
    child.parent = parent
    child.parent_type = 'OBJECT'
    child.matrix_parent_inverse = Matrix.Identity(4)
    child.matrix_basis = parent.matrix_world.inverted_safe() @ world_matrix


def parent_label_to_source(
    label: bpy.types.Object,
    source: Optional[bpy.types.Object],
) -> None:
    """Make the duplicated label mesh inherit the exact transform of its product.

    Label vertices are copied in the source object's local coordinates. An identity
    local transform is therefore the cleanest and most stable relationship: moving,
    rotating, scaling or parenting the product moves the label identically.
    """
    if source is None or label is None or source == label:
        return
    label.parent = source
    label.parent_type = 'OBJECT'
    label.matrix_parent_inverse = Matrix.Identity(4)
    label.matrix_basis = Matrix.Identity(4)
    label.lock_location = (True, True, True)
    label.lock_rotation = (True, True, True)
    label.lock_scale = (True, True, True)
    label["jb3d_parenting_version"] = 1


def ensure_rig_parenting(rig: LabelRig) -> None:
    """Repair and enforce the product > label > anchor > controller hierarchy."""
    if rig is None or rig.label is None:
        return

    if rig.source is not None:
        parent_label_to_source(rig.label, rig.source)

    if rig.anchor is not None and rig.anchor.parent != rig.label:
        _set_parent_keep_world(rig.anchor, rig.label)

    if rig.controller is not None and rig.anchor is not None and rig.controller.parent != rig.anchor:
        _set_parent_keep_world(rig.controller, rig.anchor)


def initialize_rig_data(
    label: bpy.types.Object,
    controller: bpy.types.Object,
    anchor: bpy.types.Object,
    source: bpy.types.Object,
    image: bpy.types.Image,
    image_path: str,
    width: float,
    height: float,
    preserve_ratio: bool,
    surface_offset: float,
    follow_surface: bool,
    unwrap_method: str,
    orientation_mode: str,
    roughness: float,
    metallic: float,
    pack_image: bool,
    reference: SelectionReference,
    label_type: str = 'STANDARD',
    wrap_seam_mode: str = 'AUTO_BACK',
    wrap_axis: str = 'AUTO',
) -> None:
    rig_uuid = str(uuid.uuid4())
    data = label.jb3d_labeler
    data.role = ROLE_LABEL
    data.rig_uuid = rig_uuid
    data.data_version = CURRENT_DATA_VERSION
    data.source_object = source
    data.controller_object = controller
    data.anchor_object = anchor
    data.label_type = label_type
    data.wrap_seam_mode = wrap_seam_mode
    data.wrap_axis = wrap_axis
    data.applied_wrap_seam_mode = wrap_seam_mode
    data.applied_wrap_axis = wrap_axis
    data.ratio_update_lock = True
    try:
        data.image = image
        data.image_path = image_path
        data.image_pixel_width = int(image.size[0]) if len(image.size) >= 1 else 0
        data.image_pixel_height = int(image.size[1]) if len(image.size) >= 2 else 0
        data.width = width
        data.height = height
        data.preserve_ratio = preserve_ratio
        data.last_edited_dimension = 'WIDTH'
    finally:
        data.ratio_update_lock = False
    data.surface_offset = surface_offset
    data.follow_surface = follow_surface
    data.unwrap_method = unwrap_method
    data.orientation_mode = orientation_mode
    data.applied_unwrap_method = unwrap_method
    data.applied_orientation_mode = orientation_mode
    data.roughness = roughness
    data.metallic = metallic
    data.pack_image = pack_image
    data.active_face_index = reference.active_face_index
    if reference.active_edge_vertices:
        data.active_edge_v0, data.active_edge_v1 = reference.active_edge_vertices
    else:
        data.active_edge_v0 = data.active_edge_v1 = -1

    for obj, role in ((controller, ROLE_CONTROLLER), (anchor, ROLE_ANCHOR)):
        part = obj.jb3d_labeler
        part.role = role
        part.rig_uuid = rig_uuid
        part.data_version = CURRENT_DATA_VERSION
        part.owner_label = label
        obj[ROLE_KEY] = role
        obj["jb3d_label_name"] = label.name

    label[ROLE_KEY] = ROLE_LABEL
    label.hide_select = True
    label.hide_viewport = False
    label.hide_render = False
    anchor.hide_select = False
    controller.hide_select = False
    label["jb3d_source_name"] = source.name
    label["jb3d_controller_name"] = controller.name
    label["jb3d_anchor_name"] = anchor.name
    label["jb3d_image_name"] = image.name
    label["jb3d_original_width"] = width
    label["jb3d_original_height"] = height


def create_controller_rig(
    collection: bpy.types.Collection,
    label: bpy.types.Object,
    source: bpy.types.Object,
    image: bpy.types.Image,
    image_path: str,
    width: float,
    height: float,
    preserve_ratio: bool,
    surface_offset: float,
    follow_surface: bool,
    unwrap_method: str,
    orientation_mode: str,
    roughness: float,
    metallic: float,
    pack_image: bool,
    reference: SelectionReference,
    frame_offset: float,
    label_type: str = 'STANDARD',
    wrap_seam_mode: str = 'AUTO_BACK',
    wrap_axis: str = 'AUTO',
    anchor_target_uv: Optional[Vector] = None,
) -> tuple[bpy.types.Object, bpy.types.Object]:
    # The label mesh uses the source object's local coordinates, so an identity
    # child transform gives a stable, exact hierarchy for all later movements.
    parent_label_to_source(label, source)

    anchor = bpy.data.objects.new(f"{label.name}_Anchor", None)
    anchor.empty_display_type = 'PLAIN_AXES'
    anchor.empty_display_size = max(min(width, height) * 0.12, 0.002)
    anchor.show_in_front = True
    anchor.hide_render = True
    collection.objects.link(anchor)
    anchor.matrix_world = surface_frame_from_uv(
        label, frame_offset, anchor_target_uv or Vector((0.0, 0.0))
    )
    _set_parent_keep_world(anchor, label)

    controller = bpy.data.objects.new(f"{label.name}_Controller", None)
    controller.empty_display_type = 'CUBE'
    controller.empty_display_size = 1.0
    controller.show_in_front = True
    controller.hide_render = True
    collection.objects.link(controller)
    controller.parent = anchor
    controller.matrix_parent_inverse = Matrix.Identity(4)
    controller.location = (0.0, 0.0, 0.0)
    controller.rotation_mode = 'XYZ'
    controller.rotation_euler = (0.0, 0.0, 0.0)
    controller.scale = (
        max(width * 0.5, 1e-6),
        max(height * 0.5, 1e-6),
        max(min(width, height) * 0.01, 1e-6),
    )
    controller.lock_location[2] = True
    controller.lock_rotation[0] = True
    controller.lock_rotation[1] = True
    controller.lock_scale[2] = True

    initialize_rig_data(
        label=label,
        controller=controller,
        anchor=anchor,
        source=source,
        image=image,
        image_path=image_path,
        width=width,
        height=height,
        preserve_ratio=preserve_ratio,
        surface_offset=surface_offset,
        follow_surface=follow_surface,
        unwrap_method=unwrap_method,
        orientation_mode=orientation_mode,
        roughness=roughness,
        metallic=metallic,
        pack_image=pack_image,
        reference=reference,
        label_type=label_type,
        wrap_seam_mode=wrap_seam_mode,
        wrap_axis=wrap_axis,
    )
    ensure_rig_parenting(LabelRig(label=label, controller=controller, anchor=anchor, source=source))
    return anchor, controller



def source_subdivision_modifier(source: Optional[bpy.types.Object]) -> Optional[bpy.types.Modifier]:
    if source is None or source.type != 'MESH':
        return None
    return next((modifier for modifier in source.modifiers if modifier.type == 'SUBSURF'), None)


def remove_source_subdivision(label: bpy.types.Object) -> None:
    modifier = label.modifiers.get(SOURCE_SUBSURF_NAME)
    if modifier is not None:
        label.modifiers.remove(modifier)


def _copy_modifier_settings(source_modifier: bpy.types.Modifier, target_modifier: bpy.types.Modifier) -> None:
    """Copy writable RNA properties without depending on one Blender version."""
    ignored = {'rna_type', 'name', 'type'}
    for prop in source_modifier.bl_rna.properties:
        identifier = prop.identifier
        if identifier in ignored or prop.is_readonly or prop.type == 'COLLECTION':
            continue
        try:
            value = getattr(source_modifier, identifier)
            if getattr(prop, "is_array", False):
                value = tuple(value)
            setattr(target_modifier, identifier, value)
        except (AttributeError, TypeError, ValueError, RuntimeError):
            # Some inherited or version-specific properties cannot be assigned.
            continue


def sync_source_subdivision(
    label: bpy.types.Object,
    source: Optional[bpy.types.Object],
) -> Optional[bpy.types.Modifier]:
    source_modifier = source_subdivision_modifier(source)
    if source_modifier is None:
        remove_source_subdivision(label)
        return None

    target_modifier = label.modifiers.get(SOURCE_SUBSURF_NAME)
    if target_modifier is None or target_modifier.type != 'SUBSURF':
        if target_modifier is not None:
            label.modifiers.remove(target_modifier)
        target_modifier = label.modifiers.new(SOURCE_SUBSURF_NAME, type='SUBSURF')

    _copy_modifier_settings(source_modifier, target_modifier)
    target_modifier.name = SOURCE_SUBSURF_NAME
    try:
        target_modifier.show_expanded = False
    except Exception:
        pass
    return target_modifier

def add_shrinkwrap(label: bpy.types.Object, source: bpy.types.Object, offset: float) -> bpy.types.Modifier:
    modifier = label.modifiers.get(SHRINKWRAP_NAME)
    if modifier is None:
        modifier = label.modifiers.new(SHRINKWRAP_NAME, type='SHRINKWRAP')
    modifier.target = source
    modifier.wrap_method = 'NEAREST_SURFACEPOINT'
    modifier.offset = offset
    if hasattr(modifier, "wrap_mode"):
        try:
            modifier.wrap_mode = 'ABOVE_SURFACE'
        except Exception:
            pass
    if hasattr(modifier, "use_smooth_shade"):
        try:
            modifier.use_smooth_shade = True
        except Exception:
            pass
    return modifier


def remove_shrinkwrap(label: bpy.types.Object) -> None:
    modifier = label.modifiers.get(SHRINKWRAP_NAME)
    if modifier is not None:
        label.modifiers.remove(modifier)


def apply_shrinkwrap_once(
    context: bpy.types.Context,
    label: bpy.types.Object,
    source: bpy.types.Object,
    offset: float,
) -> None:
    remove_shrinkwrap(label)
    modifier = add_shrinkwrap(label, source, offset)
    selection_lock = label.hide_select
    viewport_hidden = label.hide_viewport
    label.hide_select = False
    label.hide_viewport = False
    try:
        select_only(context, label)
        bpy.ops.object.modifier_apply(modifier=modifier.name)
    finally:
        label.hide_select = selection_lock
        label.hide_viewport = viewport_hidden


def configure_surface_follow(
    context: bpy.types.Context,
    label: bpy.types.Object,
    source: Optional[bpy.types.Object],
    follow_surface: bool,
    offset: float,
) -> float:
    # Rebuild the plugin-owned part of the modifier stack deterministically.
    # The copied Subdivision Surface is always inserted before Shrinkwrap.
    remove_shrinkwrap(label)
    remove_source_subdivision(label)
    if source is None or source.type != 'MESH':
        return 0.0

    if follow_surface:
        sync_source_subdivision(label, source)
        add_shrinkwrap(label, source, offset)
        return offset

    # Frozen mode: return the base vertices to the target before baking the
    # requested offset. This avoids accumulating the offset on repeated updates.
    apply_shrinkwrap_once(context, label, source, 0.0)
    if offset > 1e-12:
        apply_shrinkwrap_once(context, label, source, offset)
    sync_source_subdivision(label, source)
    return 0.0

def update_anchor_frame(rig: LabelRig, frame_offset: float) -> None:
    if rig.anchor is None:
        return
    data = rig.label.jb3d_labeler
    target_uv = Vector((data.wrap_anchor_u, data.wrap_anchor_v)) if data.label_type == 'WRAP_360' else Vector((0.0, 0.0))
    rig.anchor.matrix_world = surface_frame_from_uv(rig.label, frame_offset, target_uv)


def reference_from_label(label: bpy.types.Object, view_right_world: Optional[Vector] = None) -> SelectionReference:
    data = label.jb3d_labeler
    edge = None
    if data.active_edge_v0 >= 0 and data.active_edge_v1 >= 0:
        edge = (data.active_edge_v0, data.active_edge_v1)
    return SelectionReference(
        active_face_index=data.active_face_index,
        active_edge_vertices=edge,
        view_right_world=view_right_world,
    )


def label_fit_report(rig: LabelRig) -> FitReport:
    if rig.label.jb3d_labeler.label_type == 'WRAP_360':
        data = rig.label.jb3d_labeler
        return FitReport(True, 0.0, data.wrap_circumference, data.wrap_height)
    min_u, max_u, min_v, max_v = uv_bounds(rig.label.data)
    support_width = max_u - min_u
    support_height = max_v - min_v
    controller = rig.controller
    if controller is None:
        return FitReport(False, float('inf'), support_width, support_height)

    center = Vector((controller.location.x, controller.location.y))
    half_w = abs(controller.scale.x)
    half_h = abs(controller.scale.y)
    angle = controller.rotation_euler.z
    cos_r = math.cos(angle)
    sin_r = math.sin(angle)

    overflow = 0.0
    for x, y in ((-half_w, -half_h), (half_w, -half_h), (half_w, half_h), (-half_w, half_h)):
        point = center + Vector((cos_r * x - sin_r * y, sin_r * x + cos_r * y))
        overflow = max(
            overflow,
            min_u - point.x,
            point.x - max_u,
            min_v - point.y,
            point.y - max_v,
        )
    overflow = max(overflow, 0.0)
    return FitReport(overflow <= 1e-8, overflow, support_width, support_height)


def format_distance(scene: bpy.types.Scene, value: float) -> str:
    scale = scene.unit_settings.scale_length if scene.unit_settings.scale_length > 0 else 1.0
    meters = value * scale
    if meters < 0.01:
        return f"{meters * 1000.0:.2f} mm"
    if meters < 1.0:
        return f"{meters * 100.0:.2f} cm"
    return f"{meters:.3f} m"


def remove_object_and_data(obj: Optional[bpy.types.Object]) -> None:
    if obj is None or obj.name not in bpy.data.objects:
        return
    data = obj.data if hasattr(obj, "data") else None
    bpy.data.objects.remove(obj, do_unlink=True)
    if data is not None and getattr(data, "users", 1) == 0:
        collection = None
        if isinstance(data, bpy.types.Mesh):
            collection = bpy.data.meshes
        if collection is not None:
            collection.remove(data)
