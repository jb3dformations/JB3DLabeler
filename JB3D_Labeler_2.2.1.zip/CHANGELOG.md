# JB3D Labeler Changelog

## 2.2.1

- Fixed extension installation under Blender's restricted registration context (`_RestrictData`).
- Registration no longer reads scenes, objects, or other `bpy.data` collections.
- Runtime product/material discovery is now deferred until normal Blender handlers run.
- Reordered startup so classes, properties, operators, and UI are registered before runtime handlers.
- Made handler/timer cleanup symmetrical and safe during extension disable/reload.
- Existing labeled products are rediscovered lazily and their material stacks are refreshed without losing label data.

## 2.2.0

- Added transparent material re-integration: labels survive assigning, replacing or rebuilding the product material after labels have already been created.
- Added lightweight structural material monitoring for labeled products only; regular shader value edits and viewport transforms do not trigger stack rebuilds.
- Reconnects the JB3D stack when supported Principled BSDF nodes or Base Color / Roughness / Metallic links are structurally changed.
- Restores and removes obsolete JB3D integration nodes when a product shader is rebuilt, avoiding stale material wiring.
- Improved the sidebar spacing and separated tightly packed controls for better readability in narrow N-panels.
- Added the public GitHub issue tracker to the extension manifest: https://github.com/jb3dformations/JB3DLabeler/issues
- Removed the `User Interface` and `Mesh` extension tags as requested during extensions.blender.org review; retained only `Material` and `UV`.
- Simplified class and RNA-property registration/unregistration to the standard Blender add-on pattern used in the official templates.
- Minimum supported Blender version remains 4.5.0 LTS.


## 2.1.1

- Fixed a critical sidebar regression where Blender could reject RNA writes performed from `Panel.draw()`, leaving the JB3D Labeler panel completely empty.
- Made all panel rendering strictly read-only.
- Product label lists are now synchronized by operators, load handlers, and a lightweight deferred scene watcher instead of during UI drawing.
- Added automatic stale-label cleanup after manual object deletion without rebuilding on normal controller transforms.
- Added a defensive UI fallback so future drawing errors are shown in the panel instead of producing an unexplained blank sidebar.

## 2.1.0

- Moved the Labels UI list from scene-global storage to product-owned storage.
- The sidebar now shows only labels belonging to the selected product; selecting a label Controller or internal rig part resolves back to its product automatically.
- Each product now keeps its own active label and independent top-to-bottom stack order.
- Hardened label deletion against manually deleted Viewport/Outliner objects and invalid Blender pointers.
- Added UUID-backed list entries so stale rows can be removed without dereferencing a deleted label object.
- Added debounced product cleanup: stale label deletion schedules one lightweight material-stack repair instead of rebuilding inside the UI draw loop.
- Replaced Threshold / Contrast / Feather / Invert mask processing with Blender's native ColorRamp node.
- Exposed the real ColorRamp editor in the sidebar, including editable stops, positions, stop colors, color mode, interpolation, and hue interpolation where applicable.
- Added Mask Ramp Invert and Reset actions.
- Added Final / Mask preview controls for faster mask tuning.
- ColorRamp edits now operate directly on the shader node and update the viewport without a custom property synchronization layer.
- Preserved ColorRamp state across structural material-stack rebuilds, mask enable/disable cycles, label reordering, and mask preview changes.
- Added automatic migration of V2.0 Threshold/Contrast/Feather/Invert masks to equivalent two-stop ColorRamps.
- Reorganized mask controls under Material Effects and clarified the relationship between Color Treatment and masked Color/Roughness/Metallic effects.
- Bumped internal rig data schema to version 11 while retaining V1.x/V2.0 migration support.
- Minimum supported Blender version remains 4.5.0 LTS.

## 2.0.0

- Replaced separate rendered label surfaces with a product-level Material Decal engine.
- Blend modes now start from the original product Base Color and continue through the JB3D label stack from bottom to top.
- Integrated labels non-destructively before supported Principled BSDF Base Color, Roughness and Metallic inputs.
- Preserved the original Normal, Coat, Transmission, Emission, Volume and Material Output Displacement branches.
- Eliminated label/displacement intersections and Z-fighting by rendering labels on the product surface itself.
- Added per-label internal product coordinate and support-mask attributes without creating or modifying user UV maps.
- Added automatic single-user mesh handling when internal product attributes require isolation.
- Added safe local material copies when a labeled product uses a material shared with other objects.
- Added automatic restoration of original Principled input links when the last label is removed.
- Added explicit 0–1 artwork bounds masking for predictable partial labels and JPEG artwork.
- Added Artwork / Tint / Replace color modes.
- Added an Effect Color control for tinting or replacing selected artwork areas.
- Added a reusable material-effect mask system sourced from the artwork or a separate image.
- Added Luminance, Red, Green, Blue and Alpha mask-channel extraction.
- Added Threshold, Contrast, Feather and Invert mask controls.
- Added black-and-white mask preview directly on the product.
- Added Base Roughness / Metallic and independent Masked Roughness / Metallic controls.
- Added mask routing for Color, Roughness and Metallic to support foil, selective varnish and localized material effects.
- Rebuilt the UI around collapsible Add Label, Labels, Placement, Appearance, Mask & Material Effects, Advanced and Utilities sections.
- Simplified the Labels list to layer name/type and visibility; detailed material controls now live only in the selected label settings.
- Added optional Controller visibility and hidden internal mapping surfaces by default.
- The Labels list is now the authoritative edited layer, avoiding accidental actions on a previously selected rig object.
- Removed render-time Shrinkwrap/Subdivision duplication from label mapping surfaces in the V2 path.
- Existing V1.x Standard and 360° Wrap rigs migrate to the V2 Material Decal engine while preserving placement and appearance values.
- Minimum supported Blender version remains 4.5.0 LTS.

## 1.3.0

- Added true color compositing between overlapping labels on the same product.
- Blend modes now use the visible label stack underneath instead of always using a white local base.
- Added per-label Opacity control.
- Added support for compositing Standard labels with Standard labels, 360° Wrap labels with Wrap labels, and Standard/Wrap combinations when their support faces overlap.
- Added internal source-face and source-vertex provenance attributes to newly generated label meshes.
- Added automatic provenance reconstruction for older V1.x label meshes.
- Added internal transferred coordinate and overlap-mask attributes so compositing does not modify the product mesh or its UV maps.
- Added live lower-layer sampling driven by each label controller, so position, rotation and scale changes remain interactive.
- Added compositing status information in the active-label interface.
- Added a manual Rebuild Layer Compositing maintenance action for recovery and diagnostics.
- Reordering and blend-mode changes rebuild the relevant source stack automatically; opacity and visibility are evaluated live through drivers.
- Preserved V1.2 physical sizing and aspect-ratio controls for 360° Wrap artwork.
- Minimum supported Blender version remains 4.5.0 LTS.

## 1.2.0

- Added physical Width and Height controls to 360° Wrap artwork.
- Added live wrap artwork scaling through the existing controller.
- Added horizontal and vertical repositioning combined with independent artwork sizing.
- Added Preserve Image Ratio support to 360° Wrap labels to prevent aspect-ratio stretching.
- Added Full 360° Width and Fit Band Height actions for fast wrap fitting.
- Added support for curved partial labels when artwork width is smaller than the product circumference.
- Limited wrap artwork width to one circumference to avoid overlap/discontinuities at the seam.
- Added warnings when artwork is taller than the selected wrap band and will be clipped.
- Added controller-scale detection so viewport scaling can be stored with Update Label.
- Updated the shared wrap shader coordinate system to use physical circumference, band height and artwork dimensions.
- Added automatic migration of V1.1 360° Wrap rigs to the new V1.2 controller behavior while preserving their previous appearance.
- Standard Label behavior remains compatible.

## 1.1.1

- Converted the package cleanly to the Blender Extension format by removing legacy `bl_info` metadata.
- Added explicit GPL-3.0-or-later licensing information and SPDX headers.
- Prevented JB3D Labeler from deleting unrelated user node groups when an internal node-group name collides.
- Added persistent ownership markers for managed shader node groups.
- Removed a redundant module-level registry state assignment.
- Verified the code path against Blender 4.5-era APIs and lowered the minimum supported version to Blender 4.5.0 LTS; Blender 5.x remains supported.
- No changes to the saved label data schema; existing 1.0.0 and 1.1.0 labels remain compatible.

## 1.1.0

- Added a **360° Wrap** label type for bottles, cans, jars, tubes, and similar packaging.
- Added automatic detection of continuous closed quad bands.
- Added automatic back-seam placement based on the active face.
- Added optional seam placement from the active vertical edge.
- Added automatic or local-axis band detection.
- Added circumference, height, top/bottom length, and taper measurements.
- Added warnings for image-ratio mismatch and tapered surfaces.
- Added horizontal and vertical artwork offsets through the existing controller.
- Added the shared **JB3D Wrap Coordinates v1** shader node group.
- Preserved subdivision-before-shrinkwrap, white label backs, parenting, stacking, visibility, locking, and blend modes.
- Existing 1.0.0 labels are migrated as Standard labels.

## 1.0.0

- Initial public release.
