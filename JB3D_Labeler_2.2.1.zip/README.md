# JB3D Labeler

JB3D Labeler is a non-destructive packaging-label system for Blender. Version 2 renders labels directly inside the product material while keeping the existing product shader as the base layer.

The visible label is no longer a separate rendered surface. JB3D keeps lightweight internal mapping objects and viewport controllers for editing, then transfers only the required label coordinates and masks to internal mesh attributes on the product. Existing user UV maps are not modified.

From V2.1 onward, label management is product-local rather than scene-global. The sidebar only lists labels for the active product, which keeps multi-product packaging scenes predictable and uncluttered.

## Why the V2 Material Decal Engine

The product material remains in control of the final surface. JB3D inserts one product-specific label stack immediately before the Base Color, Roughness and Metallic inputs of supported Principled BSDF nodes.

This means:

- blend modes use the actual product Base Color underneath the labels;
- labels blend correctly with other JB3D labels in the layer list;
- existing Roughness and Metallic inputs remain the starting values outside labels;
- the original Normal, Coat, Transmission, Emission, Volume and other shader branches are left untouched;
- the original Material Output Displacement connection is untouched;
- shader displacement automatically affects the labels because product and labels are shaded on the same surface;
- there is no rendered label geometry to intersect with displaced surfaces or create Z-fighting.

If a material is shared with another object, JB3D makes a local material copy for the labeled product before integrating the stack. If a mesh datablock is shared, JB3D makes the product mesh single-user before adding its internal attributes.

Labels are independent from the material currently assigned to the product. You can create labels first, then assign, replace or rebuild the product material later. JB3D detects structural material changes and automatically reconnects the label stack around the current supported Principled BSDF inputs while keeping all label artwork, placement, layer order and mask settings intact. Regular color/value edits upstream of the JB3D stack do not trigger unnecessary rebuilds.

## Standard Labels

1. Select the product and enter Edit Mode.
2. Select one connected region of faces.
3. Choose **Standard** and select the artwork image.
4. Enter the physical Width/Height and optionally keep the image ratio.
5. Create the label.
6. Use **Edit in Viewport** or the Placement controls to move, rotate and resize the artwork.

Metric label coordinates remain attached to the selected support faces. Pixels outside the artwork rectangle are explicitly masked, so partial labels stay clipped even with images that do not contain alpha.

## 360° Wrap Labels

1. Choose **360° Wrap**.
2. Select one continuous quad band around the product.
3. Make the desired front face active.
4. Create the wrap.
5. Move the Controller horizontally to slide the artwork around the circumference and vertically to reposition it along the band.
6. Resize Width/Height with **Keep Image Ratio**, **Full 360°**, or **Fit Height**.

A wrap can cover the complete circumference or behave as a curved partial label. The support band and the physical artwork size are independent, so the artwork does not have to be stretched to the full band.

## Layer Compositing

The Labels list is the material-layer stack for the currently selected product. The first row is the top layer. Selecting another product immediately switches the list to that product's labels; selecting a JB3D Controller resolves back to its owning product.

Each label has:

- Blend Mode;
- Opacity;
- independent placement and physical dimensions;
- base Roughness and Metallic values;
- optional color treatment and material-effect masking.

Composition starts with the original product Base Color, Roughness and Metallic values and accumulates labels from bottom to top. Standard and 360° labels can be mixed in the same stack.

## Material Effects and Native ColorRamp Masks

A label can extract a black-and-white material mask directly from its artwork or use a separate image.

Mask sources:

- Artwork;
- External Image.

Available channels:

- Luminance;
- Red;
- Green;
- Blue;
- Alpha.

The selected channel is processed by a real Blender **ColorRamp**. The sidebar exposes the same ramp data used by the shader: stops can be added/removed/moved, stop colors can be edited, and Color Mode / Interpolation / Hue Interpolation are available where supported. **Invert** and **Reset** shortcuts are provided, plus **Final / Mask** preview buttons.

The resulting mask can independently affect:

- Color treatment (Tint or Replace);
- Roughness;
- Metallic.

Typical workflows include metallic foil, selective gloss/varnish, recoloring only a logo or text region, and localized roughness changes without preparing an extra texture. The ColorRamp state is preserved through label reordering, stack rebuilds, preview changes, and temporary mask disable/enable cycles.

V2.0 Threshold / Contrast / Feather / Invert masks are migrated automatically to an equivalent two-stop ColorRamp the first time the product stack is rebuilt in V2.1.

## Simplified UI

The V2 interface is organized around four user concepts:

- Labels;
- Placement;
- Appearance;
- Material Effects.

Creation, label management, selected-label settings and Utilities can be collapsed independently. Technical mapping surfaces are hidden by default. Controllers can also be hidden and revealed only when viewport editing is needed.

Utilities contain recovery/debug actions such as Rebuild Material Stack, Rebuild Mapping, Repair Rig Links and Show Internal Mapping Surface.

## Material Compatibility

V2 integrates into top-level Principled BSDF nodes that contribute to the active Material Output Surface. Base Color, Roughness and Metallic are intercepted non-destructively; all other shader inputs and Material Output Displacement remain untouched.

Materials whose final surface is entirely encapsulated inside a custom shader node group, or materials with no supported top-level Principled BSDF, are left unchanged and reported in the label status instead of being guessed or destructively rewritten.

## Migration

Existing V1.x Standard and 360° Wrap rigs are migrated in place. Their label meshes are retained as hidden internal mapping carriers, while rendering moves to the V2 product-material stack. Existing images, placement controllers, dimensions, wrap settings, blend modes, opacity, Roughness and Metallic values are preserved.

## Compatibility

Blender 4.5 LTS or newer, including Blender 5.x.

## Permissions

JB3D Labeler requests file access only for images explicitly selected by the user. It does not use network access, subprocesses, package installation or external Python dependencies.

## License

GPL-3.0-or-later. See `LICENSE`.
