# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from . import compositor, operators, properties, registry, ui


def register():
    properties.register()
    operators.register()
    ui.register()
    registry.register()


def unregister():
    registry.unregister()
    ui.unregister()
    operators.unregister()
    properties.unregister()
