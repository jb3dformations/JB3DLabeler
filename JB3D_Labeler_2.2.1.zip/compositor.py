# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

"""Product-level label stack orchestration for JB3D Labeler V2."""

from __future__ import annotations

import bpy

from . import material_engine
from .utils import ROLE_LABEL


def labels_for_source(
    source: bpy.types.Object | None,
    scene: bpy.types.Scene | None = None,
) -> list[bpy.types.Object]:
    """Return labels for one product in UI top-to-bottom order."""
    if source is None:
        return []
    labels = []
    objects = scene.objects if scene is not None else bpy.data.objects
    for obj in objects:
        if obj.type != 'MESH' or not hasattr(obj, "jb3d_labeler"):
            continue
        data = obj.jb3d_labeler
        if data.role == ROLE_LABEL and data.source_object == source:
            labels.append(obj)
    labels.sort(key=lambda item: (int(item.jb3d_labeler.stack_order), item.name.casefold()))
    return labels


def clear_stack_attributes(label: bpy.types.Object) -> None:
    """Compatibility shim for V1.3 callers.

    V2 attributes live on the product rather than on each label surface.
    """
    if label is None or not hasattr(label, "jb3d_labeler"):
        return
    material_engine.clear_label_attributes(label.jb3d_labeler.source_object, label)


def rebuild_source_stack(source: bpy.types.Object | None, scene: bpy.types.Scene | None = None) -> int:
    labels = labels_for_source(source, scene)
    report = material_engine.rebuild_product(source, labels)
    for label in labels:
        data = label.jb3d_labeler
        data.composite_layer_count = max(len(labels) - int(data.stack_order) - 1, 0)
        if report.warnings:
            data.composite_status = "; ".join(report.warnings[:2])
        else:
            data.composite_status = data.material_status

    # Keep the depsgraph material watcher in sync after deliberate JB3D
    # rebuilds, so the structural changes made by JB3D itself never cause a
    # redundant second rebuild.
    try:
        from . import registry
        registry.remember_material_state(source)
    except Exception:
        pass
    return report.labels


def refresh_source_stack(
    label_or_source: bpy.types.Object | None,
    scene: bpy.types.Scene | None = None,
) -> int:
    if label_or_source is None:
        return 0
    if hasattr(label_or_source, "jb3d_labeler") and label_or_source.jb3d_labeler.role == ROLE_LABEL:
        source = label_or_source.jb3d_labeler.source_object
    else:
        source = label_or_source
    if scene is None:
        users_scene = getattr(source, "users_scene", ()) if source is not None else ()
        scene = users_scene[0] if users_scene else None
    return rebuild_source_stack(source, scene)


def refresh_scene(scene: bpy.types.Scene | None) -> int:
    if scene is None:
        return 0
    sources: dict[int, bpy.types.Object] = {}
    for obj in scene.objects:
        if obj.type != 'MESH':
            continue
        # Include products that already carry a V2 UUID even when their last
        # label object was manually deleted. This lets load/refresh restore the
        # original material links and clean stale internal attributes.
        if obj.get(material_engine.SOURCE_UUID_KEY):
            sources[obj.as_pointer()] = obj
        if not hasattr(obj, "jb3d_labeler"):
            continue
        data = obj.jb3d_labeler
        if data.role == ROLE_LABEL and data.source_object is not None:
            sources[data.source_object.as_pointer()] = data.source_object
    return sum(rebuild_source_stack(source, scene) for source in sources.values())
