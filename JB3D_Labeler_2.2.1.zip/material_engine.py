# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

"""JB3D Labeler V2 material-decal rendering engine.

The V2 engine renders labels inside the product material instead of rendering
separate label surfaces. Label meshes remain lightweight mapping/controller
carriers only. Per-label coordinates and support masks are copied to internal
corner attributes on the product mesh, then a single product-specific shader
node group composites Base Color, Roughness and Metallic from bottom to top.

This design has three important properties:
- the original product shader remains the base layer for all blend modes;
- shader displacement automatically affects the labels because they are shaded
  on the exact same product surface;
- no user UV maps are created or modified.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field

import bpy

from . import materials
from .utils import (
    ROLE_LABEL,
    SOURCE_FACE_ATTRIBUTE,
    SOURCE_VERTEX_ATTRIBUTE,
    UV_NAME,
    ensure_source_mapping,
)


SOURCE_UUID_KEY = "jb3d_labeler_source_uuid"
STACK_GROUP_OWNER_KEY = "jb3d_labeler_stack_source_uuid"
STACK_GROUP_SCHEMA_KEY = "jb3d_labeler_stack_schema"
STACK_GROUP_SCHEMA = 2
INTEGRATION_NODE_KEY = "jb3d_labeler_integration_source_uuid"
INTEGRATION_PRINCIPLED_KEY = "jb3d_labeler_principled"
MATERIAL_SOURCE_KEY = "jb3d_labeler_material_source_uuid"
MATERIAL_ORIGINAL_KEY = "jb3d_labeler_original_material"

SOURCE_UV_PREFIX = "JB3D_LUV_"
SOURCE_MASK_PREFIX = "JB3D_LMASK_"
STACK_GROUP_PREFIX = "JB3D Label Stack "
INTEGRATION_NODE_PREFIX = "JB3D_LABEL_STACK_"
MASK_RAMP_NODE_KEY = "jb3d_labeler_mask_ramp_uuid"
MASK_RAMP_SCHEMA_KEY = "jb3d_labeler_mask_ramp_schema"
MASK_RAMP_SCHEMA = 1

def _safe_object_link(data, name: str):
    try:
        value = getattr(data, name, None)
        if value is None or not value.as_pointer():
            return None
        return value
    except (ReferenceError, RuntimeError, AttributeError):
        return None



@dataclass
class ProductBuildReport:
    labels: int = 0
    materials: int = 0
    principled_nodes: int = 0
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.labels > 0 and self.principled_nodes > 0


def _safe_token(text: str, limit: int = 32) -> str:
    token = "".join(ch for ch in text if ch.isalnum() or ch == "_")
    return (token or "JB3D")[:limit]


def source_uuid(source: bpy.types.Object) -> str:
    """Return the persistent UUID used to own one product material stack."""
    token = str(source.get(SOURCE_UUID_KEY, ""))
    if token:
        return token
    token = str(uuid.uuid4())
    source[SOURCE_UUID_KEY] = token
    return token


def label_token(label: bpy.types.Object) -> str:
    """Stable per-object token for internal attributes and nodes.

    The object name suffix intentionally disambiguates duplicated legacy rigs
    that may still carry the same rig UUID. Blender object names are unique in
    a file; renaming is harmless because every structural rebuild first removes
    the old JB3D attributes.
    """
    data = label.jb3d_labeler
    rig = (data.rig_uuid or "legacy").replace("-", "")[:20]
    return _safe_token(f"{rig}_{label.name}", 48)


def attribute_names(label: bpy.types.Object) -> tuple[str, str]:
    token = label_token(label)
    return f"{SOURCE_UV_PREFIX}{token}", f"{SOURCE_MASK_PREFIX}{token}"


def mask_ramp_node_name(label: bpy.types.Object) -> str:
    """Stable node name independent of user-facing object renames."""
    rig = str(label.jb3d_labeler.rig_uuid or "legacy").replace("-", "")[:28]
    return f"JB3D_MASK_RAMP_{_safe_token(rig, 28)}"


def _ramp_snapshot(node) -> dict | None:
    if node is None or node.bl_idname != 'ShaderNodeValToRGB':
        return None
    ramp = node.color_ramp
    return {
        "color_mode": str(getattr(ramp, "color_mode", 'RGB')),
        "interpolation": str(getattr(ramp, "interpolation", 'LINEAR')),
        "hue_interpolation": str(getattr(ramp, "hue_interpolation", 'NEAR')),
        "elements": [
            (float(element.position), tuple(float(v) for v in element.color))
            for element in ramp.elements
        ],
    }


def _snapshot_mask_ramps(group) -> dict[str, dict]:
    snapshots: dict[str, dict] = {}
    if group is None:
        return snapshots
    for node in group.nodes:
        if node.bl_idname != 'ShaderNodeValToRGB':
            continue
        rig_uuid = str(node.get(MASK_RAMP_NODE_KEY, ""))
        snapshot = _ramp_snapshot(node)
        if rig_uuid and snapshot:
            snapshots[rig_uuid] = snapshot
    return snapshots


def _legacy_mask_ramp_snapshot(label: bpy.types.Object) -> dict:
    """Convert the V2.0 Threshold/Contrast/Feather model to a ColorRamp.

    The old mask is a clamped linear transition. Two ramp stops reproduce that
    transition closely while giving V2.1 users the full native ColorRamp editor.
    """
    data = label.jb3d_labeler
    contrast = max(float(getattr(data, "mask_contrast", 1.0)), 0.01)
    threshold = float(getattr(data, "mask_threshold", 0.5))
    feather = max(float(getattr(data, "mask_feather", 0.01)), 0.001)
    p0 = 0.5 + (threshold - feather - 0.5) / contrast
    p1 = 0.5 + (threshold + feather - 0.5) / contrast
    p0 = max(0.0, min(1.0, p0))
    p1 = max(0.0, min(1.0, p1))
    if p1 <= p0:
        p1 = min(1.0, p0 + 0.001)
    invert = bool(getattr(data, "mask_invert", False))
    black = (0.0, 0.0, 0.0, 1.0)
    white = (1.0, 1.0, 1.0, 1.0)
    return {
        "color_mode": 'RGB',
        "interpolation": 'LINEAR',
        "hue_interpolation": 'NEAR',
        "elements": [(p0, white if invert else black), (p1, black if invert else white)],
    }


def _default_mask_ramp_snapshot() -> dict:
    return {
        "color_mode": 'RGB',
        "interpolation": 'LINEAR',
        "hue_interpolation": 'NEAR',
        "elements": [
            (0.0, (0.0, 0.0, 0.0, 1.0)),
            (1.0, (1.0, 1.0, 1.0, 1.0)),
        ],
    }


def _apply_ramp_snapshot(node, snapshot: dict | None) -> None:
    if node is None or node.bl_idname != 'ShaderNodeValToRGB':
        return
    snapshot = snapshot or _default_mask_ramp_snapshot()
    ramp = node.color_ramp
    for prop in ("color_mode", "interpolation", "hue_interpolation"):
        value = snapshot.get(prop)
        if value is not None:
            try:
                setattr(ramp, prop, value)
            except (AttributeError, TypeError, ValueError):
                pass

    values = list(snapshot.get("elements") or _default_mask_ramp_snapshot()["elements"])
    values.sort(key=lambda item: item[0])
    while len(ramp.elements) > 2:
        try:
            ramp.elements.remove(ramp.elements[-1])
        except (RuntimeError, TypeError):
            break
    while len(ramp.elements) < 2:
        try:
            ramp.elements.new(1.0)
        except (RuntimeError, TypeError):
            break

    base = values[:2] if len(values) >= 2 else _default_mask_ramp_snapshot()["elements"]
    for index, (position, color) in enumerate(base):
        try:
            ramp.elements[index].position = max(0.0, min(1.0, float(position)))
            ramp.elements[index].color = tuple(color)
        except (IndexError, TypeError, ValueError):
            pass
    for position, color in values[2:]:
        try:
            element = ramp.elements.new(max(0.0, min(1.0, float(position))))
            element.color = tuple(color)
        except (RuntimeError, TypeError, ValueError):
            pass


def get_mask_ramp_node(label: bpy.types.Object | None):
    """Return the live native ColorRamp node used by one label, if available."""
    if label is None or not hasattr(label, "jb3d_labeler"):
        return None
    source = _safe_object_link(label.jb3d_labeler, "source_object")
    if source is None:
        return None
    token = str(source.get(SOURCE_UUID_KEY, ""))
    if not token:
        return None
    wanted = mask_ramp_node_name(label)
    for group in bpy.data.node_groups:
        if group.bl_idname != 'ShaderNodeTree' or group.get(STACK_GROUP_OWNER_KEY) != token:
            continue
        node = group.nodes.get(wanted)
        if node is not None and node.bl_idname == 'ShaderNodeValToRGB':
            return node
        rig_uuid = str(label.jb3d_labeler.rig_uuid or "")
        for candidate in group.nodes:
            if (
                candidate.bl_idname == 'ShaderNodeValToRGB'
                and str(candidate.get(MASK_RAMP_NODE_KEY, "")) == rig_uuid
            ):
                return candidate
    return None


def reset_mask_ramp(label: bpy.types.Object | None) -> bool:
    node = get_mask_ramp_node(label)
    if node is None:
        return False
    _apply_ramp_snapshot(node, _default_mask_ramp_snapshot())
    if label is not None:
        label.jb3d_labeler.mask_ramp_version = MASK_RAMP_SCHEMA
    return True


def invert_mask_ramp(label: bpy.types.Object | None) -> bool:
    node = get_mask_ramp_node(label)
    if node is None:
        return False
    for element in node.color_ramp.elements:
        color = element.color
        element.color = (1.0 - color[0], 1.0 - color[1], 1.0 - color[2], color[3])
    return True


def _ensure_single_user_mesh(source: bpy.types.Object) -> None:
    if source.type != 'MESH':
        raise TypeError("Label source must be a mesh object")
    mesh = source.data
    if mesh.users <= 1:
        return
    source.data = mesh.copy()
    source["jb3d_labeler_mesh_made_single_user"] = True


def _remove_attribute(mesh: bpy.types.Mesh, name: str) -> None:
    attr = mesh.attributes.get(name)
    if attr is None:
        return
    try:
        mesh.attributes.remove(attr)
    except (RuntimeError, TypeError):
        pass


def clear_source_attributes(source: bpy.types.Object | None) -> None:
    if source is None or source.type != 'MESH':
        return
    for attr in list(source.data.attributes):
        if attr.name.startswith(SOURCE_UV_PREFIX) or attr.name.startswith(SOURCE_MASK_PREFIX):
            try:
                source.data.attributes.remove(attr)
            except (RuntimeError, TypeError):
                pass


def clear_label_attributes(source: bpy.types.Object | None, label: bpy.types.Object | None) -> None:
    if source is None or source.type != 'MESH' or label is None:
        return
    uv_name, mask_name = attribute_names(label)
    _remove_attribute(source.data, uv_name)
    _remove_attribute(source.data, mask_name)


def _new_attribute(mesh: bpy.types.Mesh, name: str, data_type: str, domain: str):
    existing = mesh.attributes.get(name)
    if existing is not None:
        if existing.data_type == data_type and existing.domain == domain:
            return existing
        _remove_attribute(mesh, name)
    return mesh.attributes.new(name=name, type=data_type, domain=domain)


def _label_source_face_values(label: bpy.types.Object) -> list[int]:
    attr = label.data.attributes.get(SOURCE_FACE_ATTRIBUTE)
    if attr is None or attr.domain != 'FACE' or attr.data_type != 'INT':
        raise ValueError(f"{label.name}: missing source-face mapping")
    return [int(item.value) for item in attr.data]


def _label_source_vertex_values(label: bpy.types.Object) -> list[int]:
    attr = label.data.attributes.get(SOURCE_VERTEX_ATTRIBUTE)
    if attr is None or attr.domain != 'POINT' or attr.data_type != 'INT':
        raise ValueError(f"{label.name}: missing source-vertex mapping")
    return [int(item.value) for item in attr.data]


def _label_uv_lookup(label: bpy.types.Object) -> dict[tuple[int, int], tuple[float, float]]:
    ensure_source_mapping(label)
    mesh = label.data
    uv_layer = mesh.uv_layers.get(UV_NAME)
    if uv_layer is None:
        raise ValueError(f"{label.name}: missing {UV_NAME} UV map")
    face_ids = _label_source_face_values(label)
    vertex_ids = _label_source_vertex_values(label)
    lookup: dict[tuple[int, int], tuple[float, float]] = {}
    for polygon in mesh.polygons:
        source_face = face_ids[polygon.index]
        if source_face < 0:
            continue
        for loop_index in polygon.loop_indices:
            loop = mesh.loops[loop_index]
            source_vertex = vertex_ids[loop.vertex_index]
            if source_vertex < 0:
                continue
            uv = uv_layer.data[loop_index].uv
            lookup[(source_face, source_vertex)] = (float(uv.x), float(uv.y))
    return lookup


def bake_label_attributes(source: bpy.types.Object, label: bpy.types.Object) -> set[int]:
    """Bake one label's native coordinates and support mask onto the product mesh."""
    if source.type != 'MESH' or label.type != 'MESH':
        return set()
    if _safe_object_link(label.jb3d_labeler, "source_object") != source:
        return set()

    lookup = _label_uv_lookup(label)
    if not lookup:
        raise ValueError(f"{label.name}: no usable label coordinates")

    mesh = source.data
    uv_name, mask_name = attribute_names(label)
    uv_attr = _new_attribute(mesh, uv_name, 'FLOAT_VECTOR', 'CORNER')
    mask_attr = _new_attribute(mesh, mask_name, 'FLOAT', 'CORNER')

    # Rebuild deterministically. CORNER data is important: masks end exactly at
    # the selected face boundary instead of bleeding to neighbouring polygons.
    for item in uv_attr.data:
        item.vector = (0.0, 0.0, 0.0)
    for item in mask_attr.data:
        item.value = 0.0

    touched_materials: set[int] = set()
    matched = 0
    for polygon in mesh.polygons:
        polygon_matched = False
        for loop_index in polygon.loop_indices:
            loop = mesh.loops[loop_index]
            uv = lookup.get((polygon.index, loop.vertex_index))
            if uv is None:
                continue
            uv_attr.data[loop_index].vector = (uv[0], uv[1], 0.0)
            mask_attr.data[loop_index].value = 1.0
            polygon_matched = True
            matched += 1
        if polygon_matched:
            touched_materials.add(int(polygon.material_index))

    if matched == 0:
        _remove_attribute(mesh, uv_name)
        _remove_attribute(mesh, mask_name)
        raise ValueError(f"{label.name}: source topology no longer matches the label")
    return touched_materials


def _group_for_source(source: bpy.types.Object):
    token = source_uuid(source)
    for group in bpy.data.node_groups:
        if group.get(STACK_GROUP_OWNER_KEY) == token and group.bl_idname == 'ShaderNodeTree':
            return group
    preferred = f"{STACK_GROUP_PREFIX}{_safe_token(source.name, 28)}"
    group = bpy.data.node_groups.get(preferred)
    if group is not None and group.get(STACK_GROUP_OWNER_KEY) != token:
        preferred = f"{preferred} {_safe_token(token.replace('-', ''), 8)}"
    group = bpy.data.node_groups.new(preferred, 'ShaderNodeTree')
    group[STACK_GROUP_OWNER_KEY] = token
    group[STACK_GROUP_SCHEMA_KEY] = STACK_GROUP_SCHEMA
    group.use_fake_user = True
    try:
        group.description = "JB3D Labeler V2 material-decal stack for one product"
    except Exception:
        pass
    materials._new_interface_socket(group, "Base Color", 'INPUT', 'NodeSocketColor', (0.8, 0.8, 0.8, 1.0))
    materials._new_interface_socket(group, "Roughness", 'INPUT', 'NodeSocketFloat', 0.5)
    materials._new_interface_socket(group, "Metallic", 'INPUT', 'NodeSocketFloat', 0.0)
    materials._new_interface_socket(group, "Base Color", 'OUTPUT', 'NodeSocketColor')
    materials._new_interface_socket(group, "Roughness", 'OUTPUT', 'NodeSocketFloat')
    materials._new_interface_socket(group, "Metallic", 'OUTPUT', 'NodeSocketFloat')
    return group


def _new_value(nodes, name: str, value: float, location):
    node = nodes.new("ShaderNodeValue")
    node.name = name
    node.label = name.replace("JB3D_", "")
    node.location = location
    node.outputs[0].default_value = float(value)
    return node


def _add_color_driver(socket, label: bpy.types.Object, data_path: str) -> None:
    for index in range(4):
        try:
            socket.driver_remove("default_value", index)
        except (TypeError, RuntimeError):
            pass
        fcurve = socket.driver_add("default_value", index)
        driver = fcurve.driver
        driver.type = 'SCRIPTED'
        driver.expression = "v"
        variable = driver.variables.new()
        variable.name = "v"
        variable.type = 'SINGLE_PROP'
        target = variable.targets[0]
        target.id = label
        target.data_path = f"{data_path}[{index}]"


def _new_driven_value(nodes, label, name: str, data_path: str, location, expression: str = "v"):
    node = _new_value(nodes, name, 0.0, location)
    materials._add_property_driver(node.outputs[0], label, data_path, expression=expression)
    return node.outputs[0]


def _new_driven_color(nodes, label, name: str, data_path: str, location):
    node = nodes.new("ShaderNodeRGB")
    node.name = name
    node.label = "Effect Color"
    node.location = location
    _add_color_driver(node.outputs[0], label, data_path)
    return node.outputs[0]


def _float_mix(nodes, links, factor, a, b, *, name: str, location):
    node = nodes.new("ShaderNodeMix")
    node.name = name
    node.label = name.replace("JB3D_", "")
    node.data_type = 'FLOAT'
    node.location = location
    # Blender 4.5/5.x ShaderNodeMix FLOAT sockets are named Factor, A and B.
    factor_socket = next((s for s in node.inputs if s.name == "Factor" and getattr(s, "type", "") == 'VALUE'), node.inputs[0])
    a_socket = next((s for s in node.inputs if s.name == "A" and getattr(s, "type", "") == 'VALUE'), None)
    b_socket = next((s for s in node.inputs if s.name == "B" and getattr(s, "type", "") == 'VALUE'), None)
    if a_socket is None or b_socket is None:
        value_inputs = [s for s in node.inputs if getattr(s, "type", "") == 'VALUE']
        a_socket = a_socket or (value_inputs[-2] if len(value_inputs) >= 2 else node.inputs[-2])
        b_socket = b_socket or (value_inputs[-1] if len(value_inputs) >= 1 else node.inputs[-1])
    result = next((s for s in node.outputs if s.name == "Result" and getattr(s, "type", "") == 'VALUE'), None)
    result = result or next((s for s in node.outputs if getattr(s, "type", "") == 'VALUE'), node.outputs[0])
    links.new(factor, factor_socket)
    links.new(a, a_socket)
    links.new(b, b_socket)
    return result


def _multiply(nodes, links, a, b, name: str, location):
    node = nodes.new("ShaderNodeMath")
    node.name = name
    node.operation = 'MULTIPLY'
    node.location = location
    links.new(a, node.inputs[0])
    links.new(b, node.inputs[1])
    return node.outputs[0]


def _constant_factor(nodes, name: str, value: float, location):
    return _new_value(nodes, name, value, location).outputs[0]


def _channel_socket(nodes, links, color_socket, alpha_socket, channel: str, *, prefix: str, location):
    if channel == 'ALPHA':
        return alpha_socket
    if channel == 'LUMINANCE':
        bw = nodes.new("ShaderNodeRGBToBW")
        bw.name = prefix + "LUMINANCE"
        bw.label = "Luminance"
        bw.location = location
        links.new(color_socket, bw.inputs[0])
        return bw.outputs[0]

    separate = nodes.new("ShaderNodeSeparateColor")
    separate.name = prefix + "CHANNEL"
    separate.label = f"Mask {channel.title()}"
    separate.location = location
    links.new(color_socket, separate.inputs["Color"])
    output_name = {'RED': 'Red', 'GREEN': 'Green', 'BLUE': 'Blue'}.get(channel, 'Red')
    return separate.outputs[output_name]


def _create_mask_ramp_node(
    nodes,
    label,
    *,
    location,
    ramp_snapshot: dict | None = None,
):
    x, y = location
    ramp_node = nodes.new("ShaderNodeValToRGB")
    ramp_node.name = mask_ramp_node_name(label)
    ramp_node.label = "Mask Color Ramp"
    ramp_node.location = (x, y)
    rig_uuid = str(label.jb3d_labeler.rig_uuid or "")
    ramp_node[MASK_RAMP_NODE_KEY] = rig_uuid
    ramp_node[MASK_RAMP_SCHEMA_KEY] = MASK_RAMP_SCHEMA

    if ramp_snapshot is None:
        if int(getattr(label.jb3d_labeler, "mask_ramp_version", 0)) < MASK_RAMP_SCHEMA:
            ramp_snapshot = _legacy_mask_ramp_snapshot(label)
        else:
            ramp_snapshot = _default_mask_ramp_snapshot()
    _apply_ramp_snapshot(ramp_node, ramp_snapshot)
    label.jb3d_labeler.mask_ramp_version = MASK_RAMP_SCHEMA
    return ramp_node


def _processed_mask(
    nodes,
    links,
    label,
    raw_socket,
    *,
    prefix: str,
    location,
    ramp_snapshot: dict | None = None,
):
    """Process a mask through Blender's native ColorRamp node.

    The ColorRamp itself is the persistent editing surface shown in the sidebar.
    Its full element/interpolation state is snapshotted before structural stack
    rebuilds and restored afterwards, so moving a stop never needs a custom
    property synchronization layer.
    """
    x, y = location
    ramp_node = _create_mask_ramp_node(
        nodes, label, location=(x, y), ramp_snapshot=ramp_snapshot,
    )
    links.new(raw_socket, ramp_node.inputs["Fac"])

    # ColorRamp can technically contain colored stops. Material masks remain a
    # scalar by converting its displayed color output to luminance.
    bw = nodes.new("ShaderNodeRGBToBW")
    bw.name = prefix + "TO_FACTOR"
    bw.label = "Mask Luminance"
    bw.location = (x + 230, y + 30)
    links.new(ramp_node.outputs["Color"], bw.inputs["Color"])
    # Respect ColorRamp stop alpha as well as stop color, matching the native
    # node's complete editing model exposed in the sidebar.
    factor = _multiply(
        nodes, links, bw.outputs[0], ramp_node.outputs["Alpha"],
        prefix + "RAMP_ALPHA", (x + 420, y),
    )
    return factor


def _coordinate_bounds_mask(nodes, links, vector_socket, *, prefix: str, location):
    """Return 1 only inside the artwork 0–1 rectangle.

    Image Texture > Clip is usually transparent outside the image, but an
    explicit bounds mask makes JPEG and unusual alpha/color-space cases
    deterministic and prevents partial 360° labels from leaking around a band.
    """
    x, y = location
    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.name = prefix + "BOUNDS_XY"
    separate.location = (x, y)
    links.new(vector_socket, separate.inputs["Vector"])

    tests = []
    for suffix, socket, operation, threshold, lx, ly in (
        ("U_MIN", separate.outputs["X"], 'GREATER_THAN', -1e-6, x + 170, y + 80),
        ("U_MAX", separate.outputs["X"], 'LESS_THAN', 1.000001, x + 170, y),
        ("V_MIN", separate.outputs["Y"], 'GREATER_THAN', -1e-6, x + 170, y - 80),
        ("V_MAX", separate.outputs["Y"], 'LESS_THAN', 1.000001, x + 170, y - 160),
    ):
        node = nodes.new("ShaderNodeMath")
        node.name = prefix + suffix
        node.operation = operation
        node.location = (lx, ly)
        links.new(socket, node.inputs[0])
        node.inputs[1].default_value = threshold
        tests.append(node.outputs[0])

    uv_ok = _multiply(nodes, links, tests[0], tests[1], prefix + "U_BOUNDS", (x + 350, y + 60))
    v_ok = _multiply(nodes, links, tests[2], tests[3], prefix + "V_BOUNDS", (x + 350, y - 100))
    return _multiply(nodes, links, uv_ok, v_ok, prefix + "UV_BOUNDS", (x + 520, y - 20))


def _layer_nodes(nodes, links, label, *, y: float, ramp_snapshots: dict[str, dict] | None = None):
    """Build one label layer and return its sockets.

    Returns: (color, alpha, roughness, metallic, processed_mask, footprint_mask)
    """
    data = label.jb3d_labeler
    controller = _safe_object_link(data, "controller_object")
    image = data.image
    if controller is None or image is None:
        raise ValueError(f"{label.name}: incomplete controller or image")

    prefix = f"JB3D_{label_token(label)}_"
    uv_name, support_name = attribute_names(label)
    uv_attr = materials._attribute_vector_node(nodes, prefix + "UV", uv_name, (-1600, y + 100))
    support_attr = materials._attribute_factor_node(nodes, prefix + "SUPPORT", support_name, (-1600, y - 80))
    support = materials._attribute_factor_output(support_attr)

    coord, coord_input = materials._create_coordinate_node(
        nodes, label, controller, name=prefix + "COORD", location=(-1370, y + 100)
    )
    links.new(uv_attr.outputs["Vector"], coord.inputs[coord_input])

    image_node = materials._create_image_node(nodes, prefix + "ARTWORK", image, (-1100, y + 100))
    links.new(coord.outputs["Image Coordinates"], image_node.inputs["Vector"])

    # Overall coverage = support × 0–1 artwork bounds × artwork alpha ×
    # label opacity × visibility. The explicit bounds mask is robust for JPEGs
    # and makes partial wrap labels deterministic.
    bounds = _coordinate_bounds_mask(
        nodes, links, coord.outputs["Image Coordinates"],
        prefix=prefix, location=(-1100, y - 120),
    )
    image_alpha = _multiply(
        nodes, links, image_node.outputs["Alpha"], bounds,
        prefix + "IMAGE_ALPHA", (-650, y - 80),
    )
    support_alpha = _multiply(
        nodes, links, image_alpha, support,
        prefix + "SUPPORT_ALPHA", (-480, y - 80),
    )
    strength = _new_value(nodes, prefix + "STRENGTH", 1.0, (-480, y - 220))
    materials._add_layer_strength_driver(strength.outputs[0], label)
    effective_alpha = _multiply(
        nodes, links, support_alpha, strength.outputs[0],
        prefix + "EFFECTIVE_ALPHA", (-300, y - 80),
    )

    # Optional effect mask. It changes selected material properties but does not
    # alter label coverage; transparent pixels still come only from artwork alpha.
    effect_mask = _constant_factor(nodes, prefix + "MASK_ONE", 1.0, (-850, y - 360))
    rig_uuid = str(data.rig_uuid or "")
    saved_ramp = (ramp_snapshots or {}).get(rig_uuid)
    if data.mask_enabled:
        mask_color = image_node.outputs["Color"]
        mask_alpha = image_node.outputs["Alpha"]
        if data.mask_source == 'EXTERNAL_IMAGE' and data.mask_image is not None:
            mask_image = materials._create_image_node(
                nodes, prefix + "MASK_IMAGE", data.mask_image, (-1100, y - 360)
            )
            mask_image.label = "MASK IMAGE"
            links.new(coord.outputs["Image Coordinates"], mask_image.inputs["Vector"])
            mask_color = mask_image.outputs["Color"]
            mask_alpha = mask_image.outputs["Alpha"]
        raw_mask = _channel_socket(
            nodes, links, mask_color, mask_alpha, data.mask_channel,
            prefix=prefix + "MASK_", location=(-850, y - 360),
        )
        effect_mask = _processed_mask(
            nodes, links, label, raw_mask,
            prefix=prefix + "MASK_", location=(-650, y - 360),
            ramp_snapshot=saved_ramp,
        )
    else:
        # Keep the ramp node in the product stack even while the mask is off.
        # This preserves user-edited stops across disable/enable cycles without
        # maintaining a duplicate custom-property representation.
        _create_mask_ramp_node(
            nodes, label, location=(-650, y - 360), ramp_snapshot=saved_ramp,
        )

    # Artwork color processing. Tint/Replace can affect the complete artwork or
    # only the extracted mask, depending on the user's Mask > Affect Color toggle.
    artwork_color = image_node.outputs["Color"]
    modified_color = artwork_color
    if data.color_mode in {'TINT', 'REPLACE'}:
        effect_color = _new_driven_color(
            nodes, label, prefix + "EFFECT_COLOR", "jb3d_labeler.effect_color", (-390, y + 280)
        )
        if data.color_mode == 'TINT':
            tint = materials._new_mix_node(
                nodes, prefix + "TINT", "Tint Artwork", 'MULTIPLY', (-170, y + 260)
            )
            factor, a, b, result = materials._mix_color_sockets(tint)
            factor.default_value = 1.0
            links.new(artwork_color, a)
            links.new(effect_color, b)
            modified_color = result
        else:
            modified_color = effect_color

        if data.mask_enabled and data.mask_affect_color:
            color_mask_mix = materials._new_mix_node(
                nodes, prefix + "COLOR_MASK", "Masked Color Effect", 'MIX', (60, y + 260)
            )
            factor, a, b, result = materials._mix_color_sockets(color_mask_mix)
            links.new(effect_mask, factor)
            links.new(artwork_color, a)
            links.new(modified_color, b)
            modified_color = result

    roughness_base = _new_driven_value(
        nodes, label, prefix + "ROUGHNESS", "jb3d_labeler.roughness", (-360, y - 40)
    )
    roughness_value = roughness_base
    if data.mask_enabled and data.mask_affect_roughness:
        roughness_masked = _new_driven_value(
            nodes, label, prefix + "ROUGHNESS_MASKED", "jb3d_labeler.masked_roughness", (-360, y - 130)
        )
        roughness_value = _float_mix(
            nodes, links, effect_mask, roughness_base, roughness_masked,
            name=prefix + "ROUGHNESS_MIX", location=(-100, y - 80),
        )

    metallic_base = _new_driven_value(
        nodes, label, prefix + "METALLIC", "jb3d_labeler.metallic", (-360, y - 220)
    )
    metallic_value = metallic_base
    if data.mask_enabled and data.mask_affect_metallic:
        metallic_masked = _new_driven_value(
            nodes, label, prefix + "METALLIC_MASKED", "jb3d_labeler.masked_metallic", (-360, y - 310)
        )
        metallic_value = _float_mix(
            nodes, links, effect_mask, metallic_base, metallic_masked,
            name=prefix + "METALLIC_MIX", location=(-100, y - 260),
        )

    return modified_color, effective_alpha, roughness_value, metallic_value, effect_mask, support_alpha


def _build_stack_group(source: bpy.types.Object, labels: list[bpy.types.Object]):
    group = _group_for_source(source)
    group[STACK_GROUP_SCHEMA_KEY] = STACK_GROUP_SCHEMA
    nodes = group.nodes
    links = group.links
    ramp_snapshots = _snapshot_mask_ramps(group)
    try:
        group.animation_data_clear()
    except (AttributeError, RuntimeError):
        pass
    nodes.clear()

    group_input = nodes.new("NodeGroupInput")
    group_input.name = "JB3D_STACK_INPUT"
    group_input.label = "Original Product Material"
    group_input.location = (-2050, 0)
    group_output = nodes.new("NodeGroupOutput")
    group_output.name = "JB3D_STACK_OUTPUT"
    group_output.label = "Material + Labels"
    group_output.location = (1300, 0)

    preview_label = next((label for label in labels if label.jb3d_labeler.preview_mask), None)
    preview_mask_socket = None
    preview_support_socket = None

    color = group_input.outputs["Base Color"]
    roughness = group_input.outputs["Roughness"]
    metallic = group_input.outputs["Metallic"]

    # List order is top-to-bottom; shader evaluation must start at the product
    # material and accumulate from bottom to top.
    for layer_index, label in enumerate(reversed(labels)):
        y = -layer_index * 640.0
        try:
            layer_color, alpha, layer_rough, layer_metal, layer_mask, layer_support = _layer_nodes(
                nodes, links, label, y=y, ramp_snapshots=ramp_snapshots
            )
            if preview_label is not None and label == preview_label:
                preview_mask_socket = layer_mask
                preview_support_socket = layer_support
        except Exception:
            continue

        data = label.jb3d_labeler
        artistic = materials._new_mix_node(
            nodes,
            f"JB3D_LAYER_{layer_index:02d}_BLEND",
            f"{label.name}: {data.blend_mode}",
            data.blend_mode,
            (340, y + 170),
        )
        art_factor, art_a, art_b, art_result = materials._mix_color_sockets(artistic)
        art_factor.default_value = 1.0
        links.new(color, art_a)
        links.new(layer_color, art_b)

        composite = materials._new_mix_node(
            nodes,
            f"JB3D_LAYER_{layer_index:02d}_COMPOSITE",
            "Layer Opacity",
            'MIX',
            (590, y + 170),
        )
        comp_factor, comp_a, comp_b, comp_result = materials._mix_color_sockets(composite)
        links.new(alpha, comp_factor)
        links.new(color, comp_a)
        links.new(art_result, comp_b)
        color = comp_result

        roughness = _float_mix(
            nodes, links, alpha, roughness, layer_rough,
            name=f"JB3D_LAYER_{layer_index:02d}_ROUGHNESS", location=(590, y - 20),
        )
        metallic = _float_mix(
            nodes, links, alpha, metallic, layer_metal,
            name=f"JB3D_LAYER_{layer_index:02d}_METALLIC", location=(590, y - 180),
        )

    if preview_mask_socket is not None and preview_support_socket is not None:
        preview_factor = _multiply(
            nodes, links, preview_mask_socket, preview_support_socket,
            "JB3D_PREVIEW_MASK", (850, 20),
        )
        preview_mix = materials._new_mix_node(
            nodes, "JB3D_PREVIEW_COLOR", "Mask Preview", 'MIX', (1030, 70)
        )
        factor, a, b, result = materials._mix_color_sockets(preview_mix)
        links.new(preview_factor, factor)
        a.default_value = (0.0, 0.0, 0.0, 1.0)
        b.default_value = (1.0, 1.0, 1.0, 1.0)
        links.new(result, group_output.inputs["Base Color"])
        links.new(group_input.outputs["Roughness"], group_output.inputs["Roughness"])
        links.new(group_input.outputs["Metallic"], group_output.inputs["Metallic"])
    else:
        links.new(color, group_output.inputs["Base Color"])
        links.new(roughness, group_output.inputs["Roughness"])
        links.new(metallic, group_output.inputs["Metallic"])
    return group


def _active_material_outputs(material: bpy.types.Material):
    if not material.use_nodes or material.node_tree is None:
        return []
    outputs = [node for node in material.node_tree.nodes if node.bl_idname == 'ShaderNodeOutputMaterial']
    active = [node for node in outputs if getattr(node, "is_active_output", False)]
    return active or outputs


def _reachable_principled(material: bpy.types.Material) -> list:
    """Find top-level Principled BSDF nodes that contribute to Material Output."""
    if material.node_tree is None:
        return []
    found = []
    seen = set()

    def visit(node):
        pointer = node.as_pointer()
        if pointer in seen:
            return
        seen.add(pointer)
        if node.bl_idname == 'ShaderNodeBsdfPrincipled':
            found.append(node)
            return
        for socket in node.inputs:
            for link in socket.links:
                visit(link.from_node)

    for output in _active_material_outputs(material):
        surface = output.inputs.get("Surface")
        if surface is None:
            continue
        for link in surface.links:
            visit(link.from_node)
    # Preserve node-tree order while de-duplicating.
    unique = []
    pointers = set()
    for node in found:
        if node.as_pointer() not in pointers:
            pointers.add(node.as_pointer())
            unique.append(node)
    return unique


def _slot_material(source: bpy.types.Object, index: int):
    if index < 0 or index >= len(source.material_slots):
        return None
    return source.material_slots[index].material


def _material_local_usage(source: bpy.types.Object, material: bpy.types.Material) -> int:
    return sum(1 for slot in source.material_slots if slot.material == material)


def _make_material_local(source: bpy.types.Object, material: bpy.types.Material):
    token = source_uuid(source)
    if material.get(MATERIAL_SOURCE_KEY) == token:
        return material
    local_usage = _material_local_usage(source, material)
    if material.users <= local_usage:
        material[MATERIAL_SOURCE_KEY] = token
        return material

    copy = material.copy()
    copy.name = f"{material.name} - JB3D"
    copy[MATERIAL_SOURCE_KEY] = token
    copy[MATERIAL_ORIGINAL_KEY] = material.name
    # Object.material_slots respects OBJECT-linked material overrides as well as
    # normal DATA-linked slots. The source mesh is already single-user here.
    for slot in source.material_slots:
        if slot.material == material:
            slot.material = copy
    return copy


def _ensure_material_slot(source: bpy.types.Object, index: int):
    while len(source.material_slots) <= index:
        filler = bpy.data.materials.new(f"{source.name} Material {len(source.material_slots) + 1}")
        filler.use_nodes = True
        source.data.materials.append(filler)
    material = _slot_material(source, index)
    if material is None:
        material = bpy.data.materials.new(f"{source.name} Material {index + 1}")
        material.use_nodes = True
        source.material_slots[index].material = material
    return _make_material_local(source, material)


def _integration_nodes(material: bpy.types.Material, token: str):
    if not material.use_nodes or material.node_tree is None:
        return []
    return [
        node for node in material.node_tree.nodes
        if node.get(INTEGRATION_NODE_KEY) == token
    ]


def _principled_integration_health(material, principled, token: str) -> tuple[bool, bool, bool]:
    """Return whether JB3D still owns the three Principled input links.

    Numeric material edits do not affect this signature. Replacing a material,
    adding/removing a supported Principled, or reconnecting Base Color,
    Roughness or Metallic does. This makes automatic material re-integration
    cheap enough to check from the depsgraph without rebuilding on every slider
    change in the Material properties.
    """
    health = []
    for socket_name in ("Base Color", "Roughness", "Metallic"):
        pin = principled.inputs.get(socket_name)
        if pin is None:
            health.append(True)
            continue
        ok = False
        for link in pin.links:
            node = link.from_node
            if node is None or node.get(INTEGRATION_NODE_KEY) != token:
                continue
            if link.from_socket == node.outputs.get(socket_name):
                ok = True
                break
        health.append(ok)
    return tuple(health)


def material_binding_signature(source: bpy.types.Object | None) -> tuple:
    """Structural material signature used by the lightweight auto-sync watcher.

    The signature intentionally ignores colors and numeric shader values. It
    only changes when material slots change or when the JB3D insertion point is
    structurally broken/created, so normal material tweaking stays free.
    """
    if source is None or source.type != 'MESH':
        return ()
    token = str(source.get(SOURCE_UUID_KEY, ""))
    slots = []
    for index, slot in enumerate(source.material_slots):
        material = slot.material
        if material is None:
            slots.append((index, 0, ()))
            continue
        try:
            pointer = int(material.as_pointer())
        except (ReferenceError, RuntimeError):
            pointer = 0
        principled_state = []
        if material.use_nodes and material.node_tree is not None:
            for principled in _reachable_principled(material):
                try:
                    pptr = int(principled.as_pointer())
                except (ReferenceError, RuntimeError):
                    pptr = 0
                health = _principled_integration_health(material, principled, token) if token else (False, False, False)
                principled_state.append((pptr, health))
        slots.append((index, pointer, tuple(principled_state)))
    return tuple(slots)


def _principled_fed_by_integration(node):
    for output in node.outputs:
        for link in output.links:
            if link.to_node.bl_idname == 'ShaderNodeBsdfPrincipled':
                return link.to_node
    return None


def _restore_integration_node(material: bpy.types.Material, node) -> None:
    tree = material.node_tree
    if tree is None:
        return
    principled_name = str(node.get(INTEGRATION_PRINCIPLED_KEY, ""))
    principled = tree.nodes.get(principled_name)
    if principled is None or principled.bl_idname != 'ShaderNodeBsdfPrincipled':
        principled = _principled_fed_by_integration(node)
    if principled is not None and principled.bl_idname == 'ShaderNodeBsdfPrincipled':
        for socket_name in ("Base Color", "Roughness", "Metallic"):
            pin = principled.inputs.get(socket_name)
            group_input = node.inputs.get(socket_name)
            group_output = node.outputs.get(socket_name)
            if pin is None or group_input is None or group_output is None:
                continue
            out_links = [link for link in list(pin.links) if link.from_node == node and link.from_socket == group_output]
            if not out_links:
                continue
            upstream = group_input.links[0] if group_input.is_linked and group_input.links else None
            for link in out_links:
                tree.links.remove(link)
            if upstream is not None:
                from_socket = upstream.from_socket
                tree.links.remove(upstream)
                try:
                    tree.links.new(from_socket, pin)
                except (RuntimeError, TypeError):
                    pass
            else:
                try:
                    pin.default_value = group_input.default_value
                except (AttributeError, TypeError, ValueError):
                    pass
    try:
        tree.nodes.remove(node)
    except (RuntimeError, TypeError):
        pass


def remove_material_integration(source: bpy.types.Object | None, material_indices: set[int] | None = None) -> int:
    if source is None or source.type != 'MESH':
        return 0
    token = str(source.get(SOURCE_UUID_KEY, ""))
    if not token:
        return 0

    if material_indices is None:
        # Scan all materials, not only current slots. A user may replace a
        # material while labels exist; the old material must not keep a stale
        # product-specific JB3D group after it leaves the product.
        candidates = list(bpy.data.materials)
    else:
        candidates = []
        for index in sorted(material_indices):
            material = _slot_material(source, index)
            if material is not None:
                candidates.append(material)

    removed = 0
    seen_materials = set()
    for material in candidates:
        try:
            pointer = material.as_pointer()
        except (ReferenceError, RuntimeError):
            continue
        if pointer in seen_materials:
            continue
        seen_materials.add(pointer)
        for node in list(_integration_nodes(material, token)):
            _restore_integration_node(material, node)
            removed += 1
        if not _integration_nodes(material, token) and not material.get(MATERIAL_ORIGINAL_KEY):
            try:
                del material[MATERIAL_SOURCE_KEY]
            except KeyError:
                pass
    return removed


def _integrate_principled(material, principled, group, token: str):
    tree = material.node_tree
    # Reuse an integration node only when it is still physically connected to
    # this exact Principled node. Names are not stable enough for ownership:
    # users can delete/recreate a Principled and Blender may reuse the same
    # display name. In that case we must wrap the new node's current inputs, not
    # accidentally resurrect the previous material wiring.
    existing = next(
        (
            node for node in _integration_nodes(material, token)
            if _principled_fed_by_integration(node) == principled
        ),
        None,
    )
    node = existing
    created = node is None
    if node is None:
        node = tree.nodes.new("ShaderNodeGroup")
        node.name = f"{INTEGRATION_NODE_PREFIX}{_safe_token(principled.name, 24)}"
        node.label = "JB3D Label Stack"
        node[INTEGRATION_NODE_KEY] = token
        node.location = (principled.location.x - 300.0, principled.location.y)
        node.width = 220
    node[INTEGRATION_PRINCIPLED_KEY] = principled.name
    node.node_tree = group

    for socket_name in ("Base Color", "Roughness", "Metallic"):
        pin = principled.inputs.get(socket_name)
        group_input = node.inputs.get(socket_name)
        group_output = node.outputs.get(socket_name)
        if pin is None or group_input is None or group_output is None:
            continue

        current_from_group = next(
            (link for link in pin.links if link.from_node == node and link.from_socket == group_output),
            None,
        )
        if current_from_group is None:
            prior_link = pin.links[0] if pin.is_linked and pin.links else None
            if prior_link is not None:
                from_socket = prior_link.from_socket
                tree.links.remove(prior_link)
                tree.links.new(from_socket, group_input)
            else:
                try:
                    group_input.default_value = pin.default_value
                except (AttributeError, TypeError, ValueError):
                    pass
            tree.links.new(group_output, pin)
        elif created and not group_input.is_linked:
            try:
                group_input.default_value = pin.default_value
            except (AttributeError, TypeError, ValueError):
                pass
    return node


def _remove_obsolete_principled_integrations(
    material: bpy.types.Material,
    token: str,
    live_principleds: list,
) -> None:
    """Restore/remove JB3D nodes that no longer feed a live Principled.

    This matters when users rebuild their product shader after creating labels:
    deleting/replacing a Principled must not leave detached JB3D groups or stale
    upstream links behind. The current material graph is always treated as the
    source of truth.
    """
    live_pointers = set()
    for principled in live_principleds:
        try:
            live_pointers.add(int(principled.as_pointer()))
        except (ReferenceError, RuntimeError):
            pass

    for node in list(_integration_nodes(material, token)):
        principled = _principled_fed_by_integration(node)
        try:
            pointer = int(principled.as_pointer()) if principled is not None else 0
        except (ReferenceError, RuntimeError):
            pointer = 0
        if pointer and pointer in live_pointers:
            continue
        _restore_integration_node(material, node)


def _remove_stale_integrations(source: bpy.types.Object, keep_materials: set[int]) -> None:
    token = source_uuid(source)
    keep_pointers = {
        source.material_slots[index].material.as_pointer()
        for index in keep_materials
        if 0 <= index < len(source.material_slots)
        and source.material_slots[index].material is not None
    }

    # A material can disappear from the product slots without being deleted
    # from the .blend. Restore every old product-specific integration that is no
    # longer used by this product, including materials that are now detached.
    for material in list(bpy.data.materials):
        try:
            pointer = material.as_pointer()
        except (ReferenceError, RuntimeError):
            continue
        if pointer in keep_pointers:
            continue
        for node in list(_integration_nodes(material, token)):
            _restore_integration_node(material, node)


def _remove_stack_group_if_unused(source: bpy.types.Object) -> None:
    token = str(source.get(SOURCE_UUID_KEY, ""))
    if not token:
        return
    for group in list(bpy.data.node_groups):
        if group.get(STACK_GROUP_OWNER_KEY) != token:
            continue
        # Fake user keeps the reusable stack alive during normal operation; when
        # there are no labels we explicitly release and delete it if possible.
        group.use_fake_user = False
        if group.users == 0:
            try:
                bpy.data.node_groups.remove(group)
            except (RuntimeError, TypeError):
                pass


def rebuild_product(source: bpy.types.Object | None, labels: list[bpy.types.Object]) -> ProductBuildReport:
    report = ProductBuildReport(labels=len(labels))
    if source is None or source.type != 'MESH':
        report.warnings.append("Product is missing or is not a mesh")
        return report

    valid_input_labels = []
    for label in labels:
        try:
            if (
                label is not None
                and label.type == 'MESH'
                and hasattr(label, "jb3d_labeler")
                and label.jb3d_labeler.role == ROLE_LABEL
                and _safe_object_link(label.jb3d_labeler, "source_object") == source
                and label.jb3d_labeler.image is not None
                and _safe_object_link(label.jb3d_labeler, "controller_object") is not None
            ):
                valid_input_labels.append(label)
            elif label is not None and hasattr(label, "jb3d_labeler"):
                label.jb3d_labeler.material_status = "Incomplete label rig (missing Controller or source)"
        except (ReferenceError, RuntimeError, AttributeError):
            continue
    labels = valid_input_labels
    report.labels = len(labels)

    if not labels:
        clear_source_attributes(source)
        remove_material_integration(source)
        _remove_stack_group_if_unused(source)
        return report

    _ensure_single_user_mesh(source)
    clear_source_attributes(source)

    touched_materials: set[int] = set()
    valid_labels: list[bpy.types.Object] = []
    for label in labels:
        try:
            touched_materials.update(bake_label_attributes(source, label))
            valid_labels.append(label)
            label.jb3d_labeler.material_status = ""
        except Exception as exc:
            label.jb3d_labeler.material_status = str(exc)
            report.warnings.append(str(exc))

    if not valid_labels:
        remove_material_integration(source)
        return report

    if not touched_materials:
        touched_materials.add(0)
    group = _build_stack_group(source, valid_labels)
    _remove_stale_integrations(source, touched_materials)

    seen_materials: set[int] = set()
    supported_materials = 0
    for material_index in sorted(touched_materials):
        try:
            material = _ensure_material_slot(source, material_index)
            material.use_nodes = True
            pointer = material.as_pointer()
            if pointer in seen_materials:
                continue
            seen_materials.add(pointer)
            principled_nodes = _reachable_principled(material)
            if not principled_nodes:
                report.warnings.append(
                    f"{material.name}: no top-level Principled BSDF connected to Material Output"
                )
                continue
            token = source_uuid(source)
            for principled in principled_nodes:
                _integrate_principled(material, principled, group, token)
                report.principled_nodes += 1
            _remove_obsolete_principled_integrations(material, token, principled_nodes)
            supported_materials += 1
        except Exception as exc:
            report.warnings.append(f"Material slot {material_index}: {exc}")

    report.materials = supported_materials
    status = (
        f"Material Decal active on {supported_materials} material(s)"
        if supported_materials
        else "Material Decal could not find a supported Principled BSDF"
    )
    for label in valid_labels:
        label.jb3d_labeler.material_status = status
        # Mapping surfaces are data carriers only in V2. They must never render,
        # otherwise shader displacement would again create intersections.
        label.hide_render = True
        label.hide_viewport = not bool(label.jb3d_labeler.debug_show_surface)
        label.hide_select = not bool(label.jb3d_labeler.debug_show_surface)

    return report
