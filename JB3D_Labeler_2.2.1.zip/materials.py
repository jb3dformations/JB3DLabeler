# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import bpy

from .utils import UV_NAME, add_transform_driver


NODE_PREFIX = "JB3D_LABEL_"
COORD_GROUP_NAME = "JB3D Label Coordinates v1"
COORD_GROUP_SCHEMA = 2
COORD_NODE_NAME = f"{NODE_PREFIX}COORDINATES"
WRAP_COORD_GROUP_NAME = "JB3D Wrap Coordinates v2"
WRAP_COORD_GROUP_SCHEMA = 2
WRAP_COORD_NODE_NAME = f"{NODE_PREFIX}WRAP_COORDINATES"
GROUP_OWNER_KEY = "jb3d_labeler_group"
GROUP_OWNER_COORDINATES = "coordinates"
GROUP_OWNER_WRAP = "wrap_coordinates"


def _new_math(nodes, operation: str, name: str, x: float, y: float):
    node = nodes.new("ShaderNodeMath")
    node.name = name
    node.label = name.replace(NODE_PREFIX, "")
    node.operation = operation
    node.location = (x, y)
    return node


def _new_interface_socket(
    node_tree: bpy.types.NodeTree,
    name: str,
    in_out: str,
    socket_type: str,
    default_value=None,
):
    """Create a node-group socket with Blender 4.x/5.x and a legacy fallback."""
    if hasattr(node_tree, "interface"):
        socket = node_tree.interface.new_socket(
            name=name,
            in_out=in_out,
            socket_type=socket_type,
        )
    else:  # pragma: no cover - compatibility fallback for older Blender files.
        collection = node_tree.inputs if in_out == 'INPUT' else node_tree.outputs
        socket = collection.new(socket_type, name)

    if default_value is not None and hasattr(socket, "default_value"):
        try:
            socket.default_value = default_value
        except (TypeError, ValueError):
            pass
    return socket


def _coordinate_group_is_valid(group: bpy.types.NodeTree | None) -> bool:
    if group is None or group.bl_idname != 'ShaderNodeTree':
        return False
    if int(group.get("jb3d_schema", 0)) != COORD_GROUP_SCHEMA:
        return False
    return (
        group.nodes.get("JB3D_COORD_INPUT") is not None
        and group.nodes.get("JB3D_COORD_OUTPUT") is not None
    )


def _managed_group(owner: str, validator) -> bpy.types.NodeTree | None:
    """Find a valid node group created and owned by JB3D Labeler."""
    for candidate in bpy.data.node_groups:
        if candidate.get(GROUP_OWNER_KEY) == owner and validator(candidate):
            return candidate
    return None


def ensure_coordinate_group() -> bpy.types.NodeTree:
    """Return the shared coordinate-transform group used by all label materials."""
    group = bpy.data.node_groups.get(COORD_GROUP_NAME)
    if _coordinate_group_is_valid(group):
        group[GROUP_OWNER_KEY] = GROUP_OWNER_COORDINATES
        return group

    # Never remove or overwrite an unknown user node group with a colliding name.
    managed = _managed_group(GROUP_OWNER_COORDINATES, _coordinate_group_is_valid)
    if managed is not None:
        return managed

    group_name = (
        COORD_GROUP_NAME
        if group is None
        else f"{COORD_GROUP_NAME} - JB3D Managed v{COORD_GROUP_SCHEMA}"
    )
    group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group["jb3d_schema"] = COORD_GROUP_SCHEMA
    group[GROUP_OWNER_KEY] = GROUP_OWNER_COORDINATES
    group.use_fake_user = True
    try:
        group.description = (
            "Transforms metric JB3D label UVs with the label controller: "
            "translation, rotation, physical width and physical height."
        )
    except Exception:
        pass

    _new_interface_socket(group, "Metric UV", 'INPUT', 'NodeSocketVector', (0.0, 0.0, 0.0))
    _new_interface_socket(group, "Center U", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Center V", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Rotation", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Width", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Image Coordinates", 'OUTPUT', 'NodeSocketVector')

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.name = "JB3D_COORD_INPUT"
    group_input.label = "Label Controls"
    group_input.location = (-1000, 20)

    group_output = nodes.new("NodeGroupOutput")
    group_output.name = "JB3D_COORD_OUTPUT"
    group_output.label = "0–1 Coordinates"
    group_output.location = (720, 80)

    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.name = "JB3D_COORD_SEPARATE"
    separate.label = "Separate UV"
    separate.location = (-780, 180)

    subtract_u = _new_math(nodes, 'SUBTRACT', "JB3D_COORD_SUB_U", -560, 260)
    subtract_v = _new_math(nodes, 'SUBTRACT', "JB3D_COORD_SUB_V", -560, 80)

    cosine = _new_math(nodes, 'COSINE', "JB3D_COORD_COS", -560, -160)
    sine = _new_math(nodes, 'SINE', "JB3D_COORD_SIN", -560, -300)

    dx_cos = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DX_COS", -330, 330)
    dy_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DY_SIN", -330, 210)
    rotated_x = _new_math(nodes, 'ADD', "JB3D_COORD_ROT_X", -100, 280)

    dx_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DX_SIN", -330, 50)
    dy_cos = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_DY_COS", -330, -80)
    negative_dx_sin = _new_math(nodes, 'MULTIPLY', "JB3D_COORD_NEG_DX_SIN", -100, 40)
    negative_dx_sin.inputs[1].default_value = -1.0
    rotated_y = _new_math(nodes, 'ADD', "JB3D_COORD_ROT_Y", 110, -20)

    divide_u = _new_math(nodes, 'DIVIDE', "JB3D_COORD_DIV_U", 120, 280)
    divide_v = _new_math(nodes, 'DIVIDE', "JB3D_COORD_DIV_V", 330, -20)

    add_half_u = _new_math(nodes, 'ADD', "JB3D_COORD_ADD_HALF_U", 340, 280)
    add_half_u.inputs[1].default_value = 0.5
    add_half_v = _new_math(nodes, 'ADD', "JB3D_COORD_ADD_HALF_V", 540, -20)
    add_half_v.inputs[1].default_value = 0.5

    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.name = "JB3D_COORD_COMBINE"
    combine.label = "Image Coordinates"
    combine.location = (540, 170)
    combine.inputs["Z"].default_value = 0.0

    links.new(group_input.outputs["Metric UV"], separate.inputs["Vector"])
    links.new(separate.outputs["X"], subtract_u.inputs[0])
    links.new(group_input.outputs["Center U"], subtract_u.inputs[1])
    links.new(separate.outputs["Y"], subtract_v.inputs[0])
    links.new(group_input.outputs["Center V"], subtract_v.inputs[1])

    links.new(group_input.outputs["Rotation"], cosine.inputs[0])
    links.new(group_input.outputs["Rotation"], sine.inputs[0])

    links.new(subtract_u.outputs[0], dx_cos.inputs[0])
    links.new(cosine.outputs[0], dx_cos.inputs[1])
    links.new(subtract_v.outputs[0], dy_sin.inputs[0])
    links.new(sine.outputs[0], dy_sin.inputs[1])
    links.new(dx_cos.outputs[0], rotated_x.inputs[0])
    links.new(dy_sin.outputs[0], rotated_x.inputs[1])

    links.new(subtract_u.outputs[0], dx_sin.inputs[0])
    links.new(sine.outputs[0], dx_sin.inputs[1])
    links.new(subtract_v.outputs[0], dy_cos.inputs[0])
    links.new(cosine.outputs[0], dy_cos.inputs[1])
    links.new(dx_sin.outputs[0], negative_dx_sin.inputs[0])
    links.new(negative_dx_sin.outputs[0], rotated_y.inputs[0])
    links.new(dy_cos.outputs[0], rotated_y.inputs[1])

    links.new(rotated_x.outputs[0], divide_u.inputs[0])
    links.new(group_input.outputs["Width"], divide_u.inputs[1])
    links.new(rotated_y.outputs[0], divide_v.inputs[0])
    links.new(group_input.outputs["Height"], divide_v.inputs[1])

    links.new(divide_u.outputs[0], add_half_u.inputs[0])
    links.new(divide_v.outputs[0], add_half_v.inputs[0])
    links.new(add_half_u.outputs[0], combine.inputs["X"])
    links.new(add_half_v.outputs[0], combine.inputs["Y"])
    links.new(combine.outputs["Vector"], group_output.inputs["Image Coordinates"])

    return group


def _wrap_coordinate_group_is_valid(group: bpy.types.NodeTree | None) -> bool:
    if group is None or group.bl_idname != 'ShaderNodeTree':
        return False
    return (
        int(group.get("jb3d_wrap_schema", 0)) == WRAP_COORD_GROUP_SCHEMA
        and group.nodes.get("JB3D_WRAP_INPUT") is not None
        and group.nodes.get("JB3D_WRAP_OUTPUT") is not None
    )


def ensure_wrap_coordinate_group() -> bpy.types.NodeTree:
    """Create the shared physical-size coordinate group for 360° labels."""
    group = bpy.data.node_groups.get(WRAP_COORD_GROUP_NAME)
    if _wrap_coordinate_group_is_valid(group):
        group[GROUP_OWNER_KEY] = GROUP_OWNER_WRAP
        return group

    # Preserve unrelated user data if the preferred node-group name is occupied.
    managed = _managed_group(GROUP_OWNER_WRAP, _wrap_coordinate_group_is_valid)
    if managed is not None:
        return managed

    group_name = (
        WRAP_COORD_GROUP_NAME
        if group is None
        else f"{WRAP_COORD_GROUP_NAME} - JB3D Managed v{WRAP_COORD_GROUP_SCHEMA}"
    )
    group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group["jb3d_wrap_schema"] = WRAP_COORD_GROUP_SCHEMA
    group[GROUP_OWNER_KEY] = GROUP_OWNER_WRAP
    group.use_fake_user = True
    try:
        group.description = (
            "Maps normalized 360-degree wrap UVs to a movable physical artwork rectangle. "
            "Artwork width and height can be resized independently or kept at the image aspect ratio."
        )
    except Exception:
        pass

    _new_interface_socket(group, "Wrap UV", 'INPUT', 'NodeSocketVector', (0.0, 0.0, 0.0))
    _new_interface_socket(group, "Horizontal Offset", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Vertical Offset", 'INPUT', 'NodeSocketFloat', 0.0)
    _new_interface_socket(group, "Surface Circumference", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Surface Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Artwork Width", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Artwork Height", 'INPUT', 'NodeSocketFloat', 1.0)
    _new_interface_socket(group, "Image Coordinates", 'OUTPUT', 'NodeSocketVector')

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.name = "JB3D_WRAP_INPUT"
    group_input.label = "Wrap Controls"
    group_input.location = (-1180, 0)

    group_output = nodes.new("NodeGroupOutput")
    group_output.name = "JB3D_WRAP_OUTPUT"
    group_output.label = "Artwork Coordinates"
    group_output.location = (760, 60)

    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.name = "JB3D_WRAP_SEPARATE"
    separate.label = "Separate Wrap UV"
    separate.location = (-980, 120)

    # Horizontal: keep the seam periodic, center the artwork on the front,
    # convert normalized wrap distance to physical distance, then divide by
    # the requested artwork width. Width == circumference reproduces V1.1.
    subtract_u = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_SUB_U", -780, 260)
    fract_u = _new_math(nodes, 'FRACT', "JB3D_WRAP_FRACT_U", -580, 260)
    center_u = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_CENTER_U", -380, 260)
    center_u.inputs[1].default_value = 0.5
    physical_u = _new_math(nodes, 'MULTIPLY', "JB3D_WRAP_PHYSICAL_U", -180, 260)
    divide_u = _new_math(nodes, 'DIVIDE', "JB3D_WRAP_DIV_U", 20, 260)
    image_u = _new_math(nodes, 'ADD', "JB3D_WRAP_IMAGE_U", 220, 260)
    image_u.inputs[1].default_value = 0.5

    # Vertical: the normalized band is centered at 0.5. Convert it to physical
    # height around the center, apply the controller offset and artwork height.
    subtract_v_offset = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_SUB_V_OFFSET", -780, -100)
    center_v = _new_math(nodes, 'SUBTRACT', "JB3D_WRAP_CENTER_V", -580, -100)
    center_v.inputs[1].default_value = 0.5
    physical_v = _new_math(nodes, 'MULTIPLY', "JB3D_WRAP_PHYSICAL_V", -380, -100)
    divide_v = _new_math(nodes, 'DIVIDE', "JB3D_WRAP_DIV_V", -180, -100)
    image_v = _new_math(nodes, 'ADD', "JB3D_WRAP_IMAGE_V", 20, -100)
    image_v.inputs[1].default_value = 0.5

    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.name = "JB3D_WRAP_COMBINE"
    combine.label = "Image Coordinates"
    combine.location = (500, 80)
    combine.inputs["Z"].default_value = 0.0

    links.new(group_input.outputs["Wrap UV"], separate.inputs["Vector"])

    links.new(separate.outputs["X"], subtract_u.inputs[0])
    links.new(group_input.outputs["Horizontal Offset"], subtract_u.inputs[1])
    links.new(subtract_u.outputs[0], fract_u.inputs[0])
    links.new(fract_u.outputs[0], center_u.inputs[0])
    links.new(center_u.outputs[0], physical_u.inputs[0])
    links.new(group_input.outputs["Surface Circumference"], physical_u.inputs[1])
    links.new(physical_u.outputs[0], divide_u.inputs[0])
    links.new(group_input.outputs["Artwork Width"], divide_u.inputs[1])
    links.new(divide_u.outputs[0], image_u.inputs[0])

    links.new(separate.outputs["Y"], subtract_v_offset.inputs[0])
    links.new(group_input.outputs["Vertical Offset"], subtract_v_offset.inputs[1])
    links.new(subtract_v_offset.outputs[0], center_v.inputs[0])
    links.new(center_v.outputs[0], physical_v.inputs[0])
    links.new(group_input.outputs["Surface Height"], physical_v.inputs[1])
    links.new(physical_v.outputs[0], divide_v.inputs[0])
    links.new(group_input.outputs["Artwork Height"], divide_v.inputs[1])
    links.new(divide_v.outputs[0], image_v.inputs[0])

    links.new(image_u.outputs[0], combine.inputs["X"])
    links.new(image_v.outputs[0], combine.inputs["Y"])
    links.new(combine.outputs["Vector"], group_output.inputs["Image Coordinates"])
    return group


def _configure_wrap_coordinate_drivers(
    coordinate_node: bpy.types.ShaderNodeGroup,
    controller: bpy.types.Object,
    circumference: float,
    height: float,
) -> None:
    circumference = max(float(circumference), 1e-8)
    height = max(float(height), 1e-8)
    coordinate_node.inputs["Surface Circumference"].default_value = circumference
    coordinate_node.inputs["Surface Height"].default_value = height
    add_transform_driver(
        coordinate_node.inputs["Horizontal Offset"], controller, 'LOC_X',
        f"v / {circumference:.17g}",
    )
    add_transform_driver(
        coordinate_node.inputs["Vertical Offset"], controller, 'LOC_Y',
        f"v / {height:.17g}",
    )
    add_transform_driver(
        coordinate_node.inputs["Artwork Width"], controller, 'SCALE_X',
        "abs(v) * 2.0 + 1e-8",
    )
    add_transform_driver(
        coordinate_node.inputs["Artwork Height"], controller, 'SCALE_Y',
        "abs(v) * 2.0 + 1e-8",
    )


def _configure_coordinate_drivers(
    coordinate_node: bpy.types.ShaderNodeGroup,
    controller: bpy.types.Object,
) -> None:
    add_transform_driver(coordinate_node.inputs["Center U"], controller, 'LOC_X')
    add_transform_driver(coordinate_node.inputs["Center V"], controller, 'LOC_Y')
    add_transform_driver(coordinate_node.inputs["Rotation"], controller, 'ROT_Z')
    add_transform_driver(
        coordinate_node.inputs["Width"],
        controller,
        'SCALE_X',
        "abs(v) * 2.0 + 1e-8",
    )
    add_transform_driver(
        coordinate_node.inputs["Height"],
        controller,
        'SCALE_Y',
        "abs(v) * 2.0 + 1e-8",
    )


COLOR_MIX_NODE_NAME = f"{NODE_PREFIX}COLOR_MIX"
OPACITY_NODE_NAME = f"{NODE_PREFIX}OPACITY"
MATERIAL_OWNER_KEY = "jb3d_labeler_material"


def _available_socket(sockets, name: str, socket_type: str):
    candidates = [
        socket for socket in sockets
        if socket.name == name and getattr(socket, "type", "") == socket_type
    ]
    for socket in candidates:
        if not getattr(socket, "is_unavailable", False):
            return socket
    return candidates[-1] if candidates else None


def _mix_color_sockets(node):
    factor = _available_socket(node.inputs, "Factor", 'VALUE')
    color_a = _available_socket(node.inputs, "A", 'RGBA')
    color_b = _available_socket(node.inputs, "B", 'RGBA')
    result = _available_socket(node.outputs, "Result", 'RGBA')

    # Stable fallbacks used by ShaderNodeMix in Blender 4.x/5.x.
    factor = factor or (node.inputs[0] if len(node.inputs) > 0 else None)
    color_a = color_a or (node.inputs[6] if len(node.inputs) > 6 else None)
    color_b = color_b or (node.inputs[7] if len(node.inputs) > 7 else None)
    result = result or (node.outputs[2] if len(node.outputs) > 2 else node.outputs[0])
    return factor, color_a, color_b, result


def _configure_mix_color(node, blend_mode: str) -> None:
    node.data_type = 'RGBA'
    try:
        node.blend_type = blend_mode
    except (TypeError, ValueError):
        node.blend_type = 'MIX'
    if hasattr(node, "clamp_factor"):
        node.clamp_factor = True

    factor, color_a, _color_b, _result = _mix_color_sockets(node)
    if factor is not None:
        factor.default_value = 1.0
    if color_a is not None:
        color_a.default_value = (1.0, 1.0, 1.0, 1.0)


def _new_mix_node(nodes, name: str, label: str, blend_mode: str, location: tuple[float, float]):
    node = nodes.new("ShaderNodeMix")
    node.name = name
    node.label = label
    node.location = location
    node.width = 180
    _configure_mix_color(node, blend_mode)
    return node


def _attribute_vector_node(nodes, name: str, attribute_name: str, location: tuple[float, float]):
    node = nodes.new("ShaderNodeAttribute")
    node.name = name
    node.label = "Transferred Label Coordinates"
    node.location = location
    node.attribute_name = attribute_name
    if hasattr(node, "attribute_type"):
        try:
            node.attribute_type = 'GEOMETRY'
        except (TypeError, ValueError):
            pass
    return node


def _attribute_factor_node(nodes, name: str, attribute_name: str, location: tuple[float, float]):
    node = nodes.new("ShaderNodeAttribute")
    node.name = name
    node.label = "Overlap Mask"
    node.location = location
    node.attribute_name = attribute_name
    if hasattr(node, "attribute_type"):
        try:
            node.attribute_type = 'GEOMETRY'
        except (TypeError, ValueError):
            pass
    return node


def _attribute_factor_output(node):
    socket = node.outputs.get("Fac")
    if socket is None:
        socket = node.outputs.get("Factor")
    if socket is None and len(node.outputs) > 2:
        socket = node.outputs[2]
    if socket is None:
        raise RuntimeError("Attribute node has no factor output")
    return socket


def _create_coordinate_node(
    nodes,
    label: bpy.types.Object,
    controller: bpy.types.Object,
    *,
    name: str,
    location: tuple[float, float],
):
    coordinate_node = nodes.new("ShaderNodeGroup")
    is_wrap = label.jb3d_labeler.label_type == 'WRAP_360'
    if is_wrap:
        coordinate_node.name = name
        coordinate_node.label = "360° Artwork Placement & Size"
        coordinate_node.node_tree = ensure_wrap_coordinate_group()
        _configure_wrap_coordinate_drivers(
            coordinate_node,
            controller,
            label.jb3d_labeler.wrap_circumference,
            label.jb3d_labeler.wrap_height,
        )
        input_name = "Wrap UV"
    else:
        coordinate_node.name = name
        coordinate_node.label = "Placement and Size"
        coordinate_node.node_tree = ensure_coordinate_group()
        _configure_coordinate_drivers(coordinate_node, controller)
        input_name = "Metric UV"
    coordinate_node.location = location
    coordinate_node.width = 220
    return coordinate_node, input_name


def _create_image_node(nodes, name: str, image: bpy.types.Image, location: tuple[float, float]):
    image_node = nodes.new("ShaderNodeTexImage")
    image_node.name = name
    image_node.label = "LABEL IMAGE"
    image_node.location = location
    image_node.image = image
    image_node.extension = 'CLIP'
    image_node.interpolation = 'Linear'
    return image_node


def _add_property_driver(socket, owner: bpy.types.Object, data_path: str, *, expression: str = "v") -> None:
    """Drive a node scalar from a JB3D object property."""
    try:
        socket.driver_remove("default_value")
    except (TypeError, RuntimeError):
        pass
    fcurve = socket.driver_add("default_value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = expression
    variable = driver.variables.new()
    variable.name = "v"
    variable.type = 'SINGLE_PROP'
    target = variable.targets[0]
    target.id = owner
    target.data_path = data_path


def _add_layer_strength_driver(socket, label: bpy.types.Object) -> None:
    """Drive lower-layer contribution from its Opacity and Visible properties."""
    try:
        socket.driver_remove("default_value")
    except (TypeError, RuntimeError):
        pass
    fcurve = socket.driver_add("default_value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = "opacity * visible"
    opacity = driver.variables.new()
    opacity.name = "opacity"
    opacity.type = 'SINGLE_PROP'
    opacity.targets[0].id = label
    opacity.targets[0].data_path = "jb3d_labeler.opacity"
    visible = driver.variables.new()
    visible.name = "visible"
    visible.type = 'SINGLE_PROP'
    visible.targets[0].id = label
    visible.targets[0].data_path = "jb3d_labeler.visible"

# V2 renders labels inside the source product material. The legacy standalone
# label-surface material builder was intentionally removed; this module now owns
# only shared coordinate transforms and small shader-node construction helpers.
