# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import math
import os

import bpy
import bmesh
from bpy.props import EnumProperty
from bpy.types import Operator

from . import registry, wrap
from .utils import (
    build_metric_uv,
    copy_selected_faces,
    current_view_right,
    ensure_collection,
    ensure_rig_parenting,
    label_fit_report,
    load_image,
    migrate_legacy_label,
    reference_from_label,
    remove_object_and_data,
    resolve_rig_from_object,
    select_only,
    selected_face_island_count,
    store_uv_analysis,
    unique_label_name,
    create_controller_rig,
)


def _resolved_image(path: str, existing: bpy.types.Image | None, pack: bool) -> bpy.types.Image:
    if path:
        absolute = bpy.path.abspath(path)
        if os.path.isfile(absolute):
            return load_image(path, pack)
        if existing is None:
            raise FileNotFoundError("Image file not found.")
    if existing is None:
        raise FileNotFoundError("No image is associated with this label.")
    if pack and not existing.packed_file:
        existing.pack()
    return existing


def _apply_ratio(
    width: float,
    height: float,
    preserve_ratio: bool,
    image: bpy.types.Image,
    reference_axis: str = 'WIDTH',
) -> tuple[float, float]:
    if preserve_ratio and image.size[0] > 0 and image.size[1] > 0:
        ratio = image.size[0] / image.size[1]
        if reference_axis == 'HEIGHT':
            width = height * ratio
        else:
            height = width / ratio
    return max(width, 1e-6), max(height, 1e-6)


def _wrap_artwork_size(
    width: float,
    height: float,
    preserve_ratio: bool,
    image: bpy.types.Image,
    circumference: float,
    reference_axis: str = 'WIDTH',
) -> tuple[float, float]:
    """Resolve a physical artwork rectangle for a wrap without overlapping itself."""
    width, height = _apply_ratio(width, height, preserve_ratio, image, reference_axis)
    circumference = max(float(circumference), 1e-6)
    if width > circumference:
        width = circumference
        if preserve_ratio and image.size[0] > 0 and image.size[1] > 0:
            height = width / (image.size[0] / image.size[1])
    return max(width, 1e-6), max(height, 1e-6)


def _configure_wrap_controller(
    controller: bpy.types.Object,
    width: float,
    height: float,
) -> None:
    """Make the wrap controller directly usable for live move/scale transforms."""
    controller.empty_display_type = 'CUBE'
    controller.empty_display_size = 1.0
    controller.scale.x = max(width * 0.5, 1e-6)
    controller.scale.y = max(height * 0.5, 1e-6)
    controller.scale.z = max(min(width, height) * 0.01, 1e-6)
    controller.lock_scale = (False, False, True)
    controller.lock_rotation = (True, True, True)


def _wrap_size_from_controller(data, controller: bpy.types.Object) -> tuple[float, float, str]:
    """Read viewport scaling and infer which dimension the user changed most."""
    width = max(abs(float(controller.scale.x)) * 2.0, 1e-6)
    height = max(abs(float(controller.scale.y)) * 2.0, 1e-6)
    stored_width = max(float(data.width), 1e-6)
    stored_height = max(float(data.height), 1e-6)
    width_change = abs(width / stored_width - 1.0)
    height_change = abs(height / stored_height - 1.0)
    if max(width_change, height_change) <= 1e-5:
        axis = data.last_edited_dimension
    else:
        axis = 'WIDTH' if width_change >= height_change else 'HEIGHT'
    return width, height, axis


class JB3D_LABELER_OT_create_from_selection(Operator):
    bl_idname = "jb3d_labeler.create_from_selection"
    bl_label = "Create Label from Selection"
    bl_description = "Create a standard or 360° wrap label from the selected faces"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        source = context.active_object
        settings = context.scene.jb3d_labeler

        try:
            image = load_image(settings.image_path, settings.pack_image)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(source.data)
        selected_faces = [face for face in bm.faces if face.select]
        if not selected_faces:
            self.report({'ERROR'}, "Select at least one face in Edit Mode.")
            return {'CANCELLED'}
        if selected_face_island_count(bm) != 1:
            self.report({'ERROR'}, "The selection must form one connected region.")
            return {'CANCELLED'}

        is_wrap = settings.label_type == 'WRAP_360'
        if not is_wrap:
            width, height = _apply_ratio(
                settings.width, settings.height, settings.preserve_ratio, image,
                settings.last_edited_dimension,
            )
            settings.ratio_update_lock = True
            try:
                settings.image = image
                settings.image_pixel_width = int(image.size[0])
                settings.image_pixel_height = int(image.size[1])
                settings.width = width
                settings.height = height
            finally:
                settings.ratio_update_lock = False
        else:
            width = height = 0.001
            settings.image = image
            settings.image_pixel_width = int(image.size[0])
            settings.image_pixel_height = int(image.size[1])

        collection = ensure_collection(context)
        label_name = unique_label_name()
        label = anchor = controller = None

        try:
            label, reference = copy_selected_faces(
                source, collection, label_name, current_view_right(context),
            )
            bpy.ops.object.mode_set(mode='OBJECT')

            wrap_result = None
            if is_wrap:
                wrap_result = wrap.build_wrap_uv(
                    label, reference, settings.wrap_seam_mode, settings.wrap_axis,
                )
                width = wrap_result.measurements.circumference
                height = wrap_result.measurements.height
                if settings.preserve_ratio:
                    width, height = _wrap_artwork_size(
                        width, height, True, image,
                        wrap_result.measurements.circumference, 'WIDTH',
                    )
                used_method = 'WRAP_360'
            else:
                used_method = build_metric_uv(
                    context, label, settings.unwrap_method,
                    settings.orientation_mode, reference,
                )

            # V2 labels render directly in the product material. The mapping
            # carrier already contains the copied source faces, so no physical
            # Shrinkwrap/Subdivision stack is required during creation.
            frame_offset = 0.0

            anchor, controller = create_controller_rig(
                collection=collection, label=label, source=source, image=image,
                image_path=image.filepath or settings.image_path,
                width=width, height=height,
                preserve_ratio=settings.preserve_ratio,
                surface_offset=0.0,
                follow_surface=False,
                unwrap_method=settings.unwrap_method,
                orientation_mode=settings.orientation_mode,
                roughness=settings.roughness, metallic=settings.metallic,
                pack_image=settings.pack_image, reference=reference,
                frame_offset=frame_offset, label_type=settings.label_type,
                wrap_seam_mode=settings.wrap_seam_mode, wrap_axis=settings.wrap_axis,
                anchor_target_uv=wrap_result.anchor_uv if wrap_result else None,
            )
            data = label.jb3d_labeler
            data.last_unwrap_used = used_method

            if wrap_result is not None:
                wrap.store_wrap_result(label, wrap_result)
                data.ratio_update_lock = True
                try:
                    data.width = width
                    data.height = height
                    data.preserve_ratio = settings.preserve_ratio
                finally:
                    data.ratio_update_lock = False
                _configure_wrap_controller(controller, width, height)
                data.distortion_rms = data.distortion_u = data.distortion_v = 0.0
                data.available_width = data.wrap_circumference
                data.available_height = data.wrap_height
                analysis = None
            else:
                analysis = store_uv_analysis(label)

            label.show_in_front = False
            label.display_type = 'TEXTURED'
            registry.register_label(context.scene, label, at_top=True)
            registry.apply_stack_order(context, context.scene, source)
            select_only(context, controller)

            if wrap_result is not None:
                messages = [
                    f"360° wrap created — circumference {wrap_result.measurements.circumference:.4g}, "
                    f"height {wrap_result.measurements.height:.4g}."
                ]
                ratio_warning = wrap.image_ratio_warning(data, image)
                if wrap_result.measurements.taper_percentage > 5.0:
                    messages.append(
                        f"The surface is tapered ({wrap_result.measurements.taper_percentage:.1f}% difference)."
                    )
                if ratio_warning:
                    messages.append(ratio_warning)
                fit_warning = wrap.artwork_fit_warning(data, controller)
                if fit_warning:
                    messages.append(fit_warning)
                self.report({'WARNING'} if len(messages) > 1 else {'INFO'}, " ".join(messages))
            else:
                fit = label_fit_report(resolve_rig_from_object(controller))
                fit_text = "valid size" if fit.fits else "exceeds the selected area"
                self.report(
                    {'INFO'},
                    f"Label created ({used_method}) — distortion {analysis.rms:.1f}%, {fit_text}.",
                )
            return {'FINISHED'}

        except Exception as exc:
            for obj in (controller, anchor, label):
                remove_object_and_data(obj)
            if source and source.name in bpy.data.objects:
                select_only(context, source)
            self.report({'ERROR'}, f"Cannot create label: {exc}")
            return {'CANCELLED'}


class JB3D_LABELER_OT_update_active(Operator):
    bl_idname = "jb3d_labeler.update_active"
    bl_label = "Update Label"
    bl_description = "Update the image, mapping and product material stack"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None

    def execute(self, context):
        original_active = context.active_object
        rig = registry.active_rig(context)
        if rig is None or rig.controller is None:
            self.report({'ERROR'}, "Incomplete label rig.")
            return {'CANCELLED'}

        ensure_rig_parenting(rig)
        data = rig.label.jb3d_labeler
        try:
            image = _resolved_image(data.image_path, data.image, data.pack_image)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        data.ratio_update_lock = True
        try:
            data.image = image
            data.image_pixel_width = int(image.size[0])
            data.image_pixel_height = int(image.size[1])
            if image.filepath:
                data.image_path = image.filepath
        finally:
            data.ratio_update_lock = False
        if data.pack_image and getattr(data, "mask_image", None) is not None and not data.mask_image.packed_file:
            try:
                data.mask_image.pack()
            except RuntimeError:
                pass

        uv_rebuilt = False
        used_method = data.last_unwrap_used
        if data.label_type == 'WRAP_360':
            if (
                data.wrap_seam_mode != data.applied_wrap_seam_mode
                or data.wrap_axis != data.applied_wrap_axis
            ):
                reference = reference_from_label(rig.label, current_view_right(context))
                result = wrap.build_wrap_uv(
                    rig.label, reference, data.wrap_seam_mode, data.wrap_axis,
                )
                wrap.store_wrap_result(rig.label, result)
                data.applied_wrap_seam_mode = data.wrap_seam_mode
                data.applied_wrap_axis = data.wrap_axis
                data.last_unwrap_used = 'WRAP_360'
                used_method = 'WRAP_360'
                uv_rebuilt = True

            controller_width, controller_height, edited_axis = _wrap_size_from_controller(data, rig.controller)
            width, height = _wrap_artwork_size(
                controller_width, controller_height, data.preserve_ratio, image,
                data.wrap_circumference, edited_axis,
            )
            data.last_edited_dimension = edited_axis
            data.ratio_update_lock = True
            try:
                data.width = width
                data.height = height
            finally:
                data.ratio_update_lock = False
            data.available_width = data.wrap_circumference
            data.available_height = data.wrap_height
            _configure_wrap_controller(rig.controller, width, height)
        else:
            width, height = _apply_ratio(
                data.width, data.height, data.preserve_ratio, image,
                data.last_edited_dimension,
            )
            data.ratio_update_lock = True
            try:
                data.width = width
                data.height = height
            finally:
                data.ratio_update_lock = False
            rig.controller.scale.x = width * 0.5
            rig.controller.scale.y = height * 0.5
            if (
                data.unwrap_method != data.applied_unwrap_method
                or data.orientation_mode != data.applied_orientation_mode
            ):
                reference = reference_from_label(rig.label, current_view_right(context))
                used_method = build_metric_uv(
                    context, rig.label, data.unwrap_method,
                    data.orientation_mode, reference,
                )
                data.last_unwrap_used = used_method
                data.applied_unwrap_method = data.unwrap_method
                data.applied_orientation_mode = data.orientation_mode
                uv_rebuilt = True
            store_uv_analysis(rig.label)

        rig.controller["jb3d_image_name"] = image.name
        rig.label["jb3d_image_name"] = image.name
        rig.label["jb3d_original_width"] = data.width
        rig.label["jb3d_original_height"] = data.height

        registry.apply_stack_order(context, context.scene, rig.source)

        if original_active and original_active.name in bpy.data.objects:
            select_only(context, original_active)

        if data.label_type == 'WRAP_360':
            message = "360° wrap updated" + (" — UVs rebuilt" if uv_rebuilt else "")
            warning = wrap.image_ratio_warning(data, image)
            fit_warning = wrap.artwork_fit_warning(data, rig.controller)
            if fit_warning:
                warning = (warning + " " if warning else "") + fit_warning
            if data.taper_percentage > 5.0:
                warning = (warning + " " if warning else "") + (
                    f"The surface is tapered ({data.taper_percentage:.1f}% difference)."
                )
            self.report({'WARNING'} if warning else {'INFO'}, f"{message}. {warning or ''}".strip())
        else:
            fit = label_fit_report(rig)
            uv_text = f" — UV rebuilt with {used_method}" if uv_rebuilt else ""
            if fit.fits:
                self.report({'INFO'}, f"Label updated{uv_text} — it fits the selected area.")
            else:
                self.report({'WARNING'}, f"Label updated{uv_text}, but it exceeds the selected area.")
        return {'FINISHED'}


class JB3D_LABELER_OT_rebuild_uv(Operator):
    bl_idname = "jb3d_labeler.rebuild_uv"
    bl_label = "Rebuild UVs"
    bl_description = "Rebuild the unwrap using the stored active face and edge"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.label.type == 'MESH'

    def execute(self, context):
        original_active = context.active_object
        rig = registry.active_rig(context)
        ensure_rig_parenting(rig)
        data = rig.label.jb3d_labeler
        reference = reference_from_label(rig.label, current_view_right(context))

        try:
            if data.label_type == 'WRAP_360':
                result = wrap.build_wrap_uv(
                    rig.label, reference, data.wrap_seam_mode, data.wrap_axis,
                )
                wrap.store_wrap_result(rig.label, result)
                data.applied_wrap_seam_mode = data.wrap_seam_mode
                data.applied_wrap_axis = data.wrap_axis
                data.last_unwrap_used = 'WRAP_360'
                image = data.image
                if rig.controller is not None:
                    candidate_width, candidate_height, edited_axis = _wrap_size_from_controller(data, rig.controller)
                else:
                    candidate_width, candidate_height, edited_axis = data.width, data.height, data.last_edited_dimension
                if image is not None:
                    width, height = _wrap_artwork_size(
                        candidate_width, candidate_height, data.preserve_ratio, image,
                        data.wrap_circumference, edited_axis,
                    )
                else:
                    width = min(max(candidate_width, 1e-6), max(data.wrap_circumference, 1e-6))
                    height = max(candidate_height, 1e-6)
                data.last_edited_dimension = edited_axis
                data.ratio_update_lock = True
                try:
                    data.width = width
                    data.height = height
                finally:
                    data.ratio_update_lock = False
                data.available_width = data.wrap_circumference
                data.available_height = data.wrap_height
                if rig.controller:
                    _configure_wrap_controller(rig.controller, width, height)
                message = (
                    f"360° UVs rebuilt — circumference {data.wrap_circumference:.4g}, "
                    f"height {data.wrap_height:.4g}."
                )
            else:
                used_method = build_metric_uv(
                    context, rig.label, data.unwrap_method,
                    data.orientation_mode, reference,
                )
                data.last_unwrap_used = used_method
                data.applied_unwrap_method = data.unwrap_method
                data.applied_orientation_mode = data.orientation_mode
                if rig.controller:
                    rig.controller.location.x = 0.0
                    rig.controller.location.y = 0.0
                    rig.controller.rotation_euler.z = 0.0
                    rig.controller.scale.x = data.width * 0.5
                    rig.controller.scale.y = data.height * 0.5
                analysis = store_uv_analysis(rig.label)
                message = f"UVs rebuilt with {used_method} — distortion {analysis.rms:.1f}%."
            registry.apply_stack_order(context, context.scene, rig.source)
        except Exception as exc:
            self.report({'ERROR'}, f"Cannot rebuild UVs: {exc}")
            return {'CANCELLED'}

        if original_active and original_active.name in bpy.data.objects:
            select_only(context, original_active)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_controller(Operator):
    bl_idname = "jb3d_labeler.select_controller"
    bl_label = "Select Controller"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.controller is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        data = rig.label.jb3d_labeler
        data.controller_visible = True
        rig.controller.hide_viewport = False
        select_only(context, rig.controller)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_label(Operator):
    bl_idname = "jb3d_labeler.select_label"
    bl_label = "Select Surface"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        data = rig.label.jb3d_labeler
        data.debug_show_surface = True
        rig.label.hide_viewport = False
        rig.label.hide_select = False
        select_only(context, rig.label)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_anchor(Operator):
    bl_idname = "jb3d_labeler.select_anchor"
    bl_label = "Select Anchor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.anchor is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        if rig.label.jb3d_labeler.anchor_locked:
            self.report({'WARNING'}, "This anchor is locked.")
            return {'CANCELLED'}
        select_only(context, rig.anchor)
        return {'FINISHED'}


class JB3D_LABELER_OT_select_source(Operator):
    bl_idname = "jb3d_labeler.select_source"
    bl_label = "Select Product"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.source is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        select_only(context, rig.source)
        return {'FINISHED'}


class JB3D_LABELER_OT_fit_wrap_artwork(Operator):
    bl_idname = "jb3d_labeler.fit_wrap_artwork"
    bl_label = "Fit Wrap Artwork"
    bl_description = "Fit the wrap artwork to the full circumference or the selected band height"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        name="Fit Mode",
        items=(
            ('FULL_WIDTH', "Full 360° Width", "Use the complete circumference as artwork width"),
            ('BAND_HEIGHT', "Fit Band Height", "Use the selected face-band height as artwork height"),
        ),
        default='FULL_WIDTH',
    )

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return (
            rig is not None
            and rig.controller is not None
            and rig.label.jb3d_labeler.label_type == 'WRAP_360'
        )

    def execute(self, context):
        rig = registry.active_rig(context)
        data = rig.label.jb3d_labeler
        image = data.image
        if image is None:
            self.report({'ERROR'}, "No image is associated with this wrap label.")
            return {'CANCELLED'}

        width = max(float(data.width), 1e-6)
        height = max(float(data.height), 1e-6)
        if self.mode == 'BAND_HEIGHT':
            height = max(float(data.wrap_height), 1e-6)
            axis = 'HEIGHT'
        else:
            width = max(float(data.wrap_circumference), 1e-6)
            axis = 'WIDTH'

        width, height = _wrap_artwork_size(
            width, height, data.preserve_ratio, image,
            data.wrap_circumference, axis,
        )
        data.ratio_update_lock = True
        try:
            data.width = width
            data.height = height
            data.last_edited_dimension = axis
        finally:
            data.ratio_update_lock = False
        _configure_wrap_controller(rig.controller, width, height)
        rig.label["jb3d_original_width"] = width
        rig.label["jb3d_original_height"] = height

        warning = wrap.artwork_fit_warning(data, rig.controller) or wrap.image_ratio_warning(data, image)
        self.report(
            {'WARNING'} if warning else {'INFO'},
            warning or "Wrap artwork fitted.",
        )
        return {'FINISHED'}


class JB3D_LABELER_OT_rotate_90(Operator):
    bl_idname = "jb3d_labeler.rotate_90"
    bl_label = "Rotate 90°"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.controller is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        if rig.label.jb3d_labeler.label_type == 'WRAP_360':
            self.report({'WARNING'}, "360° artwork rotation is not supported. Use horizontal offset instead.")
            return {'CANCELLED'}
        rig.controller.rotation_euler.z += math.radians(90.0)
        return {'FINISHED'}


class JB3D_LABELER_OT_reset_controller(Operator):
    bl_idname = "jb3d_labeler.reset_controller"
    bl_label = "Recenter"
    bl_description = "Move the label back to the stored active face"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        rig = registry.active_rig(context)
        return rig is not None and rig.controller is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        rig.controller.location.x = 0.0
        rig.controller.location.y = 0.0
        rig.controller.rotation_euler.z = 0.0
        return {'FINISHED'}


class JB3D_LABELER_OT_repair_links(Operator):
    bl_idname = "jb3d_labeler.repair_links"
    bl_label = "Repair Links"
    bl_description = "Migrate legacy rigs, restore pointers and repair product parenting"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None or context.active_object is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        obj = context.active_object
        if rig is None and obj is not None:
            if obj.get("jb3d_labeler_role") == "LABEL":
                migrate_legacy_label(obj)
            else:
                candidate = resolve_rig_from_object(obj)
                if candidate:
                    migrate_legacy_label(candidate.label)
            rig = resolve_rig_from_object(obj)
        if rig is None:
            self.report({'ERROR'}, "No JB3D Labeler rig detected on this object.")
            return {'CANCELLED'}
        ensure_rig_parenting(rig)
        registry.register_label(context.scene, rig.label, at_top=False)
        registry.apply_stack_order(context, context.scene, rig.source)
        self.report({'INFO'}, "Rig links, parenting and product material integration verified.")
        return {'FINISHED'}


class JB3D_LABELER_OT_rebuild_compositing(Operator):
    bl_idname = "jb3d_labeler.rebuild_compositing"
    bl_label = "Rebuild Material Stack"
    bl_description = "Rebuild the non-destructive JB3D material-decal stack on the active product"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.active_rig(context) is not None

    def execute(self, context):
        rig = registry.active_rig(context)
        if rig is None:
            return {'CANCELLED'}
        try:
            from . import compositor
            count = compositor.rebuild_source_stack(rig.source, context.scene)
        except Exception as exc:
            self.report({'ERROR'}, f"Layer compositing rebuild failed: {exc}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Material stack rebuilt for {count} label(s).")
        return {'FINISHED'}


class JB3D_LABELER_OT_move_layer(Operator):
    bl_idname = "jb3d_labeler.move_layer"
    bl_label = "Change Stack Order"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(
        items=(
            ('UP', "Move Up", "Place the label above"),
            ('DOWN', "Move Down", "Place the label below"),
        ),
        default='UP',
    )

    @classmethod
    def poll(cls, context):
        source = registry.active_product(context)
        return (
            source is not None
            and hasattr(source, "jb3d_label_items")
            and len(source.jb3d_label_items) > 1
            and context.mode == 'OBJECT'
        )

    def execute(self, context):
        if not registry.move_active_item(context, self.direction):
            return {'CANCELLED'}
        return {'FINISHED'}


class JB3D_LABELER_OT_refresh_list(Operator):
    bl_idname = "jb3d_labeler.refresh_list"
    bl_label = "Refresh List"
    bl_description = "Find labels in the scene and repair their order"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source = registry.active_product(context)
        if source is None:
            self.report({'INFO'}, "Select a product to refresh its labels.")
            return {'CANCELLED'}
        registry.sync_product_label_list(source, context.scene, defer_rebuild=False)
        registry.apply_stack_order(context, context.scene, source)
        self.report({'INFO'}, f"Label list refreshed for {source.name}.")
        return {'FINISHED'}


class JB3D_LABELER_OT_delete_rig(Operator):
    bl_idname = "jb3d_labeler.delete_rig"
    bl_label = "Delete Label"
    bl_description = "Delete the selected label or clean a stale label entry"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return registry.has_active_label_item(context) or registry.active_rig(context) is not None

    def execute(self, context):
        source = registry.active_product(context)
        if source is None:
            rig = registry.active_rig(context)
            source = rig.source if rig is not None else None
        if source is None:
            return {'CANCELLED'}

        # Remove the product-owned UI row first. This function is deliberately
        # safe when Blender has already invalidated/deleted the mapping object.
        label, stale_uuid = registry.remove_active_item(source)
        rig = resolve_rig_from_object(label) if label is not None else None

        if rig is not None:
            legacy_materials = list(rig.label.data.materials) if rig.label and rig.label.type == 'MESH' else []
            remove_object_and_data(rig.controller)
            remove_object_and_data(rig.anchor)
            remove_object_and_data(rig.label)
            for material in legacy_materials:
                if material is not None and material.users == 0 and material.get("jb3d_labeler_material"):
                    try:
                        bpy.data.materials.remove(material)
                    except (RuntimeError, TypeError):
                        pass

        # Reconcile against live objects in case a mapping surface/controller was
        # manually removed in the Viewport or Outliner before this operator ran.
        registry.sync_product_label_list(source, context.scene, defer_rebuild=False)
        try:
            from . import compositor
            if source.jb3d_label_items:
                registry.apply_stack_order(context, context.scene, source)
            else:
                compositor.rebuild_source_stack(source, context.scene)
        except Exception as exc:
            self.report({'WARNING'}, f"Label removed, but material cleanup needs a rebuild: {exc}")

        if source.name in bpy.data.objects:
            select_only(context, source)
        if rig is None and stale_uuid:
            self.report({'INFO'}, "Stale label entry cleaned and product material stack repaired.")
        return {'FINISHED'}



class JB3D_LABELER_OT_reset_mask_ramp(Operator):
    bl_idname = "jb3d_labeler.reset_mask_ramp"
    bl_label = "Reset Mask Ramp"
    bl_description = "Reset the active label mask ColorRamp to black at 0 and white at 1"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        label = registry.active_label(context)
        return label is not None and label.jb3d_labeler.mask_enabled

    def execute(self, context):
        from . import material_engine
        label = registry.active_label(context)
        if not material_engine.reset_mask_ramp(label):
            self.report({'ERROR'}, "Mask ColorRamp is unavailable. Rebuild the material stack first.")
            return {'CANCELLED'}
        try:
            node = material_engine.get_mask_ramp_node(label)
            if node is not None:
                node.id_data.update_tag()
        except Exception:
            pass
        return {'FINISHED'}


class JB3D_LABELER_OT_invert_mask_ramp(Operator):
    bl_idname = "jb3d_labeler.invert_mask_ramp"
    bl_label = "Invert Mask Ramp"
    bl_description = "Invert the colors of every stop in the active mask ColorRamp"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        label = registry.active_label(context)
        return label is not None and label.jb3d_labeler.mask_enabled

    def execute(self, context):
        from . import material_engine
        label = registry.active_label(context)
        if not material_engine.invert_mask_ramp(label):
            self.report({'ERROR'}, "Mask ColorRamp is unavailable. Rebuild the material stack first.")
            return {'CANCELLED'}
        try:
            node = material_engine.get_mask_ramp_node(label)
            if node is not None:
                node.id_data.update_tag()
        except Exception:
            pass
        return {'FINISHED'}


class JB3D_LABELER_OT_set_mask_preview(Operator):
    bl_idname = "jb3d_labeler.set_mask_preview"
    bl_label = "Set Mask Preview"
    bl_description = "Switch between the final product and the active label mask preview"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        items=(
            ('FINAL', "Final", "Show the final product material"),
            ('MASK', "Mask", "Show the active label mask in black and white"),
        ),
        default='FINAL',
    )

    @classmethod
    def poll(cls, context):
        label = registry.active_label(context)
        return label is not None and label.jb3d_labeler.mask_enabled

    def execute(self, context):
        source = registry.active_product(context)
        label = registry.active_label(context)
        if source is None or label is None:
            return {'CANCELLED'}
        target = self.mode == 'MASK'
        # Keep mask preview exclusive per product so the result is predictable.
        for item in source.jb3d_label_items:
            try:
                other = item.label
            except (ReferenceError, RuntimeError):
                continue
            if other is None or other == label:
                continue
            if other.jb3d_labeler.preview_mask:
                other.jb3d_labeler.preview_mask = False
        if bool(label.jb3d_labeler.preview_mask) != target:
            label.jb3d_labeler.preview_mask = target
        return {'FINISHED'}


_CLASSES = (
    JB3D_LABELER_OT_create_from_selection,
    JB3D_LABELER_OT_update_active,
    JB3D_LABELER_OT_rebuild_uv,
    JB3D_LABELER_OT_select_controller,
    JB3D_LABELER_OT_select_label,
    JB3D_LABELER_OT_select_anchor,
    JB3D_LABELER_OT_select_source,
    JB3D_LABELER_OT_fit_wrap_artwork,
    JB3D_LABELER_OT_rotate_90,
    JB3D_LABELER_OT_reset_controller,
    JB3D_LABELER_OT_repair_links,
    JB3D_LABELER_OT_rebuild_compositing,
    JB3D_LABELER_OT_move_layer,
    JB3D_LABELER_OT_refresh_list,
    JB3D_LABELER_OT_delete_rig,
    JB3D_LABELER_OT_reset_mask_ramp,
    JB3D_LABELER_OT_invert_mask_ramp,
    JB3D_LABELER_OT_set_mask_preview,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
