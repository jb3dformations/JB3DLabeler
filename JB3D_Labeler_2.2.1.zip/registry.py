# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent

from .utils import (
    ROLE_KEY,
    ROLE_LABEL,
    ensure_rig_parenting,
    migrate_legacy_label,
    resolve_rig_from_object,
)


_SYNC_GUARD = False
_INDEX_SELECTION_SUSPENDED = False
_DIRTY_SOURCE_UUIDS: set[str] = set()
_DIRTY_TIMER_REGISTERED = False
_SCENE_OBJECT_COUNTS: dict[int, int] = {}
_SCENE_SYNC_TIMER_REGISTERED = False
_SOURCE_MATERIAL_SIGNATURES: dict[str, tuple] = {}
_SOURCE_OBJECTS: dict[str, bpy.types.Object] = {}


def _safe_pointer(obj) -> int:
    try:
        return obj.as_pointer() if obj is not None else 0
    except (ReferenceError, RuntimeError, AttributeError):
        return 0


def _safe_item_label(item) -> bpy.types.Object | None:
    try:
        label = item.label
    except (ReferenceError, RuntimeError):
        return None
    return label if _safe_pointer(label) else None


def _safe_rig_uuid(label: bpy.types.Object | None) -> str:
    if label is None:
        return ""
    try:
        return str(label.jb3d_labeler.rig_uuid or "")
    except (ReferenceError, RuntimeError, AttributeError):
        return ""


def _safe_data_object(data, name: str) -> bpy.types.Object | None:
    try:
        value = getattr(data, name, None)
        return value if _safe_pointer(value) else None
    except (ReferenceError, RuntimeError, AttributeError):
        return None


def is_label_object(obj: bpy.types.Object | None) -> bool:
    if obj is None or not hasattr(obj, "jb3d_labeler"):
        return False
    try:
        data = obj.jb3d_labeler
        return data.role == ROLE_LABEL or obj.get(ROLE_KEY) == ROLE_LABEL
    except (ReferenceError, RuntimeError):
        return False


def labels_in_scene(scene: bpy.types.Scene) -> list[bpy.types.Object]:
    labels = []
    for obj in scene.objects:
        if not is_label_object(obj):
            continue
        migrate_legacy_label(obj)
        if obj.jb3d_labeler.role == ROLE_LABEL:
            labels.append(obj)
    return labels


def product_from_object(obj: bpy.types.Object | None) -> bpy.types.Object | None:
    """Resolve a JB3D rig part to its product; otherwise use the selected mesh.

    A plain selected mesh is intentionally a valid product context even when it
    does not have labels yet. This makes the sidebar follow normal Blender object
    selection instead of a scene-global label state.
    """
    if obj is None:
        return None
    rig = resolve_rig_from_object(obj, migrate=False)
    if rig is not None and rig.source is not None:
        return rig.source
    try:
        if obj.type == 'MESH':
            return obj
    except (ReferenceError, RuntimeError):
        pass
    return None


def active_product(context: bpy.types.Context) -> bpy.types.Object | None:
    return product_from_object(getattr(context, "active_object", None))


def _labels_for_product(source: bpy.types.Object, scene: bpy.types.Scene | None) -> list[bpy.types.Object]:
    if source is None:
        return []
    objects = scene.objects if scene is not None else bpy.data.objects
    labels = []
    for obj in objects:
        if not is_label_object(obj):
            continue
        try:
            migrate_legacy_label(obj)
            data = obj.jb3d_labeler
            if data.role == ROLE_LABEL and _safe_data_object(data, "source_object") == source:
                labels.append(obj)
        except (ReferenceError, RuntimeError):
            continue
    labels.sort(key=lambda item: (int(item.jb3d_labeler.stack_order), item.name.casefold()))
    return labels


def _source_uuid(source: bpy.types.Object | None) -> str:
    if source is None:
        return ""
    try:
        from . import material_engine
        return material_engine.source_uuid(source)
    except Exception:
        return ""


def _flush_dirty_sources():
    """Deferred material cleanup after external/manual label deletion.

    UI drawing only marks a product dirty. Rebuilding from a timer keeps draw()
    cheap and coalesces multiple Blender deletion/depsgraph events into one
    material-stack rebuild.
    """
    global _DIRTY_TIMER_REGISTERED
    uuids = set(_DIRTY_SOURCE_UUIDS)
    _DIRTY_SOURCE_UUIDS.clear()
    _DIRTY_TIMER_REGISTERED = False
    if not uuids:
        return None

    try:
        from . import compositor, material_engine
        for source in list(bpy.data.objects):
            try:
                token = str(source.get(material_engine.SOURCE_UUID_KEY, ""))
            except (ReferenceError, RuntimeError):
                continue
            if token not in uuids:
                continue
            users_scene = getattr(source, "users_scene", ())
            scene = users_scene[0] if users_scene else None
            try:
                compositor.rebuild_source_stack(source, scene)
                remember_material_state(source)
            except Exception:
                # A later explicit Refresh/Rebuild remains available. A failed
                # background cleanup must never break Blender interaction.
                pass
    except Exception:
        pass
    return None


def mark_product_dirty(source: bpy.types.Object | None) -> None:
    global _DIRTY_TIMER_REGISTERED
    token = _source_uuid(source)
    if not token:
        return
    _DIRTY_SOURCE_UUIDS.add(token)
    if _DIRTY_TIMER_REGISTERED:
        return
    try:
        bpy.app.timers.register(_flush_dirty_sources, first_interval=0.05)
        _DIRTY_TIMER_REGISTERED = True
    except Exception:
        _DIRTY_TIMER_REGISTERED = False


def _apply_saved_states(label: bpy.types.Object) -> None:
    data = label.jb3d_labeler
    try:
        label.hide_render = True
        label.hide_viewport = not bool(getattr(data, "debug_show_surface", False))
        label.hide_select = not bool(getattr(data, "debug_show_surface", False))
    except (AttributeError, RuntimeError):
        pass

    controller = _safe_data_object(data, "controller_object")
    if controller is not None:
        try:
            controller.hide_viewport = not bool(getattr(data, "controller_visible", True))
        except (AttributeError, RuntimeError):
            pass

    anchor = _safe_data_object(data, "anchor_object")
    if anchor is not None:
        try:
            anchor.hide_select = data.anchor_locked
        except (AttributeError, RuntimeError):
            pass


def sync_product_label_list(
    source: bpy.types.Object | None,
    scene: bpy.types.Scene | None = None,
    *,
    defer_rebuild: bool = True,
) -> bool:
    """Synchronize one product-owned UI list with its live label objects.

    Returns True when stale/duplicate entries were removed. Pointer access is
    guarded because Blender can invalidate a PointerProperty immediately when an
    internal mapping object is manually deleted in the Viewport or Outliner.
    """
    global _SYNC_GUARD
    if _SYNC_GUARD or source is None or not hasattr(source, "jb3d_label_items"):
        return False

    _SYNC_GUARD = True
    stale_removed = False
    try:
        valid_labels = _labels_for_product(source, scene)
        by_uuid: dict[str, bpy.types.Object] = {}
        by_pointer: dict[int, bpy.types.Object] = {}
        for label in valid_labels:
            pointer = _safe_pointer(label)
            rig_uuid = _safe_rig_uuid(label)
            if pointer:
                by_pointer[pointer] = label
            if rig_uuid and rig_uuid not in by_uuid:
                by_uuid[rig_uuid] = label

        seen_uuids: set[str] = set()
        seen_pointers: set[int] = set()
        for index in reversed(range(len(source.jb3d_label_items))):
            item = source.jb3d_label_items[index]
            label = _safe_item_label(item)
            pointer = _safe_pointer(label)
            rig_uuid = str(getattr(item, "rig_uuid", "") or "") or _safe_rig_uuid(label)
            replacement = by_uuid.get(rig_uuid) if rig_uuid else by_pointer.get(pointer)
            replacement_pointer = _safe_pointer(replacement)
            replacement_uuid = _safe_rig_uuid(replacement)
            duplicate = (
                (replacement_uuid and replacement_uuid in seen_uuids)
                or (replacement_pointer and replacement_pointer in seen_pointers)
            )
            if replacement is None or duplicate:
                source.jb3d_label_items.remove(index)
                stale_removed = True
                continue
            item.label = replacement
            item.rig_uuid = replacement_uuid
            if replacement_uuid:
                seen_uuids.add(replacement_uuid)
            if replacement_pointer:
                seen_pointers.add(replacement_pointer)

        missing = [
            label for label in valid_labels
            if _safe_rig_uuid(label) not in seen_uuids
            and _safe_pointer(label) not in seen_pointers
        ]
        missing.sort(key=lambda obj: (obj.jb3d_labeler.stack_order, obj.name.casefold()))
        for label in missing:
            item = source.jb3d_label_items.add()
            item.label = label
            item.rig_uuid = _safe_rig_uuid(label)

        for index, item in enumerate(source.jb3d_label_items):
            label = _safe_item_label(item)
            if label is None:
                continue
            if int(label.jb3d_labeler.stack_order) != index:
                label.jb3d_labeler.stack_order = index
            _apply_saved_states(label)

        if len(source.jb3d_label_items) == 0:
            target_index = 0
        else:
            target_index = min(
                max(int(source.jb3d_label_index), 0),
                len(source.jb3d_label_items) - 1,
            )
        if int(source.jb3d_label_index) != target_index:
            source.jb3d_label_index = target_index
    finally:
        _SYNC_GUARD = False

    if stale_removed and defer_rebuild:
        mark_product_dirty(source)
    return stale_removed


def sync_scene_products(scene: bpy.types.Scene | None, *, defer_rebuild: bool = True) -> None:
    if scene is None:
        return
    sources: dict[int, bpy.types.Object] = {}
    for label in labels_in_scene(scene):
        source = _safe_data_object(label.jb3d_labeler, "source_object")
        pointer = _safe_pointer(source)
        if pointer:
            sources[pointer] = source
    try:
        from . import material_engine
        for obj in scene.objects:
            if obj.type == 'MESH' and obj.get(material_engine.SOURCE_UUID_KEY):
                sources[_safe_pointer(obj)] = obj
    except Exception:
        pass
    for source in sources.values():
        sync_product_label_list(source, scene, defer_rebuild=defer_rebuild)


def active_item(source: bpy.types.Object | None, scene: bpy.types.Scene | None = None):
    """Return the selected product-local row without mutating Blender data.

    This function is called by Panel.draw(), so it must never synchronize or
    repair collections. Synchronization happens in operators/handlers instead.
    """
    if source is None or not hasattr(source, "jb3d_label_items"):
        return None
    if not source.jb3d_label_items:
        return None
    index = max(0, min(int(source.jb3d_label_index), len(source.jb3d_label_items) - 1))
    return source.jb3d_label_items[index]


def active_label(context: bpy.types.Context) -> bpy.types.Object | None:
    source = active_product(context)
    item = active_item(source, getattr(context, "scene", None))
    return _safe_item_label(item) if item is not None else None


def has_active_label_item(context: bpy.types.Context) -> bool:
    source = active_product(context)
    if source is None or not hasattr(source, "jb3d_label_items"):
        return False
    # Do not force pointer dereference here. A stale selected row is deliberately
    # considered deletable so the Delete operator can clean it safely.
    return len(source.jb3d_label_items) > 0


def active_rig(context: bpy.types.Context):
    label = active_label(context)
    rig = resolve_rig_from_object(label)
    if rig is not None:
        return rig
    return resolve_rig_from_object(context.active_object)


def index_selection_suspended() -> bool:
    return _INDEX_SELECTION_SUSPENDED


def set_active_label(
    source: bpy.types.Object | None,
    label: bpy.types.Object | None,
    *,
    scene: bpy.types.Scene | None = None,
) -> None:
    if source is None or label is None:
        return
    sync_product_label_list(source, scene)
    rig_uuid = _safe_rig_uuid(label)
    for index, item in enumerate(source.jb3d_label_items):
        if item.rig_uuid == rig_uuid or _safe_item_label(item) == label:
            source.jb3d_label_index = index
            return


def register_label(scene: bpy.types.Scene, label: bpy.types.Object, *, at_top: bool = True) -> None:
    source = _safe_data_object(label.jb3d_labeler, "source_object") if label is not None else None
    if source is None:
        return
    sync_product_label_list(source, scene, defer_rebuild=False)
    rig_uuid = _safe_rig_uuid(label)
    current_index = next(
        (
            index for index, item in enumerate(source.jb3d_label_items)
            if item.rig_uuid == rig_uuid or _safe_item_label(item) == label
        ),
        None,
    )
    if current_index is None:
        item = source.jb3d_label_items.add()
        item.label = label
        item.rig_uuid = rig_uuid
        current_index = len(source.jb3d_label_items) - 1
    if at_top and current_index > 0:
        source.jb3d_label_items.move(current_index, 0)
        current_index = 0
    source.jb3d_label_index = current_index
    for index, item in enumerate(source.jb3d_label_items):
        item_label = _safe_item_label(item)
        if item_label is not None:
            item_label.jb3d_labeler.stack_order = index


def unregister_label(scene: bpy.types.Scene, label: bpy.types.Object | None) -> None:
    if label is None:
        return
    source = _safe_data_object(label.jb3d_labeler, "source_object")
    if source is None or not hasattr(source, "jb3d_label_items"):
        return
    rig_uuid = _safe_rig_uuid(label)
    for index in reversed(range(len(source.jb3d_label_items))):
        item = source.jb3d_label_items[index]
        if item.rig_uuid == rig_uuid or _safe_item_label(item) == label:
            source.jb3d_label_items.remove(index)
    if source.jb3d_label_items:
        source.jb3d_label_index = min(source.jb3d_label_index, len(source.jb3d_label_items) - 1)
    else:
        source.jb3d_label_index = 0


def remove_active_item(source: bpy.types.Object | None) -> tuple[bpy.types.Object | None, str]:
    """Remove the selected UI row and return (live_label, rig_uuid).

    This is safe even if Blender has already deleted the label object.
    """
    if source is None or not hasattr(source, "jb3d_label_items") or not source.jb3d_label_items:
        return None, ""
    index = max(0, min(int(source.jb3d_label_index), len(source.jb3d_label_items) - 1))
    item = source.jb3d_label_items[index]
    label = _safe_item_label(item)
    rig_uuid = str(getattr(item, "rig_uuid", "") or "") or _safe_rig_uuid(label)
    source.jb3d_label_items.remove(index)
    if source.jb3d_label_items:
        source.jb3d_label_index = min(index, len(source.jb3d_label_items) - 1)
    else:
        source.jb3d_label_index = 0
    return label, rig_uuid


def label_from_uuid(scene: bpy.types.Scene, rig_uuid: str) -> bpy.types.Object | None:
    if not rig_uuid:
        return None
    for label in labels_in_scene(scene):
        if _safe_rig_uuid(label) == rig_uuid:
            return label
    return None


def apply_stack_order(
    context: bpy.types.Context,
    scene: bpy.types.Scene | None = None,
    source: bpy.types.Object | None = None,
) -> None:
    """Persist one product's top-to-bottom order and rebuild its material stack."""
    scene = scene or context.scene
    source = source or active_product(context)
    if source is None:
        return
    sync_product_label_list(source, scene, defer_rebuild=False)

    for index, item in enumerate(source.jb3d_label_items):
        label = _safe_item_label(item)
        if label is None:
            continue
        data = label.jb3d_labeler
        data.stack_order = index
        data.stack_bias = 0.0
        rig = resolve_rig_from_object(label)
        if rig is None:
            continue
        ensure_rig_parenting(rig)
        try:
            from .utils import remove_shrinkwrap, remove_source_subdivision
            remove_shrinkwrap(label)
            remove_source_subdivision(label)
        except Exception:
            pass
        _apply_saved_states(label)

    try:
        from . import compositor
        compositor.rebuild_source_stack(source, scene)
    except Exception:
        pass


def move_active_item(context: bpy.types.Context, direction: str) -> bool:
    source = active_product(context)
    if source is None:
        return False
    sync_product_label_list(source, context.scene)
    count = len(source.jb3d_label_items)
    if count < 2:
        return False
    index = max(0, min(int(source.jb3d_label_index), count - 1))
    target = index - 1 if direction == 'UP' else index + 1
    if target < 0 or target >= count:
        return False
    source.jb3d_label_items.move(index, target)
    source.jb3d_label_index = target
    apply_stack_order(context, context.scene, source)
    return True


def _scene_key(scene: bpy.types.Scene | None) -> int:
    try:
        return int(scene.as_pointer()) if scene is not None else 0
    except (ReferenceError, RuntimeError, AttributeError):
        return 0


def remember_material_state(source: bpy.types.Object | None) -> None:
    """Cache one labeled product and its structural material state."""
    if source is None or source.type != 'MESH':
        return
    try:
        from . import material_engine
        token = str(source.get(material_engine.SOURCE_UUID_KEY, ""))
        if not token:
            return
        _SOURCE_OBJECTS[token] = source
        _SOURCE_MATERIAL_SIGNATURES[token] = material_engine.material_binding_signature(source)
    except (ReferenceError, RuntimeError, AttributeError):
        return


def _forget_unused_material_states() -> None:
    """Drop cached products that were deleted or no longer own JB3D data."""
    try:
        from . import material_engine
    except Exception:
        return

    for token, source in list(_SOURCE_OBJECTS.items()):
        try:
            alive = bool(source.as_pointer()) and str(source.get(material_engine.SOURCE_UUID_KEY, "")) == token
        except (ReferenceError, RuntimeError, AttributeError):
            alive = False
        if alive:
            continue
        _SOURCE_OBJECTS.pop(token, None)
        _SOURCE_MATERIAL_SIGNATURES.pop(token, None)


def _watch_product_materials(_scene: bpy.types.Scene) -> None:
    """Detect structural material changes and defer one JB3D rebuild.

    Only products already known to JB3D are inspected. This keeps the handler
    independent of scene size: normal transforms, animation and material value
    tweaks never rebuild the stack. Slot replacement, Principled replacement or
    reconnecting Base Color/Roughness/Metallic is repaired automatically.
    """
    try:
        from . import material_engine
    except Exception:
        return

    for token, source in list(_SOURCE_OBJECTS.items()):
        try:
            if not source.as_pointer() or source.type != 'MESH':
                raise ReferenceError
            if str(source.get(material_engine.SOURCE_UUID_KEY, "")) != token:
                raise ReferenceError
            if hasattr(source, "jb3d_label_items") and len(source.jb3d_label_items) == 0:
                continue
            signature = material_engine.material_binding_signature(source)
        except (ReferenceError, RuntimeError, AttributeError):
            _SOURCE_OBJECTS.pop(token, None)
            _SOURCE_MATERIAL_SIGNATURES.pop(token, None)
            continue

        previous = _SOURCE_MATERIAL_SIGNATURES.get(token)
        if previous is None:
            _SOURCE_MATERIAL_SIGNATURES[token] = signature
            continue
        if signature != previous:
            # Cache immediately so repeated depsgraph events caused by the same
            # edit coalesce into the already scheduled deferred rebuild.
            _SOURCE_MATERIAL_SIGNATURES[token] = signature
            mark_product_dirty(source)


def _sync_scenes_after_object_change():
    """Repair product-local lists outside depsgraph evaluation and UI drawing."""
    global _SCENE_SYNC_TIMER_REGISTERED
    _SCENE_SYNC_TIMER_REGISTERED = False
    for scene in list(getattr(bpy.data, "scenes", ())):
        try:
            sync_scene_products(scene, defer_rebuild=True)
            _SCENE_OBJECT_COUNTS[_scene_key(scene)] = len(scene.objects)
        except (ReferenceError, RuntimeError):
            continue
    _forget_unused_material_states()
    return None


def _schedule_scene_sync() -> None:
    global _SCENE_SYNC_TIMER_REGISTERED
    if _SCENE_SYNC_TIMER_REGISTERED:
        return
    bpy.app.timers.register(_sync_scenes_after_object_change, first_interval=0.05)
    _SCENE_SYNC_TIMER_REGISTERED = True


@persistent
def _depsgraph_update_post(scene, _depsgraph) -> None:
    key = _scene_key(scene)
    if not key:
        return
    try:
        count = len(scene.objects)
    except (ReferenceError, RuntimeError):
        return

    previous = _SCENE_OBJECT_COUNTS.get(key)
    _SCENE_OBJECT_COUNTS[key] = count

    if previous is None:
        # Registration must not touch bpy.data while Blender is still in its
        # restricted startup context. Discover existing JB3D products lazily on
        # the first normal depsgraph event instead, then schedule one rebuild so
        # labels remain valid even if the first user action was replacing a
        # material immediately after enabling/updating the extension.
        try:
            from . import material_engine
            for source in scene.objects:
                if source.type != 'MESH' or not source.get(material_engine.SOURCE_UUID_KEY):
                    continue
                remember_material_state(source)
                mark_product_dirty(source)
        except Exception:
            pass
        _schedule_scene_sync()
    elif previous != count:
        _schedule_scene_sync()

    _watch_product_materials(scene)


@persistent
def _load_post(_dummy) -> None:
    _SCENE_OBJECT_COUNTS.clear()
    _SOURCE_MATERIAL_SIGNATURES.clear()
    _SOURCE_OBJECTS.clear()
    for scene in bpy.data.scenes:
        sync_scene_products(scene, defer_rebuild=False)
        _SCENE_OBJECT_COUNTS[_scene_key(scene)] = len(scene.objects)
        try:
            from . import compositor, material_engine
            compositor.refresh_scene(scene)
            for source in scene.objects:
                if source.type == 'MESH' and source.get(material_engine.SOURCE_UUID_KEY):
                    remember_material_state(source)
        except Exception:
            pass


def register():
    # Keep registration deliberately minimal. In particular, do not access
    # bpy.data here: extension installation can call register() while Blender
    # exposes _RestrictData. Runtime discovery happens in load/depsgraph handlers.
    _SCENE_OBJECT_COUNTS.clear()
    _SOURCE_MATERIAL_SIGNATURES.clear()
    _SOURCE_OBJECTS.clear()
    _DIRTY_SOURCE_UUIDS.clear()

    bpy.app.handlers.load_post.append(_load_post)
    bpy.app.handlers.depsgraph_update_post.append(_depsgraph_update_post)


def unregister():
    global _DIRTY_TIMER_REGISTERED, _SCENE_SYNC_TIMER_REGISTERED

    if _load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post)
    if _depsgraph_update_post in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_update_post)

    if bpy.app.timers.is_registered(_flush_dirty_sources):
        bpy.app.timers.unregister(_flush_dirty_sources)
    _DIRTY_TIMER_REGISTERED = False
    _DIRTY_SOURCE_UUIDS.clear()

    if bpy.app.timers.is_registered(_sync_scenes_after_object_change):
        bpy.app.timers.unregister(_sync_scenes_after_object_change)
    _SCENE_SYNC_TIMER_REGISTERED = False
    _SCENE_OBJECT_COUNTS.clear()
    _SOURCE_MATERIAL_SIGNATURES.clear()
    _SOURCE_OBJECTS.clear()
