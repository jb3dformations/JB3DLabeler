# SPDX-FileCopyrightText: 2026 Josselin Boullery
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import bpy
from bpy.types import Panel, UIList

from . import material_engine, registry, wrap
from .utils import format_distance, label_fit_report, resolve_rig_from_object


def _draw_image_info(layout, data) -> None:
    if data.image_pixel_width > 0 and data.image_pixel_height > 0:
        row = layout.row()
        row.scale_y = 0.85
        row.label(text=f"{data.image_pixel_width} × {data.image_pixel_height} px", icon='IMAGE_DATA')


def _foldout(layout, owner, prop_name: str, label: str, icon: str = 'NONE'):
    opened = bool(getattr(owner, prop_name))
    row = layout.row(align=True)
    row.scale_y = 1.08
    row.prop(
        owner, prop_name, text=label,
        icon='TRIA_DOWN' if opened else 'TRIA_RIGHT', emboss=False,
    )
    if icon != 'NONE':
        row.label(text="", icon=icon)
    return opened


def _safe_label(item):
    try:
        label = item.label
        if label is None or not label.as_pointer():
            return None
        return label
    except (ReferenceError, RuntimeError, AttributeError):
        return None


class JB3D_LABELER_UL_labels(UIList):
    bl_idname = "JB3D_LABELER_UL_labels"

    def draw_item(
        self, context, layout, data, item, icon, active_data,
        active_propname, index=0,
    ):
        label = _safe_label(item)
        if label is None:
            # This row is transient: the product synchronizer removes stale
            # pointers and schedules a material-stack cleanup outside draw().
            layout.label(text="Removed label", icon='ERROR')
            return
        settings = label.jb3d_labeler
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            type_icon = 'MOD_UVPROJECT' if settings.label_type == 'WRAP_360' else 'IMAGE_DATA'
            row.prop(label, "name", text="", emboss=False, icon=type_icon, translate=False)
            row.prop(
                settings, "visible", text="", emboss=False,
                icon='HIDE_OFF' if settings.visible else 'HIDE_ON',
            )
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')


class JB3D_LABELER_PT_main(Panel):
    bl_label = "JB3D Labeler"
    bl_idname = "JB3D_LABELER_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "JB3D"

    def draw(self, context):
        try:
            self._draw_ui(context)
        except Exception as exc:
            # Never leave users with an unexplained empty sidebar. Keep this
            # fallback deliberately independent from JB3D custom properties.
            import traceback
            traceback.print_exc()
            layout = self.layout
            box = layout.box()
            box.alert = True
            box.label(text="JB3D Labeler UI error", icon='ERROR')
            message = str(exc).strip() or exc.__class__.__name__
            box.label(text=message[:120])
            box.label(text="See Blender's console for the full traceback.", icon='INFO')

    def _draw_ui(self, context):
        layout = self.layout
        scene = context.scene
        defaults = scene.jb3d_labeler
        # Panel.draw() must remain read-only. Blender can reject RNA writes
        # while UI regions are being drawn, which would leave this panel blank.
        # Product lists are synchronized by operators/load handlers and by the
        # lightweight deferred scene watcher in registry.py.
        source = registry.active_product(context)

        # ------------------------------------------------------------------
        # ADD LABEL
        # ------------------------------------------------------------------
        add_box = layout.box()
        if _foldout(add_box, defaults, "show_add_label", "Add Label", 'ADD'):
            add_box.prop(defaults, "label_type", expand=True)
            add_box.prop(defaults, "image_path", text="Image")
            _draw_image_info(add_box, defaults)

            if defaults.label_type == 'STANDARD':
                size = add_box.row(align=False)
                size.prop(defaults, "width")
                size.prop(defaults, "height")
                add_box.prop(defaults, "preserve_ratio", text="Keep Image Ratio")
            else:
                hint = add_box.column(align=False)
                hint.scale_y = 0.85
                hint.label(text="Select one continuous band of faces.", icon='INFO')
                hint.label(text="The active face defines the front.")
                add_box.prop(defaults, "preserve_ratio", text="Keep Image Ratio")

            if _foldout(add_box, defaults, "show_create_advanced", "Advanced"):
                advanced = add_box.column(align=False)
                if defaults.label_type == 'STANDARD':
                    advanced.prop(defaults, "unwrap_method")
                    advanced.prop(defaults, "orientation_mode")
                else:
                    advanced.prop(defaults, "wrap_seam_mode")
                    advanced.prop(defaults, "wrap_axis")
                material_row = advanced.row(align=False)
                material_row.prop(defaults, "roughness")
                material_row.prop(defaults, "metallic")
                advanced.prop(defaults, "pack_image")

            text = "Create 360° Wrap" if defaults.label_type == 'WRAP_360' else "Create Standard Label"
            add_box.separator()
            create_row = add_box.row()
            create_row.scale_y = 1.2
            create_row.operator("jb3d_labeler.create_from_selection", text=text, icon='UV_FACESEL')
            if context.mode != 'EDIT_MESH':
                row = add_box.row()
                row.scale_y = 0.8
                row.label(text="Product + faces must be selected in Edit Mode", icon='INFO')

        layout.separator()

        # ------------------------------------------------------------------
        # PRODUCT-LOCAL LABEL STACK
        # ------------------------------------------------------------------
        manager = layout.box()
        label_count = len(source.jb3d_label_items) if source is not None and hasattr(source, "jb3d_label_items") else 0
        if _foldout(manager, defaults, "show_labels", f"Labels ({label_count})", 'IMAGE_DATA'):
            if source is None:
                manager.label(text="Select a mesh product", icon='OBJECT_DATA')
            else:
                product_row = manager.row(align=False)
                product_row.label(text="Product", icon='OBJECT_DATA')
                product_row.label(text=source.name)

                list_row = manager.row()
                list_row.template_list(
                    "JB3D_LABELER_UL_labels", "", source, "jb3d_label_items",
                    source, "jb3d_label_index", rows=4,
                )
                buttons = list_row.column(align=False)
                op = buttons.operator("jb3d_labeler.move_layer", text="", icon='TRIA_UP')
                op.direction = 'UP'
                op = buttons.operator("jb3d_labeler.move_layer", text="", icon='TRIA_DOWN')
                op.direction = 'DOWN'
                buttons.separator()
                buttons.operator("jb3d_labeler.delete_rig", text="", icon='TRASH')

                row = manager.row()
                row.scale_y = 0.75
                if label_count:
                    row.label(text="Top of the list = top material layer", icon='TRIA_UP')
                else:
                    row.label(text="No labels on this product", icon='INFO')

        layout.separator()

        label = registry.active_label(context)
        rig = resolve_rig_from_object(label, migrate=False)
        if rig is None:
            if _foldout(layout, defaults, "show_utilities", "Utilities", 'TOOL_SETTINGS'):
                box = layout.box()
                box.operator("jb3d_labeler.refresh_list", text="Refresh Product Labels", icon='FILE_REFRESH')
            return

        data = rig.label.jb3d_labeler
        is_wrap = data.label_type == 'WRAP_360'

        # ------------------------------------------------------------------
        # SELECTED LABEL
        # ------------------------------------------------------------------
        selected = layout.box()
        header = selected.row(align=False)
        header.label(
            text="360° Wrap" if is_wrap else "Standard Label",
            icon='MOD_UVPROJECT' if is_wrap else 'IMAGE_DATA',
        )
        header.prop(rig.label, "name", text="")
        header.prop(
            data, "visible", text="", emboss=False,
            icon='HIDE_OFF' if data.visible else 'HIDE_ON',
        )

        selected.separator()
        quick = selected.row(align=False)
        quick.scale_y = 1.15
        quick.operator("jb3d_labeler.select_controller", text="Edit in Viewport", icon='EMPTY_AXIS')
        quick.operator("jb3d_labeler.select_source", text="Product", icon='OBJECT_DATA')

        selected.separator()
        selected.prop(data, "image_path", text="Artwork")
        _draw_image_info(selected, data)

        # From here each section is a sibling box rather than a nested box.
        # This gives the narrow N-panel more horizontal room (especially for
        # ColorRamp stops) and makes the hierarchy easier to scan.
        layout.separator()

        # Placement --------------------------------------------------------
        placement_box = layout.box()
        if _foldout(placement_box, data, "ui_show_placement", "Placement", 'ORIENTATION_GLOBAL'):
            placement = placement_box.column(align=False)
            if rig.controller is not None:
                if is_wrap:
                    row = placement.row(align=False)
                    row.prop(rig.controller, "location", index=0, text="Horizontal")
                    row.prop(rig.controller, "location", index=1, text="Vertical")
                else:
                    row = placement.row(align=False)
                    row.prop(rig.controller, "location", index=0, text="X")
                    row.prop(rig.controller, "location", index=1, text="Y")
                    placement.prop(rig.controller, "rotation_euler", index=2, text="Rotation")

            size = placement.row(align=False)
            size.prop(data, "width")
            size.prop(data, "height")
            placement.prop(data, "preserve_ratio", text="Keep Image Ratio")

            if is_wrap:
                placement.separator()
                fit = placement.row(align=False)
                fit.scale_y = 1.1
                op = fit.operator("jb3d_labeler.fit_wrap_artwork", text="Full 360°")
                op.mode = 'FULL_WIDTH'
                op = fit.operator("jb3d_labeler.fit_wrap_artwork", text="Fit Height")
                op.mode = 'BAND_HEIGHT'
            else:
                placement.separator()
                tools = placement.row(align=False)
                tools.scale_y = 1.1
                tools.operator("jb3d_labeler.rotate_90", text="Rotate 90°")
                tools.operator("jb3d_labeler.reset_controller", text="Recenter")
            placement.prop(data, "controller_visible", text="Show Controller")

        # Appearance -------------------------------------------------------
        layout.separator()
        appearance_box = layout.box()
        if _foldout(appearance_box, data, "ui_show_appearance", "Appearance", 'MATERIAL'):
            appearance = appearance_box.column(align=False)
            appearance.prop(data, "blend_mode", text="Blend")
            appearance.prop(data, "opacity", text="Opacity", slider=True)

            appearance.separator()
            appearance.label(text="Color Treatment")
            color_modes = appearance.row(align=True)
            color_modes.scale_y = 1.1
            color_modes.prop(data, "color_mode", expand=True)
            if data.color_mode != 'ARTWORK':
                appearance.separator()
                appearance.prop(data, "effect_color", text="Color")
                if data.mask_enabled and data.mask_affect_color:
                    info = appearance.row()
                    info.scale_y = 0.75
                    info.label(text="Color treatment is limited by the material mask", icon='MOD_MASK')

            appearance.separator()
            appearance.label(text="Label Surface")
            surface = appearance.column(align=False)
            surface.prop(data, "roughness")
            surface.prop(data, "metallic")

            if data.material_status:
                appearance.separator()
                status = appearance.row()
                status.scale_y = 0.8
                icon = 'CHECKMARK' if data.material_status.startswith("Material Decal active") else 'ERROR'
                status.label(text=data.material_status, icon=icon)
            if data.composite_status and data.composite_status != data.material_status:
                warning = appearance.row()
                warning.scale_y = 0.8
                warning.label(text=data.composite_status, icon='ERROR')

        # Material Effects -------------------------------------------------
        layout.separator()
        mask_box = layout.box()
        if _foldout(mask_box, data, "ui_show_mask", "Material Effects", 'MOD_MASK'):
            mask_box.prop(data, "mask_enabled", text="Use Material Mask")
            mask_box.separator()
            mask = mask_box.column(align=False)
            mask.enabled = data.mask_enabled

            source_row = mask.column(align=False)
            source_row.prop(data, "mask_source", text="Source")
            source_row.prop(data, "mask_channel", text="Channel")
            if data.mask_source == 'EXTERNAL_IMAGE':
                mask.prop(data, "mask_image_path", text="Mask Image")

            mask.separator()
            mask.label(text="Mask Range")
            ramp_node = material_engine.get_mask_ramp_node(rig.label) if data.mask_enabled else None
            if ramp_node is not None:
                # Blender's expanded native ColorRamp widget exposes the stops,
                # active-stop position/color/alpha, color mode, interpolation and
                # hue interpolation controls without duplicating them in JB3D UI.
                mask.template_color_ramp(ramp_node, "color_ramp", expand=True)
                mask.separator()
                tools = mask.row(align=False)
                tools.scale_y = 1.1
                tools.operator("jb3d_labeler.invert_mask_ramp", text="Invert", icon='ARROW_LEFTRIGHT')
                tools.operator("jb3d_labeler.reset_mask_ramp", text="Reset", icon='LOOP_BACK')
            elif data.mask_enabled:
                warning = mask.box()
                warning.label(text="Mask ramp unavailable", icon='ERROR')
                warning.operator("jb3d_labeler.rebuild_compositing", text="Rebuild Material Stack", icon='NODETREE')

            mask.separator()
            preview = mask.row(align=True)
            preview.scale_y = 1.15
            op = preview.operator(
                "jb3d_labeler.set_mask_preview", text="Final", icon='MATERIAL',
                depress=not data.preview_mask,
            )
            op.mode = 'FINAL'
            op = preview.operator(
                "jb3d_labeler.set_mask_preview", text="Mask", icon='MOD_MASK',
                depress=data.preview_mask,
            )
            op.mode = 'MASK'

            mask.separator()
            mask.label(text="Masked Effects")
            affects = mask.row(align=False)
            affects.scale_y = 1.15
            affects.prop(data, "mask_affect_color", text="Color", toggle=True)
            affects.prop(data, "mask_affect_roughness", text="Roughness", toggle=True)
            affects.prop(data, "mask_affect_metallic", text="Metallic", toggle=True)

            if data.mask_affect_color and data.color_mode == 'ARTWORK':
                hint = mask.row()
                hint.scale_y = 0.75
                hint.label(text="Choose Tint or Replace in Appearance for a masked color effect", icon='INFO')
            if data.mask_affect_roughness or data.mask_affect_metallic:
                values = mask.column(align=False)
                if data.mask_affect_roughness:
                    values.prop(data, "masked_roughness", text="Roughness")
                if data.mask_affect_metallic:
                    values.prop(data, "masked_metallic", text="Metallic")

        # Advanced ---------------------------------------------------------
        layout.separator()
        advanced_box = layout.box()
        if _foldout(advanced_box, data, "ui_show_advanced", "Advanced"):
            advanced = advanced_box.column(align=False)
            if is_wrap:
                row = advanced.column(align=False)
                row.prop(data, "wrap_seam_mode")
                row.prop(data, "wrap_axis")
                measurements = advanced.box()
                measurements.label(text=f"Circumference: {format_distance(scene, data.wrap_circumference)}")
                measurements.label(text=f"Band Height: {format_distance(scene, data.wrap_height)}")
                if data.taper_percentage > 5.0:
                    measurements.label(text=f"Taper: {data.taper_percentage:.1f}%", icon='ERROR')
                warning = wrap.artwork_fit_warning(data, rig.controller)
                if warning:
                    measurements.label(text=warning, icon='ERROR')
            else:
                row = advanced.column(align=False)
                row.prop(data, "unwrap_method")
                row.prop(data, "orientation_mode")
                fit = label_fit_report(rig)
                if not fit.fits:
                    advanced.label(text=f"Artwork overflow: {format_distance(scene, fit.overflow)}", icon='ERROR')
                if data.distortion_rms >= 5.0:
                    advanced.label(text=f"UV distortion: {data.distortion_rms:.1f}%", icon='INFO')
            advanced.separator()
            advanced.prop(data, "pack_image")

        # Utilities --------------------------------------------------------
        layout.separator()
        if _foldout(layout, defaults, "show_utilities", "Utilities", 'TOOL_SETTINGS'):
            utilities = layout.box()
            utilities.scale_y = 1.05
            actions = utilities.column(align=False)
            actions.operator("jb3d_labeler.rebuild_compositing", text="Rebuild Material Stack", icon='NODETREE')
            actions.operator("jb3d_labeler.rebuild_uv", text="Rebuild Mapping", icon='FILE_REFRESH')
            actions.operator("jb3d_labeler.repair_links", text="Repair Rig Links", icon='LINKED')
            actions.operator("jb3d_labeler.refresh_list", text="Refresh Product Labels", icon='FILE_REFRESH')
            utilities.separator()
            utilities.prop(data, "debug_show_surface", text="Show Internal Mapping Surface")
            if data.debug_show_surface:
                utilities.operator("jb3d_labeler.select_label", text="Select Mapping Surface", icon='MESH_GRID')
                utilities.operator("jb3d_labeler.select_anchor", text="Select Anchor", icon='EMPTY_AXIS')
            utilities.operator("jb3d_labeler.delete_rig", text="Delete Label", icon='TRASH')


_CLASSES = (JB3D_LABELER_UL_labels, JB3D_LABELER_PT_main)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
